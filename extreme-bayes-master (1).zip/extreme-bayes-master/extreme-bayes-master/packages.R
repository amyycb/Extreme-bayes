# Installs packages required to set up shiny for a hotspot analysis
PATH_TO_SHINYDOWNLOAD <- "~/packages/shinyDownload"
PATH_TO_GEVTOOLS <- "~/packages/gevtools"

# Install any packages that are missing from the list of dependancies
requiredPackages <- c("shiny", "shinyjs", "ggplot2", "dygraphs", "xts", "plotly", "texmex", "gridExtra", "DT", "reshape")
packagesToInstall <- requiredPackages[!(requiredPackages %in% installed.packages()[,"Package"])]
if(length(packagesToInstall))
  install.packages(packagesToInstall)

# Check if shinyDownload is installed and install it if it isn't already so.
if (!library(shinyDownload, logical.return = TRUE)) {
  cwd <- setwd(PATH_TO_SHINYDOWNLOAD)
  devtools::install()
  setwd(cwd)
}

# Check if gevtools is installed and install it if it isn't already so.
if (!library(gevtools logical.return = TRUE)) {
  cwd <- setwd(PATH_TO_GEVTOOLS)
  devtools::install()
  setwd(cwd)
}
