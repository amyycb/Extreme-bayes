#Function to calculate the (negative) log-likelihood of the GEV distribution#
gev.loglik<-function(theta)
{
mu<-theta[1]
sigma<-theta[2]
xi<-theta[3]
m<-min((1+(xi*(dataset-mu)/sigma)))
if(m<0.00001)return(as.double(1000000))
if(sigma<0.00001)return(as.double(1000000))
loglik<--length(dataset)*log(sigma)-(1/xi+1)*sum(log(1+(xi*(dataset-mu)/sigma)))-sum((1+(xi*(dataset-mu)/sigma))**(-1/xi))
return(-loglik)
}

#Function to calculate MLEs of the parameters of the GEV distribution#
mle.gev<-function(dataset,xistart=0.1)
{  
z<-list()
theta<-c(mean(dataset),(var(dataset)**0.5),xistart)
assign("dataset",dataset,inherits=TRUE,envir=sys.frame())
a<-nlm(gev.loglik,theta)
z$estimate<-a$estimate
#b<-unclass(a[4])
#names(b)<-NULL
#e<-unlist(b)
#f<-matrix(e,ncol=3,nrow=3)
#z$varcovar<-matrix(solve(f),ncol=3,nrow=3)
#z$se<-sqrt(diag(z$varcovar))
return(z)
}

#Function to calculate the CDF of the GEV distribution#
gev.df<-function(x,mu,sigma,xi)
{
if(sigma<=0.0001)
{
stop("sigma out of range")
}
if(abs(xi)>0.0001)
{
a<-(xi*(x-mu))/sigma
a<-1+a
a<-max(a,0)
gev.df<-exp(-a^(-1/xi))
}
else if(abs(xi)<=0.001){
a<-(x-mu)/sigma
gev.df<-exp(-exp(-a))
}
return(gev.df)
}

#Function to claculate the PDF of the GEV distribution#
gev.pdf<-function(x,mu,sigma,xi)
{
Fx<-gev.df(x,mu,sigma,xi)
t5<-(x-mu)/sigma
if(abs(xi)>0.0001){
t1<-xi*t5
t2<-1+t1
t3<-max(t2,0)
t4<-t3^{-(1+xi)/xi}/sigma
gev.dens<-Fx*t4
}
else{
gev.dens<-Fx*exp(-t5)/sigma
}
return(gev.dens)
}

#Function to produce a quantile plot for the GEV distribution (with vector of parameter estimates est)#
gevquant<-function(dataset,est)
{
l<-list()
n<-length(dataset)
for(i in 1:n)
{
y<-est[1]+est[2]*((-log(i/(n+1)))^(-est[3])-1)/est[3]
l<-c(l,y)
}
plot(sort(dataset),l,type="p",xlab="empricial",ylab="model")
abline(0,1)
}

#Function to calculate the (negative) log-likelihood of the GPD#
gpd.loglik<-function(theta)
{
sigma<-theta[1]
xi<-theta[2]
m<-min(1+(dataset*(xi/sigma)))
if(m<0.00001)return(as.double(1000000))
if(sigma<0.00001)return(as.double(1000000))
loglik<--length(dataset)*log(sigma)-sum(log(1+(dataset*(xi/sigma)))*(1/xi+1))
return(-loglik)
}

#Function to calculate MLEs of the parameters of the GPD#
mle.gpd7<-function(dataset,xistart=0.1)
{
z<-list()
theta<-c((var(dataset)**0.5),xistart)
assign("dataset",dataset,inherits=TRUE,envir=sys.frame())
a<-nlm(gpd.loglik,theta,hessian=TRUE)
z$estimate<-a$estimate
b<-unclass(a[4])
names(b)<-NULL
e<-unlist(b)
f<-matrix(e,ncol=2,nrow=2)
z$varcovar<-matrix(solve(f),ncol=2,nrow=2)
z$se<-sqrt(diag(z$varcovar))
return(z)
}

#Function to produce a Q-Q plot to assess the fit of all threshold excesses to a GPD#
quant.plot<-function(dataset,u,est)
{
dataset<-dataset-u
dataset<-dataset[dataset>0]
n<-length(dataset)
sorted<-sort(dataset)
x<-vector("numeric",n)
inv.gpd<-vector("numeric",n)
for(i in 1:n)
{
x[i]<-(i/(n+1))
inv.gpd[i]<-(est[1]/est[2])*(((1-x[i])^((-(est[2]))))-1)
}
plot(inv.gpd~sorted,pch=3,xlab="empirical",ylab="model")
abline(0,1)
}

#Function to produce a Q-Q plot to assess the fit of cluster peaks to a GPD#
peaks.quant.plot<-function(dataset,u,est)
{
test1<-as.vector(cluster10(dataset,u),mode="numeric")
test2<-test1-u
n<-length(test2)
sorted<-sort(test2)
x<-vector("numeric",n)
inv.gpd<-vector("numeric",n)
for(i in 1:n)
{
x[i]<-(i/(n+1))
inv.gpd[i]<-(est[1]/est[2])*(((1-x[i])^((-(est[2]))))-1)
}
plot(inv.gpd~sorted,pch=3,xlab="empirical",ylab="model")
abline(0,1)
}

#Function to simulate a time-dependent series with unit exponential marginals (based on the logistic model)#
correxp.2<-function(n,a)
{
r<-1/a
xvec<-vector("numeric",n)
xvec[1]<-rexp(1,1)
for(i in 2:n)
{
w<-1
fx<-0
while(w>fx)
{
x2<-0
while(x2<xvec[i-1])
{
x2<-rexp(1,1)
}
u2<-runif(1,0,1)
w<-(u2*(r-1+xvec[i-1])*exp(xvec[i-1]-x2))/xvec[i-1]
fx<-((r-1+x2)*xvec[i-1]^(r-1)*exp(xvec[i-1]-x2))/(x2^r)
}
xvec[i]<-(x2^r-xvec[i-1]^r)^(1/r)
}
xvec
}

#Function to simulate a time-dependent series with GPD marginals (transformed from the above)#
corrgpd.3<-function(n,a,sigma,xi)
{
test<-correxp.2(n,a)
corrgpd<-(sigma/xi)*(exp(xi*test)-1)
corrgpd
}

#DECLUSTERING DATA USING THE RUNS METHOD#

#separation interva s=1#
cluster1<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (2):length(set))
{
if(set[i-1]>threshold & set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=2#
cluster2<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (3):length(set))
{
if(set[i-2]>threshold
& set[i-1]<=threshold & set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=3#
cluster3<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (4):length(set))
{
if(set[i-3]>threshold
& set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{

x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}
}

}
z
}

#separation interval s=4#
cluster4<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (5):length(set))
{
if(set[i-4]>threshold
& set[i-3]<=threshold
& set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=5#
cluster5<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (6):length(set))
{
if(set[i-5]>threshold
& set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=6#
cluster6<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (7):length(set))
{
if(set[i-6]>threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=7#
cluster7<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (8):length(set))
{
if(set[i-7]>threshold
& set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=8#
cluster8<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (9):length(set))
{
if(set[i-8]>threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=9#
cluster9<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (10):length(set))
{
if(set[i-9]>threshold
& set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=10#
cluster10<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (11):length(set))
{
if(set[i-10]>threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=11#

cluster11<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (12):length(set))
{
if(set[i-11]>threshold
& set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=12#
cluster12<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (13):length(set))
{
if(set[i-12]>threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=13#
cluster13<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (14):length(set))
{
if(set[i-13]>threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=14#
cluster14<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (15):length(set))
{
if(set[i-14]>threshold & set[i-13]<=threshold
& set[i-12]<=threshold & set[i-11]<=threshold 
& set[i-10]<=threshold & set[i-9]<=threshold 
& set[i-8]<=threshold & set[i-7]<=threshold 
& set[i-6]<=threshold & set[i-5]<=threshold 
& set[i-4]<=threshold & set[i-3]<=threshold 
& set[i-2]<=threshold & set[i-1]<=threshold 
& set[i]<=threshold)
{
x<-max(set[j:i])


ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=15#
cluster15<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (16):length(set))
{
if(set[i-15]>threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{

x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=16#
cluster16<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (17):length(set))
{
if(set[i-16]>threshold & set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=17#
cluster17<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (18):length(set))
{
if(set[i-17]>threshold & set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=18#
cluster18<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (19):length(set))
{
if(set[i-18]>threshold & set[i-17]<=threshold
& set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=19#
cluster19<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (20):length(set))
{
if(set[i-19]>threshold & set[i-18]<=threshold
& set[i-17]<=threshold
& set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=20#
cluster20<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (21):length(set))
{
if(set[i-20]>threshold & set[i-19]<=threshold
& set[i-18]<=threshold
& set[i-17]<=threshold
& set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=21#
cluster21<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (22):length(set))
{
if(set[i-21]>threshold & set[i-20]<=threshold
& set[i-19]<=threshold
& set[i-18]<=threshold
& set[i-17]<=threshold
& set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=22#
cluster22<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (23):length(set))
{
if(set[i-22]>threshold
& set[i-21]<=threshold & set[i-20]<=threshold
& set[i-19]<=threshold
& set[i-18]<=threshold
& set[i-17]<=threshold
& set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=23#
cluster23<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (24):length(set))
{
if(set[i-23]>threshold
& set[i-22]<=threshold
& set[i-21]<=threshold & set[i-20]<=threshold
& set[i-19]<=threshold
& set[i-18]<=threshold
& set[i-17]<=threshold
& set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=24#
cluster24<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (25):length(set))
{
if(set[i-24]>threshold
& set[i-23]<=threshold
& set[i-22]<=threshold
& set[i-21]<=threshold & set[i-20]<=threshold
& set[i-19]<=threshold
& set[i-18]<=threshold
& set[i-17]<=threshold
& set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=25#
cluster25<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (26):length(set))
{
if(set[i-25]>threshold
& set[i-24]<=threshold
& set[i-23]<=threshold
& set[i-22]<=threshold
& set[i-21]<=threshold & set[i-20]<=threshold
& set[i-19]<=threshold
& set[i-18]<=threshold
& set[i-17]<=threshold
& set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}


#separation interval s=26#
cluster26<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (27):length(set))
{
if(set[i-26]>threshold
& set[i-25]<=threshold
& set[i-24]<=threshold
& set[i-23]<=threshold
& set[i-22]<=threshold
& set[i-21]<=threshold & set[i-20]<=threshold
& set[i-19]<=threshold
& set[i-18]<=threshold
& set[i-17]<=threshold
& set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=27#
cluster27<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (28):length(set))
{
if(set[i-27]>threshold
& set[i-26]<=threshold
& set[i-25]<=threshold
& set[i-24]<=threshold
& set[i-23]<=threshold
& set[i-22]<=threshold
& set[i-21]<=threshold & set[i-20]<=threshold
& set[i-19]<=threshold
& set[i-18]<=threshold
& set[i-17]<=threshold
& set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=28#
cluster28<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (29):length(set))
{
if(set[i-28]>threshold
& set[i-27]<=threshold
& set[i-26]<=threshold
& set[i-25]<=threshold
& set[i-24]<=threshold
& set[i-23]<=threshold
& set[i-22]<=threshold
& set[i-21]<=threshold & set[i-20]<=threshold
& set[i-19]<=threshold
& set[i-18]<=threshold
& set[i-17]<=threshold
& set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=29#
cluster29<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (30):length(set))
{
if(set[i-29]>threshold
& set[i-28]<=threshold
& set[i-27]<=threshold
& set[i-26]<=threshold
& set[i-25]<=threshold
& set[i-24]<=threshold
& set[i-23]<=threshold
& set[i-22]<=threshold
& set[i-21]<=threshold & set[i-20]<=threshold
& set[i-19]<=threshold
& set[i-18]<=threshold
& set[i-17]<=threshold
& set[i-16]<=threshold
& set[i-15]<=threshold
& set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])

ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}




#separation interval s=30#
cluster30<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (31):length(set))
{
if(set[i-30]>threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=31#
cluster31<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (32):length(set))
{
if(set[i-31]>threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=32#
cluster32<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (33):length(set))
{
if(set[i-32]>threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=33#
cluster33<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (34):length(set))
{
if(set[i-33]>threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=34#
cluster34<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (35):length(set))
{
if(set[i-34]>threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=35#
cluster35<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (36):length(set))
{
if(set[i-35]>threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=36#
cluster36a<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (37):length(set))
{
if(set[i-36]>threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=36#
cluster36<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (37):length(set))
{
if(set[i-36]>threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=37#
cluster37<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (38):length(set))
{
if(set[i-37]>threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=38#
cluster38<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (39):length(set))
{
if(set[i-38]>threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=39#
cluster39<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (40):length(set))
{
if(set[i-39]>threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=40#
cluster40<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (41):length(set))
{
if(set[i-40]>threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=41#
cluster41<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (42):length(set))
{
if(set[i-41]>threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=42#
cluster42<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (43):length(set))
{
if(set[i-42]>threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=43#
cluster43<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (44):length(set))
{
if(set[i-43]>threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=44#
cluster44<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (45):length(set))
{
if(set[i-44]>threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=45#
cluster45<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (46):length(set))
{
if(set[i-45]>threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=46#
cluster46<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (47):length(set))
{
if(set[i-46]>threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=47#
cluster47<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (48):length(set))
{
if(set[i-47]>threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=48#
cluster48<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (49):length(set))
{
if(set[i-48]>threshold
& set[i-47]<=threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=49#
cluster49<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (50):length(set))
{
if(set[i-49]>threshold
& set[i-48]<=threshold
& set[i-47]<=threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=50#
cluster50<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (51):length(set))
{
if(set[i-50]>threshold
& set[i-49]<=threshold
& set[i-48]<=threshold
& set[i-47]<=threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=20#
cluster20<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (21):length(set))
{
if(set[i-20]>threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
 & set[i-13]<=threshold & set[i-12]<=threshold
 & set[i-11]<=threshold & set[i-10]<=threshold
 & set[i-9]<=threshold & set[i-8]<=threshold
 & set[i-7]<=threshold & set[i-6]<=threshold
 & set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold & set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=51#
cluster51<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (52):length(set))
{
if(set[i-51]>threshold
& set[i-50]<=threshold
& set[i-49]<=threshold
& set[i-48]<=threshold
& set[i-47]<=threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=52#
cluster52<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (53):length(set))
{
if(set[i-52]>threshold
& set[i-51]<=threshold
& set[i-50]<=threshold
& set[i-49]<=threshold
& set[i-48]<=threshold
& set[i-47]<=threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=53#
cluster53<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (54):length(set))
{
if(set[i-53]>threshold
& set[i-52]<=threshold
& set[i-51]<=threshold
& set[i-50]<=threshold
& set[i-49]<=threshold
& set[i-48]<=threshold
& set[i-47]<=threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=54#
cluster54<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (55):length(set))
{
if(set[i-54]>threshold
& set[i-53]<=threshold
& set[i-52]<=threshold
& set[i-51]<=threshold
& set[i-50]<=threshold
& set[i-49]<=threshold
& set[i-48]<=threshold
& set[i-47]<=threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=55#
cluster55<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (56):length(set))
{
if(set[i-55]>threshold
& set[i-54]<=threshold
& set[i-53]<=threshold
& set[i-52]<=threshold
& set[i-51]<=threshold
& set[i-50]<=threshold
& set[i-49]<=threshold
& set[i-48]<=threshold
& set[i-47]<=threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=56#
cluster56<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (57):length(set))
{
if(set[i-56]>threshold
& set[i-55]<=threshold
& set[i-54]<=threshold
& set[i-54]<=threshold
& set[i-53]<=threshold
& set[i-52]<=threshold
& set[i-51]<=threshold
& set[i-50]<=threshold
& set[i-49]<=threshold
& set[i-48]<=threshold
& set[i-47]<=threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=57#
cluster57<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (58):length(set))
{
if(set[i-57]>threshold
& set[i-56]<=threshold
& set[i-55]<=threshold
& set[i-54]<=threshold
& set[i-54]<=threshold
& set[i-53]<=threshold
& set[i-52]<=threshold
& set[i-51]<=threshold
& set[i-50]<=threshold
& set[i-49]<=threshold
& set[i-48]<=threshold
& set[i-47]<=threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=58#
cluster58<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (59):length(set))
{
if(set[i-58]>threshold
& set[i-57]<=threshold
& set[i-56]<=threshold
& set[i-55]<=threshold
& set[i-54]<=threshold
& set[i-54]<=threshold
& set[i-53]<=threshold
& set[i-52]<=threshold
& set[i-51]<=threshold
& set[i-50]<=threshold
& set[i-49]<=threshold
& set[i-48]<=threshold
& set[i-47]<=threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}


#separation interval s=59#
cluster59<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (60):length(set))
{
if(set[i-59]>threshold
& set[i-58]<=threshold
& set[i-57]<=threshold
& set[i-56]<=threshold
& set[i-55]<=threshold
& set[i-54]<=threshold
& set[i-54]<=threshold
& set[i-53]<=threshold
& set[i-52]<=threshold
& set[i-51]<=threshold
& set[i-50]<=threshold
& set[i-49]<=threshold
& set[i-48]<=threshold
& set[i-47]<=threshold
& set[i-46]<=threshold
& set[i-45]<=threshold
& set[i-44]<=threshold
& set[i-43]<=threshold
& set[i-42]<=threshold
& set[i-41]<=threshold
& set[i-40]<=threshold
& set[i-39]<=threshold
& set[i-38]<=threshold
& set[i-37]<=threshold
& set[i-36]<=threshold
& set[i-35]<=threshold
& set[i-34]<=threshold
& set[i-33]<=threshold
& set[i-32]<=threshold
& set[i-31]<=threshold
& set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
& set[i-13]<=threshold & set[i-12]<=threshold
& set[i-11]<=threshold & set[i-10]<=threshold
& set[i-9]<=threshold & set[i-8]<=threshold
& set[i-7]<=threshold & set[i-6]<=threshold
& set[i-5]<=threshold & set[i-4]<=threshold
& set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}







#separation interval s=60#
cluster60<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (61):length(set))
{
if(set[i-60]>threshold
 & set[i-59]<=threshold & set[i-58]<=threshold
 & set[i-57]<=threshold & set[i-56]<=threshold
 & set[i-55]<=threshold & set[i-54]<=threshold
 & set[i-53]<=threshold & set[i-52]<=threshold
 & set[i-51]<=threshold & set[i-50]<=threshold
 & set[i-49]<=threshold & set[i-48]<=threshold
 & set[i-47]<=threshold & set[i-46]<=threshold
 & set[i-45]<=threshold & set[i-44]<=threshold
 & set[i-43]<=threshold & set[i-42]<=threshold
 & set[i-41]<=threshold & set[i-40]<=threshold
 & set[i-39]<=threshold & set[i-38]<=threshold
 & set[i-37]<=threshold & set[i-36]<=threshold
 & set[i-35]<=threshold & set[i-34]<=threshold
 & set[i-33]<=threshold & set[i-32]<=threshold
 & set[i-31]<=threshold
 & set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
 & set[i-13]<=threshold & set[i-12]<=threshold
 & set[i-11]<=threshold & set[i-10]<=threshold
 & set[i-9]<=threshold & set[i-8]<=threshold
 & set[i-7]<=threshold & set[i-6]<=threshold
 & set[i-5]<=threshold & set[i-4]<=threshold
 & set[i-3]<=threshold & set[i-2]<=threshold
& set[i-1]<=threshold
& set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#separation interval s=100#
cluster100<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (101):length(set))
{if(set[i-100]>threshold
 & set[i-99]<=threshold & set[i-98]<=threshold
 & set[i-97]<=threshold & set[i-96]<=threshold
 & set[i-95]<=threshold & set[i-94]<=threshold
 & set[i-93]<=threshold & set[i-92]<=threshold
 & set[i-91]<=threshold & set[i-90]<=threshold
 & set[i-89]<=threshold & set[i-88]<=threshold
 & set[i-87]<=threshold & set[i-86]<=threshold
 & set[i-85]<=threshold & set[i-84]<=threshold
 & set[i-83]<=threshold & set[i-82]<=threshold
 & set[i-81]<=threshold & set[i-80]<=threshold
 & set[i-79]<=threshold & set[i-78]<=threshold
 & set[i-77]<=threshold & set[i-76]<=threshold
 & set[i-75]<=threshold & set[i-74]<=threshold
 & set[i-73]<=threshold & set[i-72]<=threshold
 & set[i-71]<=threshold
 & set[i-70]<=threshold
 & set[i-69]<=threshold & set[i-68]<=threshold
 & set[i-67]<=threshold & set[i-66]<=threshold
 & set[i-65]<=threshold & set[i-64]<=threshold
 & set[i-63]<=threshold & set[i-62]<=threshold
 & set[i-61]<=threshold & set[i-60]<=threshold
 & set[i-59]<=threshold & set[i-58]<=threshold
 & set[i-57]<=threshold & set[i-56]<=threshold
 & set[i-55]<=threshold & set[i-54]<=threshold
 & set[i-53]<=threshold & set[i-52]<=threshold
 & set[i-51]<=threshold & set[i-50]<=threshold
 & set[i-49]<=threshold & set[i-48]<=threshold
 & set[i-47]<=threshold & set[i-46]<=threshold
 & set[i-45]<=threshold & set[i-44]<=threshold
 & set[i-43]<=threshold & set[i-42]<=threshold
 & set[i-41]<=threshold & set[i-40]<=threshold
 & set[i-39]<=threshold & set[i-38]<=threshold
 & set[i-37]<=threshold & set[i-36]<=threshold
 & set[i-35]<=threshold & set[i-34]<=threshold
 & set[i-33]<=threshold & set[i-32]<=threshold
 & set[i-31]<=threshold
 & set[i-30]<=threshold
 & set[i-29]<=threshold & set[i-28]<=threshold
 & set[i-27]<=threshold & set[i-26]<=threshold
 & set[i-25]<=threshold & set[i-24]<=threshold
 & set[i-23]<=threshold & set[i-22]<=threshold
 & set[i-21]<=threshold & set[i-20]<=threshold
 & set[i-19]<=threshold & set[i-18]<=threshold
 & set[i-17]<=threshold & set[i-16]<=threshold
 & set[i-15]<=threshold & set[i-14]<=threshold
 & set[i-13]<=threshold & set[i-12]<=threshold
 & set[i-11]<=threshold & set[i-10]<=threshold
 & set[i-9]<=threshold & set[i-8]<=threshold
 & set[i-7]<=threshold & set[i-6]<=threshold
 & set[i-5]<=threshold & set[i-4]<=threshold
 & set[i-3]<=threshold & set[i-2]<=threshold
 & set[i-1]<=threshold
 & set[i]<=threshold)
{
x<-max(set[j:i])
ifelse(i !=length(set), j<-i+1, NA)
z<-c(z,x)
}}}
z
}

#Function which declusters using first cluster observation - here we have s=20#
first.cluster<-function(set,threshold)
{
x<-list()
z<-list()
j<-1
{
for(i in (21):length(set))
{
if(set[i-20]>threshold & set[i-19]<=threshold
& set[i-18]<=threshold & set[i-17]<=threshold
& set[i-16]<=threshold & set[i-15]<=threshold
& set[i-14]<=threshold & set[i-13]<=threshold
& set[i-12]<=threshold & set[i-11]<=threshold
& set[i-10]<=threshold & set[i-9]<=threshold
& set[i-8]<=threshold & set[i-7]<=threshold
& set[i-6]<=threshold & set[i-5]<=threshold
& set[i-4]<=threshold & set[i-3]<=threshold
& set[i-2]<=threshold & set[i-1]<=threshold
&set[i]<=threshold)
{
x<-set[i-20]
z<-c(z,x)
}}}
z
}

#Function to decluster using Ferro & Segers' method#
ferrocluster<-function(set,threshold)
{
n<-length(set)
p<-vector("numeric",n)
for(i in 1:n)
{
if(set[i]<threshold){p[i]<-0}
if(set[i]>=threshold){p[i]<-i}
}
S<-p[p>0]
m<-length(S)
l<-m-1
T<-vector("numeric",l)
for(i in 1:l)
{
T[i]<-S[i+1]-S[i]
}
U<-T-1
U1<-sum(U)
U2<-U1**(2)
numerator<-2*U2
V<-T-2
V1<-U*V
V2<-sum(V1)
denominator<-l*V2
extremal.index<-numerator/denominator
if(extremal.index>1){extremal.index<-0.99999}

return(extremal.index)
}

#Function to decluster using Ferro & Segers' method#
ferrocluster2<-function(set,threshold)
{
n<-length(set)
p<-vector("numeric",n)
for(i in 1:n)
{
if(set[i]<threshold){p[i]<-0}
if(set[i]>=threshold){p[i]<-i}
}
S<-p[p>0]
m<-length(S)
l<-m-1
T<-vector("numeric",l)
for(i in 1:l)
{
T[i]<-S[i+1]-S[i]
}
U<-T-1
U1<-sum(U)
U2<-U1**(2)
numerator<-2*U2
V<-T-2
V1<-U*V
V2<-sum(V1)
denominator<-l*V2
extremal.index<-numerator/denominator
C<-m*extremal.index
Cfloor<-length(integer(C))
T1<-sort(T)
maxim<-vector("numeric",Cfloor)
for(i in 1:Cfloor)
{
maxim[i]<-T1[l-(i-1)]
s<-min(maxim)
}
if(s==1){peaks<-as.vector(cluster1(set,threshold),mode="numeric")}
if(s==2){peaks<-as.vector(cluster2(set,threshold),mode="numeric")}
if(s==3){peaks<-as.vector(cluster3(set,threshold),mode="numeric")}
if(s==4){peaks<-as.vector(cluster4(set,threshold),mode="numeric")}
if(s==5){peaks<-as.vector(cluster5(set,threshold),mode="numeric")}
if(s==6){peaks<-as.vector(cluster6(set,threshold),mode="numeric")}
if(s==7){peaks<-as.vector(cluster7(set,threshold),mode="numeric")}
if(s==8){peaks<-as.vector(cluster8(set,threshold),mode="numeric")}
if(s==9){peaks<-as.vector(cluster9(set,threshold),mode="numeric")}
if(s==10){peaks<-as.vector(cluster10(set,threshold),mode="numeric")}
if(s==11){peaks<-as.vector(cluster11(set,threshold),mode="numeric")}
if(s==12){peaks<-as.vector(cluster12(set,threshold),mode="numeric")}
if(s==13){peaks<-as.vector(cluster13(set,threshold),mode="numeric")}
if(s==14){peaks<-as.vector(cluster14(set,threshold),mode="numeric")}
if(s==15){peaks<-as.vector(cluster15(set,threshold),mode="numeric")}
return(extremal.index,Cfloor,maxim,s,peaks,l)
}


#Function to produce mean excess (mean residual life) plot (for all excesses)#
mrl.plot<-function(dataset, umin=min(dataset),umax=max(dataset)-1,nint=500)
{
x<-NULL
u<-seq(umin,umax,length=nint)
for(i in 1:nint)
{
dataset<-dataset[dataset>u[i]]
x[i]<-mean(dataset-u[i])
sdev<-sqrt(var(dataset))
n<-length(dataset)
}
plot(u,x,type="p",pch=4,xlab="threshold",ylab="mean excess",main="Mean residual life plot : all excesses")
}

mrl.plot2<-function(dataset, umin=min(dataset),umax=max(dataset)-1,nint=300)
{
x<-NULL
u<-seq(umin,umax,length=nint)
for(i in 1:nint)
{
dataset<-dataset[dataset>u[i]]
x[i]<-mean(dataset-u[i])
sdev<-sqrt(var(dataset))
n<-length(dataset)
}
plot(u,x,type="p",pch=4,xlab="threshold",ylab="mean excess",main="Mean residual life plot: cluster peak excesses (kappa=30)",xlim=c(2.69,4.5),ylim=c(1.2,1.75))
}

#Function to produce reclustered excess plot#
reclustered.excess.plot<-function(data, umin=min(data),umax=max(data)-1,nint=2000)
{
x<-NULL
u<-seq(umin,umax,length=nint)
for(i in 1:nint)
{
test<-cluster(data,u[i])
if(length(test)==0)
{x[i]<-max(data)-u[i]}
if(length(test)>0)
{
test1<-as.vector(test,mode="numeric")
x[i]<-mean(test1-u[i])
    }
}
plot(u,x,pch=20,xlab="threshold",ylab="mean excess",main="interval = 5 hours")
}

#Function to fit a bivariate Markov chain model to threshold exceedances (based on the logistic model).  #
#First, the data must be called "set"#
#Then, the threshold must be fixed: threshold<-????#
#Then you need to fix theta: theta<-as.numeric(c(sqrt(var(set)),0.1))#
f<-function(theta)
{
N<-length(set)
Z<-vector("numeric",N)
K<-vector("numeric",N)
L<-vector("numeric",N-1)
M<-vector("numeric",N-2)
indicator<-vector("numeric",N)
X<-vector("numeric",N)
SIGMA<-theta[1]
XI<-theta[2]
a<-theta[3]
n<-N-1
test1<-set-threshold
all.exceedances<-test1[test1>0]
lambda<-length(all.exceedances)/N
for(i in 1:N)
{
if(set[i]<threshold){indicator[i]<-0}
if(set[i]>=threshold){indicator[i]<-1}
X[i]<-indicator[i]*(set[i]-threshold)
if((1+XI*(X[i])/SIGMA)>=0){p<-(1+XI*(X[i])/SIGMA)}
else(p<-0)
if(min(SIGMA)<0.00001)return(as.double(1000000))
Z[i]<-lambda^(-1)*(p^(1/(XI)))
K[i]<-(-((lambda)^(-XI)))*(SIGMA^(-1))*(Z[i]^(1-XI))
}
lee<-matrix(ncol=2,nrow=n)
for(i in 1:n)
{
lee[i,1]<-set[i]
lee[i,2]<-set[i+1]
if(lee[i,1]<threshold){if(lee[i,2]<threshold){L[i]<-1-((((lambda)^(1/a))+((lambda)^(1/a)))^(a))}}
if(lee[i,1]>=threshold){if(lee[i,2]>=threshold){L[i]<-K[i]*K[i+1]*(1-a)*((((Z[i])^(-1/a))+((Z[i+1])^(-1/a)))^(a-2))*(((Z[i])*(Z[i+1]))^((-1/a)-1))}}
if(lee[i,1]<threshold){if(lee[i,2]>=threshold){L[i]<-K[i+1]*-(((lambda^(1/a))+((Z[i+1])^(-1/a)))^(a-1))*((Z[i+1])^((-1/a)-1))}}
if(lee[i,1]>=threshold){if(lee[i,2]<threshold){L[i]<-K[i]*-((((Z[i])^(-1/a))+(lambda^(1/a)))^(a-1))*((Z[i])^((-1/a)-1))}}
}
l<-sum(log(L))
M[1]<-1
for(i in 2:n)
{
if((1+(XI*(set[i]-threshold)/SIGMA))>=0){q<-1+(XI*(set[i]-threshold)/SIGMA)}
else(q<-0)
if(set[i]>threshold){M[i]<-(SIGMA^(-1))*lambda*(q^((-1/XI)-1))}
else(M[i]<-1-lambda)
m<-sum(log(M))
}
nllh<--(l-m)
nllh
}
#Then use nlm(f,theta) to obtain MLEs for the model#

#The big simulation study!#
simulation.study2<-
function(N,n,threshold,x,a,sigma,xi)
{
SIGMA<-vector("numeric",N)
XI<-vector("numeric",N)
PSIGMA<-vector("numeric",N)
PXI<-vector("numeric",N)
FSIGMA<-vector("numeric",N)
FXI<-vector("numeric",N)
exceedance.rate<-vector("numeric",N)
p.exceedance.rate<-vector("numeric",N)
f.exceedance.rate<-vector("numeric",N)
return.level<-vector("numeric",N)
p.return.level<-vector("numeric",N)
f.return.level<-vector("numeric",N)
lambda<-vector("numeric",N)
p.lambda<-vector("numeric",N)
f.lambda<-vector("numeric",N)
sigma.se<-vector("numeric",N)
p.sigma.se<-vector("numeric",N)
f.sigma.se<-vector("numeric",N)
xi.se<-vector("numeric",N)
p.xi.se<-vector("numeric",N)
f.xi.se<-vector("numeric",N)
ret.se<-vector("numeric",N)
p.ret.se<-vector("numeric",N)
f.ret.se<-vector("numeric",N)
means<-vector("numeric",24)
medians<-vector("numeric",24)
standard.deviations<-vector("numeric",15)
LQ1<-vector("numeric",15)
UQ1<-vector("numeric",15)
LQ2<-vector("numeric",15)
UQ2<-vector("numeric",15)
for(i in 1:N)
{
test<-corrgpd.3(n,a,sigma,xi)
test1<-test-threshold
all.exceedances<-test1[test1>0]
p<-mle.gpd7(all.exceedances)
SIGMA[i]<-p$zz
XI[i]<-p$zzz
lambda[i]<-length(all.exceedances)/n
t<-(XI[i]*(x-threshold))/SIGMA[i]
t1<-(1+t)
if(t1<0)
exceedance.rate[i]<-0
else exceedance.rate[i]<-lambda[i]*(t1^(-1/XI[i]))
u<-(0.001/lambda[i])^(-XI[i])
u1<-(SIGMA[i]/XI[i])*(u-1)
return.level[i]<-threshold+u1

sigma.se[i]<-sqrt(p$varcovar[1,1])
xi.se[i]<-sqrt(p$varcovar[2,2])
V<-matrix(ncol=3,nrow=3)
V[1,1]<-lambda[i]*(1-lambda[i])/n
V[1,2]<-0
V[1,3]<-0
V[2,1]<-0
V[3,1]<-0
V[2,2]<-p$varcovar[1,1]
V[2,3]<-p$varcovar[1,2]
V[3,2]<-p$varcovar[2,1]
V[3,3]<-p$varcovar[2,2]
diff1<-SIGMA[i]*1000^(XI[i])*lambda[i]^(XI[i]-1)
diff2<-(XI[i]^(-1))*(((1000*lambda[i])^(XI[i]))-1)
diff3<--(SIGMA[i])*XI[i]^(-2)*(((1000*lambda[i])^(XI[i]))-1) + SIGMA[i]*(XI[i]^(-1))*((1000*lambda[i])^(XI[i]))*log(1000*lambda[i])
del.t<-matrix(ncol=3,nrow=1)
del.t[1,1]<-diff1
del.t[1,2]<-diff2
del.t[1,3]<-diff3
del<-matrix(ncol=1,nrow=3)
del[1,1]<-diff1
del[2,1]<-diff2
del[3,1]<-diff3
A<-matrix(ncol=3,nrow=1)
A[1,1]<-del.t[1,1]*V[1,1]
A[1,2]<-(del.t[1,2]*V[2,2])+(del.t[1,3]*V[3,2])
A[1,3]<-(del.t[1,2]*V[2,3])+(del.t[1,3]*V[3,3])
ret.var<-(A[1,1]*diff1) + (A[1,2]*diff2) + (A[1,3]*diff3)
ret.se[i]<-sqrt(ret.var)
ferro<-ferrocluster(test,threshold)
cluster.peaks<-ferro$peaks-threshold
q<-mle.gpd7(cluster.peaks)
PSIGMA[i]<-q$zz
PXI[i]<-q$zzz
p.lambda[i]<-length(cluster.peaks)/n
v<-(PXI[i]*(x-threshold))/PSIGMA[i]
v1<-(1+v)
if(v1<0)
p.exceedance.rate[i]<-0
else p.exceedance.rate[i]<-p.lambda[i]*(v1^(-1/PXI[i]))
w<-(0.001/p.lambda[i])^(-PXI[i])
w1<-(PSIGMA[i]/PXI[i])*(w-1)
p.return.level[i]<-threshold+w1
p.sigma.se[i]<-sqrt(q$varcovar[1,1])
p.xi.se[i]<-sqrt(q$varcovar[2,2])
V1<-matrix(ncol=3,nrow=3)
V1[1,1]<-p.lambda[i]*(1-p.lambda[i])/n
V1[1,2]<-0
V1[1,3]<-0
V1[2,1]<-0
V1[3,1]<-0
V1[2,2]<-q$varcovar[1,1]
V1[2,3]<-q$varcovar[1,2]
V1[3,2]<-q$varcovar[2,1]
V1[3,3]<-q$varcovar[2,2]
diff4<-PSIGMA[i]*1000^(PXI[i])*p.lambda[i]^(PXI[i]-1)
diff5<-(PXI[i]^(-1))*(((1000*p.lambda[i])^(PXI[i]))-1)
diff6<--(PSIGMA[i])*PXI[i]^(-2)*(((1000*p.lambda[i])^(PXI[i]))-1) + PSIGMA[i]*(PXI[i]^(-1))*((1000*p.lambda[i])^(PXI[i]))*log(1000*p.lambda[i])
del2.t<-matrix(ncol=3,nrow=1)
del2.t[1,1]<-diff4
del2.t[1,2]<-diff5
del2.t[1,3]<-diff6
del2<-matrix(ncol=1,nrow=3)
del2[1,1]<-diff4
del2[2,1]<-diff5
del2[3,1]<-diff6
A1<-matrix(ncol=3,nrow=1)
A1[1,1]<-del2.t[1,1]*V1[1,1]
A1[1,2]<-(del2.t[1,2]*V1[2,2])+(del2.t[1,3]*V1[3,2])
A1[1,3]<-(del2.t[1,2]*V1[2,3])+(del2.t[1,3]*V1[3,3])
p.ret.se[i]<-sqrt((A1[1,1]*diff4) + (A1[1,2]*diff5) + (A1[1,3]*diff6))
test4<-as.vector(cluster5(test,threshold),mode="numeric")
test5<-test4-threshold
first.cluster.values<-test5[test5>0]
s<-mle.gpd7(first.cluster.values)
FSIGMA[i]<-s$zz
FXI[i]<-s$zzz
f.lambda[i]<-length(first.cluster.values)/n
y<-(FXI[i]*(x-threshold))/FSIGMA[i]
y1<-(1+y)
if(y1<0)
f.exceedance.rate[i]<-0
else f.exceedance.rate[i]<-f.lambda[i]*(y1^(-1/FXI[i]))
z<-(0.001/f.lambda[i])^(-FXI[i])
z1<-(FSIGMA[i]/FXI[i])*(z-1)
f.return.level[i]<-threshold+z1
f.sigma.se[i]<-sqrt(s$varcovar[1,1])
f.xi.se[i]<-sqrt(s$varcovar[2,2])
V2<-matrix(ncol=3,nrow=3)
V2[1,1]<-f.lambda[i]*(1-f.lambda[i])/n
V2[1,2]<-0
V2[1,3]<-0
V2[2,1]<-0
V2[3,1]<-0
V2[2,2]<-s$varcovar[1,1]
V2[2,3]<-s$varcovar[1,2]
V2[3,2]<-s$varcovar[2,1]
V2[3,3]<-s$varcovar[2,2]
diff7<-FSIGMA[i]*1000^(FXI[i])*f.lambda[i]^(FXI[i]-1)
diff8<-(FXI[i]^(-1))*(((1000*f.lambda[i])^(FXI[i]))-1)
diff9<--(FSIGMA[i])*FXI[i]^(-2)*(((1000*f.lambda[i])^(FXI[i]))-1) + FSIGMA[i]*(FXI[i]^(-1))*((1000*f.lambda[i])^(FXI[i]))*log(1000*f.lambda[i])
del3.t<-matrix(ncol=3,nrow=1)
del3.t[1,1]<-diff7
del3.t[1,2]<-diff8
del3.t[1,3]<-diff9
del3<-matrix(ncol=1,nrow=3)
del3[1,1]<-diff7
del3[2,1]<-diff8
del3[3,1]<-diff9
A2<-matrix(ncol=3,nrow=1)
A2[1,1]<-del3.t[1,1]*V2[1,1]
A2[1,2]<-(del3.t[1,2]*V2[2,2])+(del3.t[1,3]*V2[3,2])
A2[1,3]<-(del3.t[1,2]*V2[2,3])+(del3.t[1,3]*V2[3,3])
f.ret.se[i]<-sqrt((A2[1,1]*diff7) + (A2[1,2]*diff8) + (A2[1,3]*diff9))
}
means[1]<-mean(SIGMA)
means[2]<-mean(XI)
means[3]<-mean(exceedance.rate)
means[4]<-mean(return.level)
means[5]<-mean(lambda)
means[6]<-mean(PSIGMA)
means[7]<-mean(PXI)
means[8]<-mean(p.exceedance.rate)
means[9]<-mean(p.return.level)
means[10]<-mean(p.lambda)
means[11]<-mean(FSIGMA)
means[12]<-mean(FXI)
means[13]<-mean(f.exceedance.rate)
means[14]<-mean(f.return.level)
means[15]<-mean(f.lambda)
means[16]<-mean(sigma.se)
means[17]<-mean(xi.se)
means[18]<-mean(ret.se)
means[19]<-mean(p.sigma.se)
means[20]<-mean(p.xi.se)
means[21]<-mean(p.ret.se)
means[22]<-mean(f.sigma.se)
means[23]<-mean(f.xi.se)
means[24]<-mean(f.ret.se)
medians[1]<-median(SIGMA)
medians[2]<-median(XI)
medians[3]<-median(exceedance.rate)
medians[4]<-median(return.level)
medians[5]<-median(lambda)
medians[6]<-median(PSIGMA)
medians[7]<-median(PXI)
medians[8]<-median(p.exceedance.rate)
medians[9]<-median(p.return.level)
medians[10]<-median(p.lambda)
medians[11]<-median(FSIGMA)
medians[12]<-median(FXI)
medians[13]<-median(f.exceedance.rate)
medians[14]<-median(f.return.level)
medians[15]<-median(f.lambda)
medians[16]<-median(sigma.se)
medians[17]<-median(xi.se)
medians[18]<-median(ret.se)
medians[19]<-median(p.sigma.se)
medians[20]<-median(p.xi.se)
medians[21]<-median(p.ret.se)
medians[22]<-median(f.sigma.se)
medians[23]<-median(f.xi.se)
medians[24]<-median(f.ret.se)
standard.deviations[1]<-sqrt(var(SIGMA))
standard.deviations[2]<-sqrt(var(XI))
standard.deviations[3]<-sqrt(var(exceedance.rate))
standard.deviations[4]<-sqrt(var(return.level))
standard.deviations[5]<-sqrt(var(lambda))
standard.deviations[6]<-sqrt(var(PSIGMA))
standard.deviations[7]<-sqrt(var(PXI))
standard.deviations[8]<-sqrt(var(p.exceedance.rate))
standard.deviations[9]<-sqrt(var(p.return.level))
standard.deviations[10]<-sqrt(var(p.lambda))
standard.deviations[11]<-sqrt(var(FSIGMA))
standard.deviations[12]<-sqrt(var(FXI))
standard.deviations[13]<-sqrt(var(f.exceedance.rate))
standard.deviations[14]<-sqrt(var(f.return.level))
standard.deviations[15]<-sqrt(var(f.lambda))
SORT.SIGMA<-sort(SIGMA)
SORT.XI<-sort(XI)
SORT.PSIGMA<-sort(PSIGMA)
SORT.PXI<-sort(PXI)
SORT.FSIGMA<-sort(FSIGMA)
SORT.FXI<-sort(FXI)
SORT.exceedance.rate<-sort(exceedance.rate)
SORT.p.exceedance.rate<-sort(p.exceedance.rate)
SORT.f.exceedance.rate<-sort(f.exceedance.rate)
SORT.return.level<-sort(return.level)
SORT.p.return.level<-sort(p.return.level)
SORT.f.return.level<-sort(f.return.level)
SORT.lambda<-sort(lambda)
SORT.p.lambda<-sort(p.lambda)
SORT.f.lambda<-sort(f.lambda)
LQ1[1]<-((SORT.SIGMA[7]-SORT.SIGMA[6])/4)+SORT.SIGMA[6]
UQ1[1]<-SORT.SIGMA[245]-((SORT.SIGMA[245]-SORT.SIGMA[244])/4)
LQ2[1]<-((SORT.SIGMA[2]-SORT.SIGMA[1])/4)+SORT.SIGMA[1]
UQ2[1]<-SORT.SIGMA[250]-((SORT.SIGMA[250]-SORT.SIGMA[249])/4)
LQ1[2]<-((SORT.XI[7]-SORT.XI[6])/4)+SORT.XI[6]
UQ1[2]<-SORT.XI[245]-((SORT.XI[245]-SORT.XI[244])/4)
LQ2[2]<-((SORT.XI[2]-SORT.XI[1])/4)+SORT.XI[1]
UQ2[2]<-SORT.XI[250]-((SORT.XI[250]-SORT.XI[249])/4)
LQ1[3]<-((SORT.exceedance.rate[7]-SORT.exceedance.rate[6])/4)+SORT.exceedance.rate[6]
UQ1[3]<-SORT.exceedance.rate[245]-((SORT.exceedance.rate[245]-SORT.exceedance.rate[244])/4)
LQ2[3]<-((SORT.exceedance.rate[2]-SORT.exceedance.rate[1])/4)+SORT.exceedance.rate[1]
UQ2[3]<-SORT.exceedance.rate[250]-((SORT.exceedance.rate[250]-SORT.exceedance.rate[249])/4)
LQ1[4]<-((SORT.return.level[7]-SORT.return.level[6])/4)+SORT.return.level[6]
UQ1[4]<-SORT.return.level[245]-((SORT.return.level[245]-SORT.return.level[244])/4)
LQ2[4]<-((SORT.return.level[2]-SORT.return.level[1])/4)+SORT.return.level[1]
UQ2[4]<-SORT.return.level[250]-((SORT.return.level[250]-SORT.return.level[249])/4)
LQ1[5]<-((SORT.lambda[7]-SORT.lambda[6])/4)+SORT.lambda[6]
UQ1[5]<-SORT.lambda[245]-((SORT.lambda[245]-SORT.lambda[244])/4)
LQ2[5]<-((SORT.lambda[2]-SORT.lambda[1])/4)+SORT.lambda[1]
UQ2[5]<-SORT.lambda[250]-((SORT.lambda[250]-SORT.lambda[249])/4)
LQ1[6]<-((SORT.PSIGMA[7]-SORT.PSIGMA[6])/4)+SORT.PSIGMA[6]
UQ1[6]<-SORT.PSIGMA[245]-((SORT.PSIGMA[245]-SORT.PSIGMA[244])/4)  
LQ2[6]<-((SORT.PSIGMA[2]-SORT.PSIGMA[1])/4)+SORT.PSIGMA[1]
UQ2[6]<-SORT.PSIGMA[250]-((SORT.PSIGMA[250]-SORT.PSIGMA[249])/4)
LQ1[7]<-((SORT.PXI[7]-SORT.PXI[6])/4)+SORT.PXI[6]
UQ1[7]<-SORT.PXI[245]-((SORT.PXI[245]-SORT.PXI[244])/4)
LQ2[7]<-((SORT.PXI[2]-SORT.PXI[1])/4)+SORT.PXI[1]
UQ2[7]<-SORT.PXI[250]-((SORT.PXI[250]-SORT.PXI[249])/4)
LQ1[8]<-((SORT.p.exceedance.rate[7]-SORT.p.exceedance.rate[6])/4)+SORT.p.exceedance.rate[6]
UQ1[8]<-SORT.p.exceedance.rate[245]-((SORT.p.exceedance.rate[245]-SORT.p.exceedance.rate[244])/4)
LQ2[8]<-((SORT.p.exceedance.rate[2]-SORT.p.exceedance.rate[1])/4)+SORT.p.exceedance.rate[1]
UQ2[8]<-SORT.p.exceedance.rate[250]-((SORT.p.exceedance.rate[250]-SORT.p.exceedance.rate[249])/4)
LQ1[9]<-((SORT.p.return.level[7]-SORT.p.return.level[6])/4)+SORT.p.return.level[6]
UQ1[9]<-SORT.p.return.level[245]-((SORT.p.return.level[245]-SORT.p.return.level[244])/4)
LQ2[9]<-((SORT.p.return.level[2]-SORT.p.return.level[1])/4)+SORT.p.return.level[1]
UQ2[9]<-SORT.p.return.level[250]-((SORT.p.return.level[250]-SORT.p.return.level[249])/4)
LQ1[10]<-((SORT.p.lambda[7]-SORT.p.lambda[6])/4)+SORT.p.lambda[6]
UQ1[10]<-SORT.p.lambda[245]-((SORT.p.lambda[245]-SORT.p.lambda[244])/4)
LQ2[10]<-((SORT.p.lambda[2]-SORT.p.lambda[1])/4)+SORT.p.lambda[1]
UQ2[10]<-SORT.p.lambda[250]-((SORT.p.lambda[250]-SORT.p.lambda[249])/4)
LQ1[11]<-((SORT.FSIGMA[7]-SORT.FSIGMA[6])/4)+SORT.FSIGMA[6]
UQ1[11]<-SORT.FSIGMA[245]-((SORT.FSIGMA[245]-SORT.FSIGMA[244])/4)
LQ2[11]<-((SORT.FSIGMA[2]-SORT.FSIGMA[1])/4)+SORT.FSIGMA[1]
UQ2[11]<-SORT.FSIGMA[250]-((SORT.FSIGMA[250]-SORT.FSIGMA[249])/4)
LQ1[12]<-((SORT.FXI[7]-SORT.FXI[6])/4)+SORT.FXI[6]
UQ1[12]<-SORT.FXI[245]-((SORT.FXI[245]-SORT.FXI[244])/4)
LQ2[12]<-((SORT.FXI[2]-SORT.FXI[1])/4)+SORT.FXI[1]
UQ2[12]<-SORT.FXI[250]-((SORT.FXI[250]-SORT.FXI[249])/4)
LQ1[13]<-((SORT.f.exceedance.rate[7]-SORT.f.exceedance.rate[6])/4)+SORT.f.exceedance.rate[6]
UQ1[13]<-SORT.f.exceedance.rate[245]-((SORT.f.exceedance.rate[245]-SORT.f.exceedance.rate[244])/4)
LQ2[13]<-((SORT.f.exceedance.rate[2]-SORT.f.exceedance.rate[1])/4)+SORT.f.exceedance.rate[1]
UQ2[13]<-SORT.f.exceedance.rate[250]-((SORT.f.exceedance.rate[250]-SORT.f.exceedance.rate[249])/4)
LQ1[14]<-((SORT.f.return.level[7]-SORT.f.return.level[6])/4)+SORT.f.return.level[6]
UQ1[14]<-SORT.f.return.level[245]-((SORT.f.return.level[245]-SORT.f.return.level[244])/4)
LQ2[14]<-((SORT.f.return.level[2]-SORT.f.return.level[1])/4)+SORT.f.return.level[1]
UQ2[14]<-SORT.f.return.level[250]-((SORT.f.return.level[250]-SORT.f.return.level[249])/4)
LQ1[15]<-((SORT.f.lambda[7]-SORT.f.lambda[6])/4)+SORT.f.lambda[6]
UQ1[15]<-SORT.f.lambda[245]-((SORT.f.lambda[245]-SORT.f.lambda[244])/4)
LQ2[15]<-((SORT.f.lambda[2]-SORT.f.lambda[1])/4)+SORT.f.lambda[1]
UQ2[15]<-SORT.f.lambda[250]-((SORT.f.lambda[250]-SORT.f.lambda[249])/4)
ninety.five<-cbind(LQ1,UQ1)
ninety.nine<-cbind(LQ2,UQ2)
return(SIGMA,PSIGMA,FSIGMA,XI,PXI,FXI,exceedance.rate,p.exceedance.rate,f.exceedance.rate,return.level,p.return.level,f.return.level,lambda,p.lambda,f.lambda,means,medians,standard.deviations,ninety.five,ninety.nine,sigma.se,p.sigma.se,f.sigma.se, xi.se,p.xi.se,f.xi.se, ret.se,p.ret.se,f.ret.se)
}

#Function to calculate the number of peaks and troughs for a test of non-randomness#
peaks.troughs<-function(set)
{
N<-length(set)-1
peaks<-vector("numeric",N)
troughs<-vector("numeric",N)
peaks[1]<-0
troughs[1]<-0
for(i in 2:N)
{
if(set[i]>set[i-1] & set[i]>set[i+1]){peaks[i]<-1}
else{peaks[i]<-0}
if(set[i]<set[i-1] & set[i]<set[i+1]){troughs[i]<-1}
else{troughs[i]<-0}
}
T<-sum(peaks)+sum(troughs)
T
}        

#Finds the lower quantile of a dataset#
Quantile<-function(data)
{
a<-0.95*length(data)
lower<-length(integer(a))
higher<-lower+1
diff<-a-lower
incr<-diff*(data[higher]-data[lower])
Q1<-data[lower]+incr
Q1
}

#Finds the upper quantile of a dataset#
Quantile2<-function(data)
{
a<-0.99*length(data)
lower<-length(integer(a))
higher<-lower+1
diff<-a-lower
incr<-diff*(data[higher]-data[lower])
Q2<-data[lower]+incr
Q2
}

#Simulates extremal index based on Smith paper#
smith<-function(N,n,u,a1,a2,a3,a4,sigma,xi)
{
theta<-vector("numeric",4)
indicator1<-vector("numeric",N)
indicator2<-vector("numeric",N)
indicator3<-vector("numeric",N)
indicator4<-vector("numeric",N)
for(i in 1:N)
{
test1<-corrgpd.3(n,a1,sigma,xi)
test2<-corrgpd.3(n,a2,sigma,xi)
test3<-corrgpd.3(n,a3,sigma,xi)
test4<-corrgpd.3(n,a4,sigma,xi)
if(max(test1)<=u){indicator1[i]<-1}
if(max(test1)>u){indicator1[i]<-0}
if(max(test2)<=u){indicator2[i]<-1}
if(max(test2)>u){indicator2[i]<-0}
if(max(test3)<=u){indicator3[i]<-1}
if(max(test3)>u){indicator3[i]<-0}
if(max(test4)<=u){indicator4[i]<-1}
if(max(test4)>u){indicator4[i]<-0}
}
prob1<-sum(indicator1)/N
prob2<-sum(indicator2)/N
prob3<-sum(indicator3)/N
prob4<-sum(indicator4)/N
theta[1]<-((log(prob1))*-1)/(log(2))
theta[2]<-((log(prob2))*-1)/(log(2))
theta[3]<-((log(prob3))*-1)/(log(2))
theta[4]<-((log(prob4))*-1)/(log(2))
theta
}

#Function to produce a simplex plot to test for trivariate Markov appropriateness#
simplex.plot<-function(dataset,sigma,xi,lambda,threshold)
{
N<-length(dataset)
n<-N-2
Ystar<-vector("numeric",N)
R<-vector("numeric",N)
W<-matrix(ncol=3, nrow=N)
for(i in 1:N)
{
Ystar[i]<-(lambda^(-1))*((1+((xi*(dataset[i]-threshold))/sigma))^(1/xi))
}
R[N-1]<-Ystar[N-1]
R[N]<-Ystar[N]
for(i in 1:n)
{
R[i]<-Ystar[i]+Ystar[i+1]+Ystar[i+2]
}
for(i in 1:N)
{
W[i,1]<-Ystar[i]/R[i]
W[i,2]<-Ystar[i+1]/R[i]
W[i,3]<-Ystar[i+2]/R[i]
}
plot(W[i,1]~W[i,3],pch=3,main="Simplex plot",xlab="W[i,1]",ylab="W[i,3]")
}

#Function to produce a return level plot#
ret.lev.plot<-function(dataset,u,n,estall,estpeaks,estmarkov,lambdaall,lambdapeaks,theta)
{
N<-length(dataset)
x<-vector("numeric",N)
Zall<-vector("numeric",N)
Zpeaks<-vector("numeric",N)
Zmarkov<-vector("numeric",N)
for(i in 1:N)
{
x[i]<-log(i)
Zall[i]<-u+(estall[1]/estall[2])*(((x[i]*n*lambdaall)^(estall[2]))-1)
Zpeaks[i]<-u+(estpeaks[1]/estpeaks[2])*(((x[i]*n*lambdapeaks)^(estpeaks[2]))-1)
Zmarkov[i]<-u+(estmarkov[1]/estmarkov[2])*(((x[i]*n*lambdaall)^(estmarkov[2]))-1)
}
plot(Zpeaks~x,type="l",xlim=c(0,10),ylim=c(7.6,9),xlab="-log{-log(1-p)}",ylab="Return level (knots)",main="Return level plots")
lines(Zmarkov~x,type="l",lty=2)
lines(Zall~x,type="l",lwd=2)
}

#Function to decluster a series using Dave's new method#
newcluster<-function(dataset,threshold,s)
{
peaks<-vector("numeric")
n<-length(dataset)
N<-n-1
diff<-vector("numeric",N)
diff2<-vector("numeric",N)
peaks[1]<-max(dataset[(s+1):(n-s)])
for(j in 2:n)
{
for(i in (s+1):(n-s))
{
if(dataset[i]>=peaks[j-1]){dataset[(i-s):(i+s)]<-0}
}
peaks[j]<-max(dataset)
}
for(i in 1:N)
{
diff[i]<-peaks[i+1]-peaks[i]
if(diff[i]>0){diff2[i]<-1}
if(diff[i]<0){diff2[i]<-1}
if(diff[i]==0){diff2[i]<-0}
}
A<-sum(diff2)
B<-A+1
peaks2<-peaks[1:B]
cluster.peak.excesses<-peaks2-threshold
cluster.peak.excesses<-cluster.peak.excesses[cluster.peak.excesses>0]
cluster.peak.excesses
}

#Simulation study - new declustering method#
simulation.study3<-
function(N,n,threshold,x,a,sigma,xi,s)
{
SIGMA<-vector("numeric",N)
XI<-vector("numeric",N)
PSIGMA<-vector("numeric",N)
PXI<-vector("numeric",N)
exceedance.rate<-vector("numeric",N)
p.exceedance.rate<-vector("numeric",N)
return.level<-vector("numeric",N)
p.return.level<-vector("numeric",N)
lambda<-vector("numeric",N)
p.lambda<-vector("numeric",N)
sigma.se<-vector("numeric",N)
p.sigma.se<-vector("numeric",N)
xi.se<-vector("numeric",N)
p.xi.se<-vector("numeric",N)
ret.se<-vector("numeric",N)
p.ret.se<-vector("numeric",N)
means<-vector("numeric",16)
medians<-vector("numeric",16)
standard.deviations<-vector("numeric",10)
for(i in 1:N)
{
test<-corrgpd.3(n,a,sigma,xi)
test1<-test-threshold
all.exceedances<-test1[test1>0]
p<-mle.gpd7(all.exceedances)
SIGMA[i]<-p$estimate[1]
XI[i]<-p$estimate[2]
lambda[i]<-length(all.exceedances)/n
t<-(XI[i]*(x-threshold))/SIGMA[i]
t1<-(1+t)
if(t1<0)
exceedance.rate[i]<-0
else exceedance.rate[i]<-lambda[i]*(t1^(-1/XI[i]))
u<-(0.001/lambda[i])^(-XI[i])
u1<-(SIGMA[i]/XI[i])*(u-1)
return.level[i]<-threshold+u1
sigma.se[i]<-sqrt(p$varcovar[1,1])
xi.se[i]<-sqrt(p$varcovar[2,2])
V<-matrix(ncol=3,nrow=3)
V[1,1]<-lambda[i]*(1-lambda[i])/n
V[1,2]<-0
V[1,3]<-0
V[2,1]<-0
V[3,1]<-0
V[2,2]<-p$varcovar[1,1]
V[2,3]<-p$varcovar[1,2]
V[3,2]<-p$varcovar[2,1]
V[3,3]<-p$varcovar[2,2]
diff1<-SIGMA[i]*1000^(XI[i])*lambda[i]^(XI[i]-1)
diff2<-(XI[i]^(-1))*(((1000*lambda[i])^(XI[i]))-1)
diff3<--(SIGMA[i])*XI[i]^(-2)*(((1000*lambda[i])^(XI[i]))-1) + SIGMA[i]*(XI[i]^(-1))*((1000*lambda[i])^(XI[i]))*log(1000*lambda[i])
del.t<-matrix(ncol=3,nrow=1)
del.t[1,1]<-diff1
del.t[1,2]<-diff2
del.t[1,3]<-diff3
del<-matrix(ncol=1,nrow=3)
del[1,1]<-diff1
del[2,1]<-diff2
del[3,1]<-diff3
A<-matrix(ncol=3,nrow=1)
A[1,1]<-del.t[1,1]*V[1,1]
A[1,2]<-(del.t[1,2]*V[2,2])+(del.t[1,3]*V[3,2])
A[1,3]<-(del.t[1,2]*V[2,3])+(del.t[1,3]*V[3,3])
ret.var<-(A[1,1]*diff1) + (A[1,2]*diff2) + (A[1,3]*diff3)
ret.se[i]<-sqrt(ret.var)
cluster.peaks<-newcluster(test,threshold,s)
q<-mle.gpd7(cluster.peaks)
PSIGMA[i]<-q$estimate[1]
PXI[i]<-q$estimate[2]
p.lambda[i]<-length(cluster.peaks)/n
v<-(PXI[i]*(x-threshold))/PSIGMA[i]
v1<-(1+v)
if(v1<0)
p.exceedance.rate[i]<-0
else p.exceedance.rate[i]<-p.lambda[i]*(v1^(-1/PXI[i]))
w<-(0.001/p.lambda[i])^(-PXI[i])
w1<-(PSIGMA[i]/PXI[i])*(w-1)
p.return.level[i]<-threshold+w1
p.sigma.se[i]<-sqrt(q$varcovar[1,1])
p.xi.se[i]<-sqrt(q$varcovar[2,2])
V1<-matrix(ncol=3,nrow=3)
V1[1,1]<-p.lambda[i]*(1-p.lambda[i])/n
V1[1,2]<-0
V1[1,3]<-0
V1[2,1]<-0
V1[3,1]<-0
V1[2,2]<-q$varcovar[1,1]
V1[2,3]<-q$varcovar[1,2]
V1[3,2]<-q$varcovar[2,1]
V1[3,3]<-q$varcovar[2,2]
diff4<-PSIGMA[i]*1000^(PXI[i])*p.lambda[i]^(PXI[i]-1)
diff5<-(PXI[i]^(-1))*(((1000*p.lambda[i])^(PXI[i]))-1)
diff6<--(PSIGMA[i])*PXI[i]^(-2)*(((1000*p.lambda[i])^(PXI[i]))-1) + PSIGMA[i]*(PXI[i]^(-1))*((1000*p.lambda[i])^(PXI[i]))*log(1000*p.lambda[i])
del2.t<-matrix(ncol=3,nrow=1)
del2.t[1,1]<-diff4
del2.t[1,2]<-diff5
del2.t[1,3]<-diff6
del2<-matrix(ncol=1,nrow=3)
del2[1,1]<-diff4
del2[2,1]<-diff5
del2[3,1]<-diff6
A1<-matrix(ncol=3,nrow=1)
A1[1,1]<-del2.t[1,1]*V1[1,1]
A1[1,2]<-(del2.t[1,2]*V1[2,2])+(del2.t[1,3]*V1[3,2])
A1[1,3]<-(del2.t[1,2]*V1[2,3])+(del2.t[1,3]*V1[3,3])
p.ret.se[i]<-sqrt((A1[1,1]*diff4) + (A1[1,2]*diff5) + (A1[1,3]*diff6))
}
means[1]<-mean(SIGMA)
means[2]<-mean(XI)
means[3]<-mean(exceedance.rate)
means[4]<-mean(return.level)
means[5]<-mean(lambda)
means[6]<-mean(PSIGMA)
means[7]<-mean(PXI)
means[8]<-mean(p.exceedance.rate)
means[9]<-mean(p.return.level)
means[10]<-mean(p.lambda)
means[11]<-mean(sigma.se)
means[12]<-mean(xi.se)
means[13]<-mean(ret.se)
means[14]<-mean(p.sigma.se)
means[15]<-mean(p.xi.se)
means[16]<-mean(p.ret.se)
medians[1]<-median(SIGMA)
medians[2]<-median(XI)
medians[3]<-median(exceedance.rate)
medians[4]<-median(return.level)
medians[5]<-median(lambda)
medians[6]<-median(PSIGMA)
medians[7]<-median(PXI)
medians[8]<-median(p.exceedance.rate)
medians[9]<-median(p.return.level)
medians[10]<-median(p.lambda)
medians[11]<-median(sigma.se)
medians[12]<-median(xi.se)
medians[13]<-median(ret.se)
medians[14]<-median(p.sigma.se)
medians[15]<-median(p.xi.se)
medians[16]<-median(p.ret.se)
standard.deviations[1]<-sqrt(var(SIGMA))
standard.deviations[2]<-sqrt(var(XI))
standard.deviations[3]<-sqrt(var(exceedance.rate))
standard.deviations[4]<-sqrt(var(return.level))
standard.deviations[5]<-sqrt(var(lambda))
standard.deviations[6]<-sqrt(var(PSIGMA))
standard.deviations[7]<-sqrt(var(PXI))
standard.deviations[8]<-sqrt(var(p.exceedance.rate))
standard.deviations[9]<-sqrt(var(p.return.level))
standard.deviations[10]<-sqrt(var(p.lambda))
return(SIGMA,PSIGMA,XI,PXI,exceedance.rate,p.exceedance.rate,return.level,p.return.level,lambda,p.lambda,means,medians,standard.deviations,sigma.se,p.sigma.se, xi.se,p.xi.se, ret.se,p.ret.se)
}

bayes5<-function(n,dataset,sigmastart,xistart,erreta,errxi,sdeta,sdxi)
{
k<-length(dataset)
sigma<-sigmastart
xi<-xistart
eta<-log(sigma)
caneta<-vector("numeric")
canxi<-vector("numeric")
caneta[1]<-eta
canxi[1]<-xi
x<-vector("numeric")
y<-vector("numeric")
aprobeta<-vector("numeric")
aprobxi<-vector("numeric")
x[1]<-caneta[1]
y[1]<-canxi[1]
loglik<-function(k,dataset,ETA,XI)
{
m<-min(1+(dataset*(XI/exp(ETA))))
if(m<0.00001)return(as.double(-1000000))
if(exp(ETA)<0.00001)return(as.double(-1000000))
loglik<--k*ETA-(1+(1/XI))*sum(log(1+((XI*dataset)/exp(ETA))))
loglik
}
for(i in 2:n){
caneta[i]<-x[i-1]+rnorm(1,0,erreta)
likely<-exp((loglik(k,dataset,caneta[i],y[i-1]))-(loglik(k,dataset,x[i-1],y[i-1])))
aprobeta[i]<-min(1,(likely*((dnorm(caneta[i],0,sdeta))*(dnorm(y[i-1],0,sdxi)))/((dnorm(x[i-1],0,sdeta))*(dnorm(y[i-1],0,sdxi)))))
u<-runif(1)
if(u<aprobeta[i]){x[i]<-caneta[i]}
if(u>=aprobeta[i]){x[i]<-x[i-1]}
canxi[i]<-y[i-1]+rnorm(1,0,errxi)
likely2<-exp((loglik(k,dataset,x[i],canxi[i]))-(loglik(k,dataset,x[i],y[i-1])))
aprobxi[i]<-min(1,(likely2*((dnorm(x[i],0,sdeta))*(dnorm(canxi[i],0,sdxi)))/((dnorm(x[i],0,sdeta))*(dnorm(y[i-1],0,sdxi)))))
if(u<aprobxi[i]){y[i]<-canxi[i]}
if(u>=aprobxi[i]){y[i]<-y[i-1]}
}
aprobeta<-aprobeta[!is.na(aprobeta)]
aprobxi<-aprobxi[!is.na(aprobxi)]
return(x,y,aprobeta,aprobxi)
}

ret.level<-function(sigma,xi,lambda,thresh,period)
{
ret.level<-thresh+(sigma/xi)*(((period*lambda)^(xi))-1)
ret.level
}
