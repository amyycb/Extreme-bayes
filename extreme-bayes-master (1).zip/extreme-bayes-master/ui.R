library(shiny)
library(shinyjs)
library(dygraphs)
library(plotly)
#Some old code hashed instead of deleted
shinyUI(
  fluidPage(
    theme = "cosmo.css",
    navbarPage(
      title="Extreme Value Explorer",
        tabPanel("Data Upload",
          fluidRow(
            column(12,
              wellPanel(
                radioButtons("dataSourceSelection",
                  label = "",
                  choices = c("Use pre-loaded dataset" = "preload", "Upload a dataset" = "user"),
                  selected = "user",
                  inline = TRUE
                )
              )
            )
          ),
          fluidRow(
            column(3,
              wellPanel(
                conditionalPanel(condition = "input.dataSourceSelection == \"preload\"",
                  # Start of Frequency table
                  h3("Demonstration datasets"),
                  selectInput("preloadDataSelection",
                    p("Select a dataset:"),
                    choices = c(
                      # "Rainfall" = "rain",
                      # "Wind speeds" = "brad2",
                      "Max temperature" = "maxtemp",
                      "Snow depths" = "snowdepth",
                      "Sunshine hours" = "sunshine",
                      "Sea level pressure" = "sealevelpressure"
                    ),
                    selected = "maxtemp"
                  )
                ), # End of conditionalPanel when input.dataSourceSelection == preload
                conditionalPanel(condition = "input.dataSourceSelection == \"user\"",
                  h2("Data upload"),
                  fileInput('dataIn',
                    'Upload data file',
                    accept = c(#'text/csv',
                               #'text/comma-separated-values,text/plain',
                               #'.csv',
                      'text/plain','.txt')
                  ),
                  checkboxInput('headerControl', 'Header', TRUE),
                  radioButtons('sepControl',
                    'Separator',
                    c(`Multi-space`="",
                      Comma=',',
                      Space=" ",
                      Semicolon=';',
                      Tab="\t"),
                    ""
                  ),
                  radioButtons('quoteControl',
                    'Quote',
                    c(None = '',
                      'Double Quote' = '"',
                      'Single Quote' = "'"),
                    '"'
                  ),
                  numericInput("dataUploadLineSkips",
                    "Number of lines ignored at start of file:",
                    value = 0,
                    min = 0,
                    step = 1
                  )
                )
              )
            ),
            column(9,
              h3("Uploaded data preview"),
              DT::dataTableOutput("dataUploadPreview1")
            ),
            column(12,
              conditionalPanel(condition = "input.dataSourceSelection == \"preload\"",
              # conditionalPanel(condition = "input.preloadDataSelection == 'brad2'",
              #   p("This is a data set of hourly maximum wind gusts, from 2003", HTML("&ndash;"), "2012 (inclusive), recorded in High Bradfield, Peak District."),
              #   HTML('<iframe src="https://www.google.com/maps/embed/v1/place?q=High,+Bradfield,+Sheffield,+United+Kingdom&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU" height="450" frameborder="0" style="border:0;width:100%" allowfullscreen></iframe>')
              # ),
              # conditionalPanel(condition = "input.preloadDataSelection == 'rain'",
              #   p("This is a data set of hourly maximum daily rainfall totals (mm), from 1991", HTML("&ndash;"), "2011 (inclusive), recorded in Eskdale, Lake District."),
              #   HTML('<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d74286.42234500349!2d-3.3119922913158697!3d54.41967578624567!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487cc9e3c7209ed5%3A0xc9d13abd308ed866!2sRiver+Esk!5e0!3m2!1sen!2suk!4v1460108413731" height="450" frameborder="0" style="border:0;width:100%;" allowfullscreen></iframe>')
              # ),
                conditionalPanel(condition = "input.preloadDataSelection == 'maxtemp'",
                  p("This is a data set of daily maximum temperatures (0.1 \u00B0C), from 1951", HTML("&ndash;"), "2013 (inclusive), recorded in Reykjavik, Iceland."),
                  HTML('<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d55703.48048044354!2d-21.922481219410464!3d64.132338740363!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48d674b9eedcedc3%3A0xec912ca230d26071!2sReykjav%C3%ADk%2C+Iceland!5e0!3m2!1sen!2suk!4v1493734719147" height="450" frameborder="0" style="border:0;width:100%;" allowfullscreen></iframe>')
                ),
                conditionalPanel(condition = "input.preloadDataSelection == 'snowdepth'",
                  p("This is a data set of daily snow depths (cm), from late 1976", HTML("&ndash;"), "2013 (inclusive), recorded in Svalbard Airport, Norway."),
                  HTML('<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d21873.835631907186!2d15.425235421532715!3d78.24416666819256!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x459c52a42b6d6fb1%3A0xe45ac2fb03b62697!2sSvalbard+Airport+(LYR)!5e0!3m2!1sen!2suk!4v1493734835555" height="450" frameborder="0" style="border:0;width:100%;" allowfullscreen></iframe>')
                ),
                conditionalPanel(condition = "input.preloadDataSelection == 'sunshine'",
                  p("This is a data set of daily total sunshine hours (0.1 hours), from 1971", HTML("&ndash;"), "2013 (inclusive), recorded in Ogulin, Croatia."),
                  HTML('<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d44931.94272051567!2d15.173975944608383!3d45.26302931212672!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4764738a58c5ccb7%3A0x7663fa6224ef2052!2sOgulin%2C+Croatia!5e0!3m2!1sen!2suk!4v1493734872677" height="450" frameborder="0" style="border:0;width:100%;" allowfullscreen></iframe>')
                ),
                conditionalPanel(condition = "input.preloadDataSelection == 'sealevelpressure'",
                  p("This is a data set of daily sea level pressures (0.1 hPa), from 1850", HTML("&ndash;"), "2001 (inclusive), recorded in Armagh, United Kingdom."),
                  HTML('<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d18604.49852840116!2d-6.66606449295625!3d54.3470437472149!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48608d557dcb168d%3A0xb92e637dcdc91848!2sArmagh!5e0!3m2!1sen!2suk!4v1493734928142" height="450" frameborder="0" style="border:0;width:100%;" allowfullscreen></iframe>')
                )
              ) # End of conditionalPanel when input.dataSourceSelection == preload
            )
          ),
          # conditionalPanel(condition = "input.dataSourceSelection == \"user\"",
            hr(),
            fluidRow(
              column(3,
                wellPanel(
                  h2("Identify the date-stamps"),
                  selectInput("dateStampColumnName",
                    "Column containing date-stamps:",
                    choices = c("Please upload a dataset" = NULL)),
                  selectInput("dateStampFormat",
                    label = "Datestamp format",
                    choices = list(
                      `Date` = c("YYYYMMDD (e.g. 19660730)" = "%Y%m%d",
                        "YYYY-MM-DD (e.g. 1966-07-30)" = "%F"),
                      `Date & Time` = c(
                        "YYYYMMDDThhmmss" = "%Y%m%dT%H%M%S",
                        "YYYYMMDDThh:mm:ss" = "%Y%m%dT%T",
                        "YYYY-MM-DDThh:mm:ss" = "%FT%T",
                        "YYYY-MM-DDThh:mm:ssZ" = "%FT%TZ",
                        "YYYY-MM-DDThhmmss" = "%FT%H%M%S",
                        "YYYY-MM-DD hh:mm:ss" = "%F%t%T"
                      )
                    ),
                    selected = "%Y%m%d"
                  ),
                  uiOutput("dateStampRangeUI")
                )
              ),
              column(9,
                h3("Date-stamp previews"),
                p("Raw date-stamp values found in the selected column (first 6 only)"),
                verbatimTextOutput("dateStampRaw"),
                p(paste0("Interpretation of the (first 6) selected date-stamps.",
                  " These should appear in the format, \"",
                  format(Sys.time(), format = "%A, %d %B %Y at %T"), "\".")
                ),
                verbatimTextOutput("dateStampInterpreted")
              )
            ),
            hr(),
            fluidRow(
              column(3,
                wellPanel(
                  h2("Identify the data values"),
                  selectInput("dataValueColumnSelectUI",
                    "Column containing data values",
                    choices = c("Please upload a dataset" = NULL)),
                  checkboxInput(inputId = "dataHasMissingValues",
                    label = "Data contains missing values",
                    value = FALSE),
                  conditionalPanel(condition = "input.dataHasMissingValues == true",
                    numericInput("missingValueCode",
                      "Missing value code",
                      value = NA_real_
                    )
                  )
                )
              ),
              column(9,
                h3("Data previews"),
                p("Raw data values found in the selected column (first 50 only)"),
                verbatimTextOutput("dataValuePreview"),
                p(textOutput("numberOfObservationsRetained", inline = TRUE),
                  "rows of data to be used in the analysis."),
                p(textOutput("numberOfMissingRowsRemoved", inline = TRUE),
                  "rows of missing data have been removed.")
              )
            # )
          ),
          fluidRow(
            column(12,
              dygraphOutput("SelectedDataTimeSeries"),
              style = "margin-bottom: 3em;"
            )
          ),
          fluidRow(
            column(12,
              wellPanel(
                radioButtons("dataSplittingForPlots",
                  "Split data by:",
                  c("Weekday", "Day", "Month", "Quarter", "Year", "(No split)" = ""),
                  selected = "",
                  inline = TRUE
                )
              ),
              plotlyOutput("splitBoxplots")
            )
          )
        ), # End of Data upload tab
                #  fluidRow(
                #    column(3,
                #           wellPanel(
                #             h2("Choosing Your Data Set"),
                #             checkboxInput("dataSourceSelection",
                #                           "Upload your own data set",
                #                           FALSE),
                            # conditionalPanel(condition = "input.dataSourceSelection == preload",
                            #   # Start of Frequency table
                            #   h3("Please select the data set you wish to use"),
                            #   selectInput("preloadDataSelection",
                            #               "",
                            #               choices = c(
                            #                 "Rainfall" = "rain",
                            #                 "Wind speeds" = "brad2",
                            #                 "Max temperature" = "maxtemp",
                            #                 "Snow depths" = "snowdepth",
                            #                 "Sunshine hours" = "sunshine",
                            #                 "Sea level pressure" = "sealevel"
                            #               ),
                            #               selected = "rain")
                            # ), # End of conditionalPanel when input.dataSourceSelection == preload
                            # conditionalPanel(condition = "input.dataSourceSelection == user",
                            #   h2("Data upload"),
                						# 	fileInput('dataIn',
                            #             'Upload data file',
                            #     # conditionalPanel(condition = "input.dataSourceSelection == preload",
                            #   # Start of Frequency table
                            #   h3("Please select the data set you wish to use"),
                            #   selectInput("preloadDataSelection",
                            #               "",
                            #               choices = c(
                            #                 "Rainfall" = "rain",
                            #                 "Wind speeds" = "brad2",
                            #                 "Max temperature" = "maxtemp",
                            #                 "Snow depths" = "snowdepth",
                            #                 "Sunshine hours" = "sunshine",
                            #                 "Sea level pressure" = "sealevel"
                            #               ),
                            #               selected = "rain")
                            # ), # End of conditionalPanel when input.dataSourceSelection == preload
                            # conditionalPanel(condition = "input.dataSourceSelection == user",
                            #   h2("Data upload"),
                						# 	fileInput('dataIn',
                            #             'Upload data file',
                            #             accept = c(#'text/csv',
                            #     									 #'text/comma-separated-values,text/plain',
                            #     									 #'.csv',
                            #     									 'text/plain','.txt')),
                						# 	checkboxInput('headerControl', 'Header', TRUE),
                						# 	radioButtons('sepControl',
                            #                'Separator',
                            #                c(`Multi-space`="",
                          	# 								 Comma=',',
                          	# 								 Space=" ",
                          	# 								 Semicolon=';',
                          	# 								 Tab="\t"),
                						# 		           ""),
                						# 	radioButtons('quoteControl',
                            #                'Quote',
                            #                c(None = '',
                        		# 						     'Double Quote' = '"',
                        		# 							   'Single Quote' = "'"),
                						# 		           '"'),        accept = c(#'text/csv',
                            #     									 #'text/comma-separated-values,text/plain',
                            #     									 #'.csv',
                            #     									 'text/plain','.txt')),
                						# 	checkboxInput('headerControl', 'Header', TRUE),
                						# 	radioButtons('sepControl',
                            #                'Separator',
                            #                c(`Multi-space`="",
                          	# 								 Comma=',',
                          	# 								 Space=" ",
                          	# 								 Semicolon=';',
                          	# 								 Tab="\t"),
                						# 		           ""),
                						# 	radioButtons('quoteControl',
                            #                'Quote',
                            #                c(None = '',
                        		# 						     'Double Quote' = '"',
                        		# 							   'Single Quote' = "'"),
                						# 		           '"'),
                              #numericInput("skipSelect", "Enter how many lines of text recordings are at the start of your uploaded file", value = 20),
            			# 						numericInput("maxSelect",
                  #                          "Enter the column which contains the data",
                  #                          value = 4),
            			# 						checkboxInput("missingCode",
                  #                           tags$b("Is there a code which represents missing values within your data set? If yes, tick this box"),
                  #                           FALSE),
            			# 						conditionalPanel(condition = "input.missingCode == true",
            		  #               numericInput("missingSelect", "Enter your missing value code here",value = -9999)
            	    #             ),
                  #                            textInput("dataName", label = "What is your data about?", value = "Enter text here..."),
                  #                            checkboxInput('headerUpload', 'Header', TRUE),
                  #                            radioButtons('sepUpload', 'Separator',
                  #                                         c(
                  #                                           `Multi-space`="",
                  #                                           Comma=',',
                  #                                           Space=" ",
                  #                                           Semicolon=';',
                  #                                           Tab="\t"
                  #                                         ),
                  #                                         ','
                  #                            ),
                  #                            radioButtons('quoteUpload', 'Quote',
                  #                                         c(
                  #                                           None='',
                  #                                           'Double Quote'='"',
                  #                                           'Single Quote'="'"
                  #                                         ),
                  #                                         '"'
                  #                            )
                  #           ), # End of conditionalPanel when input.dataSourceSelection == user
                  #           h3("Setting up the data"),
                  #           selectInput("dataUnits", label = p("Select the units for your data:"),
                  #                       choices = list(
                  #                         `Length (metric)` = c("Metre (m)" = "m", "Centimetre (cm)" = "cm", "Millimetre (mm)" = "mm"),
                  #                         `Length (imperial)` = c("Yard (yd)" = "yd", "Feet (ft)" = "ft", "Inch (in)" = "in"),
                  #                         `Volume (metric)` = c("Litre (L)" = "L", "Millilitre (ml)" = "ml"),
                  #                         `Speed` = c("Metres per second (m/s)" = "m/s", "Miles per hour (mph)" = "mph", "Kilometres per hour (kph)" = "kph"),
                  #                         `Temperature` = c("Centigrade/Celcius (\u00B0C)" = "\u00B0C", "Farenheit (\u00B0F)" = "\u00B0F", "Kelvin (K)" = "K"),
                  #                         `Time` = c("Hours (h)" = "h", "Minutes (min)" = "min", "Seconds (s)" = "s"),
                  #                         `Force` = c("Kilograms (kg)" = "kg", "Newtons (N)" = "N", "Pascal (hPa)" = "hPa")
                  #                       ),
                  #                       selected = "ft"
                  #           ),
                  #           selectInput("occurrence", label = p("Select the occurrence of your data:"),
                  #                       choices = list(
                  #                         `Annually` = 1,
                  #                         `Quarterly` = 4,
                  #                         `Monthly` = 12,
                  #                         `Fortnightly` = 26,
                  #                         `Weekly` = 52,
                  #                         `Daily` = 365.25,
                  #                         `Hourly` = 8766,
                  #                         `Every minute` = 525960,
                  #                         `Every second` = 31557600
                  #                       )
                  #           )
                  #         ) #End of Well Panel
                  #  ),
                  #  column(9,
                  #         h3("Summary Table"),
                  #         tableOutput("SummaryTable"),
                  #         h3("Histogram"),
                  #         plotOutput("datafileHistogram"),
                  #         h3("Boxplot"),
                  #         plotOutput("datafileBoxplot")
                  #  )
        tabPanel("Threshold Selection",
          fluidRow(
            h1("Threshold Selection"),
            column(12,
              wellPanel(
                radioButtons("dataSplittingForAnalysis",
                  "Type of analysis:",
                  c("Monthly", "Quarterly", "Overall"),
                  selected = 'Overall',
                  inline = TRUE
                )
              )
            )
          ), #end of fluid row 1
          sidebarLayout(
            sidebarPanel(
              h3("Threshold selection method"),
              radioButtons("quantileChoice",
                label = h4("Choose a quantile:"),
                choices = list("99%", "95%", "90%"),
                inline = TRUE
              ),
              checkboxInput(inputId = "useMRLPlot",
                label = "Manual input using MRL plot",
                value = FALSE
              ),
              conditionalPanel(condition = "input.useMRLPlot == true",
                numericInput("threshMRLInput1", label = textOutput("threshLabel1"), 0),
                conditionalPanel("input.dataSplittingForAnalysis != 'Overall'",
                  numericInput("threshMRLInput2", label = textOutput("threshLabel2"), 0),
                  numericInput("threshMRLInput3", label = textOutput("threshLabel3"), 0),
                  numericInput("threshMRLInput4", label = textOutput("threshLabel4"), 0)
                ),
                conditionalPanel(condition = "input.dataSplittingForAnalysis == 'Monthly'",
                  numericInput("threshMRLInput5", label = textOutput("threshLabel5"), 0),
                  numericInput("threshMRLInput6", label = textOutput("threshLabel6"), 0),
                  numericInput("threshMRLInput7", label = textOutput("threshLabel7"), 0),
                  numericInput("threshMRLInput8", label = textOutput("threshLabel8"), 0),
                  numericInput("threshMRLInput9", label = textOutput("threshLabel9"), 0),
                  numericInput("threshMRLInput10", label = textOutput("threshLabel10"), 0),
                  numericInput("threshMRLInput11", label = textOutput("threshLabel11"), 0),
                  numericInput("threshMRLInput12", label = textOutput("threshLabel12"), 0)
                )
              )
            ),
            mainPanel(
              fluidRow(
                column(6,
                  plotOutput("mrlPlot1"),
                  textOutput("threshChoiceText1")
                ),
                conditionalPanel("input.dataSplittingForAnalysis != 'Overall'",
                  column(6,
                    plotOutput("mrlPlot2"),
										textOutput("threshChoiceText2")
                  ),
                  hr(),
                  column(6,
                    plotOutput("mrlPlot3"),
                    textOutput("threshChoiceText3")
                  ),
                  column(6,
                    plotOutput("mrlPlot4"),
                    textOutput("threshChoiceText4")
                  ),
									style = "display:inline;"
                ),
                conditionalPanel("input.dataSplittingForAnalysis == 'Monthly'",
                  column(6,
                    plotOutput("mrlPlot5"),
                    textOutput("threshChoiceText5")
                  ),
                  column(6,
                    plotOutput("mrlPlot6"),
                    textOutput("threshChoiceText6")
                  ),
                  hr(),
                  column(6,
                    plotOutput("mrlPlot7"),
                    textOutput("threshChoiceText7")
                  ),
                  column(6,
                    plotOutput("mrlPlot8"),
                    textOutput("threshChoiceText8")
                  ),
                  hr(),
                  column(6,
                    plotOutput("mrlPlot9"),
                    textOutput("threshChoiceText9")
                  ),
                  column(6,
                    plotOutput("mrlPlot10"),
                    textOutput("threshChoiceText10")
                  ),
                  hr(),
                  column(6,
                    plotOutput("mrlPlot11"),
                    textOutput("threshChoiceText11")
                  ),
                  column(6,
                    plotOutput("mrlPlot12"),
                    textOutput("threshChoiceText12")
                	)
								)
              )
            )
          )
        ), # End of Threshold Selection tab
        tabPanel("Dependence",
          h1("Dependence"),
          uiOutput("dependenceTabs"),
          fluidRow(
            column(12,
              wellPanel(
                radioButtons("dependenceMethod",
                  h3("Method for dealing with dependence:"),
                  c("Fit a dependence model (reccommended)" = 'depend',
                    "Decluster" = 'decl',
                    "No method (fit all threshold excesses)" = 'none'
                    ),
                  selected = 'depend'
                ),
                conditionalPanel(condition = "input.dependenceMethod == 'decl'",
                  numericInput("declusterKappa",
                    label = p("Declustering constant ", withMathJax("\\(\\kappa\\)", ":")),
                    value = 5,
                    width = '30%'
                  )
                )
              )
            )
          )
        ), #end of Dependence tab
        tabPanel("Run MCMC",
          h1("Run MCMC"),
          fluidRow(
            column(4,
              wellPanel(
                h3("Prior specifications"),
                h4(withMathJax("Scale Parameter \\(\\sigma\\)")),
                fluidRow(
                  column(6,
                    numericInput("sigmaPriorMean",
                      label = 'Prior mean:',
                      value = 1,
                      min = 0
                    )
                  ),
                  column(6,
                    numericInput("sigmaPriorSD",
                      label = 'Prior standard deviation:',
                      value = 50,
                      min = 0
                    )
                  )
                ),
                helpText(withMathJax("Note: we will now work with \\(\\eta = \\log(\\sigma)\\) to ensure that \\(\\sigma\\) is positive.")),
                hr(),
                h4(withMathJax("Shape Parameter \\(\\xi\\)")),
                fluidRow(
                  column(6,
                    numericInput("xiPriorMean",
                      label = 'Prior mean:',
                      value = 0.1,
                      step = 0.1
                    )
                  ),
                  column(6,
                    numericInput("xiPriorSD",
                      label = 'Prior standard deviation:',
                      value = 1,
                      min = 0
                    )
                  )
                ),
                hr(),
                h3("Tuning Parameters"),
                fluidRow(
                  column(4,
                    numericInput("errLogSigma",
                      label = withMathJax("\\(\\log \\sigma \\)"),
                      value = 0.25,
                      min = 0,
                      step = 0.01
                    )
                  ),
                  column(4,
                    numericInput("errXi",
                      label = withMathJax("\\(\\xi \\)"),
                      value = 0.02,
                      min = 0,
                      step = 0.01
                    )
                  ),
                  column(4,
                    numericInput("errAlpha",
                      label = withMathJax("\\(\\alpha \\)"),
                      value = 0.02,
                      min = 0,
                      step = 0.01
                    )
                  )
                ),
                fluidRow(
                  column(12,
                    actionButton('pilotMCMCButton', label = 'Pilot Run', width = '50%'),
                    helpText('Pilot scheme reccommended for long schemes. Runs 1000 iterations with no thinning and a burn-in of 200.')
                  )
                )
              )
            ),
            #end well panel here
            column(8,
              conditionalPanel(condition = "input.pilotMCMCButton",
                h2("Pilot Run: Parameter Analysis"),
                fluidRow(tableOutput("pilotAcceptanceProbTab")),
                helpText("Note: acceptance probabilities should be between 20", HTML("&ndash;"), "30% for an optimal scheme."),
                hr(),
                h3(withMathJax("Pilot Parameter Plots")),
                checkboxInput("showSigmaPilotPlots",
                  withMathJax("\\(\\eta\\)"),
                  value = FALSE,
                  width = NULL
                ),
                conditionalPanel(condition = 'input.showSigmaPilotPlots == true',
                  fluidRow(plotOutput("pilotSigmaPlot1")),
                  conditionalPanel("input.dataSplittingForAnalysis != 'Overall'",
                    fluidRow(plotOutput("pilotSigmaPlot2")),
                    fluidRow(plotOutput("pilotSigmaPlot3")),
                    fluidRow(plotOutput("pilotSigmaPlot4"))
                  ),
                  conditionalPanel("input.dataSplittingForAnalysis == 'Monthly'",
                    fluidRow(plotOutput("pilotSigmaPlot5")),
                    fluidRow(plotOutput("pilotSigmaPlot6")),
                    fluidRow(plotOutput("pilotSigmaPlot7")),
                    fluidRow(plotOutput("pilotSigmaPlot8")),
                    fluidRow(plotOutput("pilotSigmaPlot9")),
                    fluidRow(plotOutput("pilotSigmaPlot10")),
                    fluidRow(plotOutput("pilotSigmaPlot11")),
                    fluidRow(plotOutput("pilotSigmaPlot12"))
                  )
                ),
                checkboxInput("showXiPilotPlots",
                  withMathJax("\\(\\xi\\)"),
                  value = FALSE,
                  width = NULL
                ),
                conditionalPanel(condition = 'input.showXiPilotPlots == true',
                  fluidRow(plotOutput("pilotXiPlot1")),
                  conditionalPanel("input.dataSplittingForAnalysis != 'Overall'",
                    fluidRow(plotOutput("pilotXiPlot2")),
                    fluidRow(plotOutput("pilotXiPlot3")),
                    fluidRow(plotOutput("pilotXiPlot4"))
                  ),
                  conditionalPanel("input.dataSplittingForAnalysis == 'Monthly'",
                    fluidRow(plotOutput("pilotXiPlot5")),
                    fluidRow(plotOutput("pilotXiPlot6")),
                    fluidRow(plotOutput("pilotXiPlot7")),
                    fluidRow(plotOutput("pilotXiPlot8")),
                    fluidRow(plotOutput("pilotXiPlot9")),
                    fluidRow(plotOutput("pilotXiPlot10")),
                    fluidRow(plotOutput("pilotXiPlot11")),
                    fluidRow(plotOutput("pilotXiPlot12"))
                  )
                ),
                conditionalPanel("input.dependenceMethod == 'depend'",
                  checkboxInput("showThetaPilotPlots",
                    withMathJax("\\(\\theta\\)"),
                    value = FALSE,
                    width = NULL
                  ),
                  conditionalPanel(condition = 'input.showThetaPilotPlots == true',
                    fluidRow(plotOutput("pilotThetaPlot1")),
                    conditionalPanel("input.dataSplittingForAnalysis != 'Overall'",
                      fluidRow(plotOutput("pilotThetaPlot2")),
                      fluidRow(plotOutput("pilotThetaPlot3")),
                      fluidRow(plotOutput("pilotThetaPlot4"))
                    ),
                    conditionalPanel("input.dataSplittingForAnalysis == 'Monthly'",
                      fluidRow(plotOutput("pilotThetaPlot5")),
                      fluidRow(plotOutput("pilotThetaPlot6")),
                      fluidRow(plotOutput("pilotThetaPlot7")),
                      fluidRow(plotOutput("pilotThetaPlot8")),
                      fluidRow(plotOutput("pilotThetaPlot9")),
                      fluidRow(plotOutput("pilotThetaPlot10")),
                      fluidRow(plotOutput("pilotThetaPlot11")),
                      fluidRow(plotOutput("pilotThetaPlot12"))
                    )
                  )
                )
              )
            )
          ), #fluid row
          # Change the run MCMC button when MCMC is running
          singleton(tags$head(
            tags$link(href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css", rel="stylesheet")
            ,tags$script(HTML( # Disable "run simulation" button with JS.
              '//$(document).ready(function() {
                Shiny.addCustomMessageHandler("startingSimulation", function(buttonid) {
                  $("#" + buttonid).prop("disabled", true).html("<i class=\\"fa fa-spinner fa-pulse\\"></i> MCMC in progress &hellip;");
                  //$("#preFlightChecks_trafficLight").children("div.alert-success").toggleClass("alert-warning").html("<i class=\\"fa fa-spinner fa-pulse\\"></i> MCMC in progress ...");
                });
                Shiny.addCustomMessageHandler("endingSimulation", function(button) {
                  $("#" + button.id).prop("disabled", false).html("<i class=\\"fa fa-check\\"></i> MCMC complete!");
                  //$("#preFlightChecks_trafficLight").children("div").attr("class", "alert alert-success").html("<i class=\\"fa fa-check\\"></i> Simulation complete on " + siteSelectionLength + " sites!  Clicking below will restart the simulation.");
                  setTimeout(function() {$("#" + button.id).html(button.message)}, 5000);
                });
              //});
              '
            ))
          )),
          fluidRow(
            column(8,
              wellPanel(
                h3("Duration"),
                sliderInput("numberIterations","Number of iterations", min=1000, max = 100000, step=1000, value=10000, width="80%"),
                sliderInput("thinning","Thinning steps between iterations", min=1, max=50, value=1, width="80%"),
                sliderInput("burnIn","Burn-in steps", min=0, max=10000, step=100, value=1000, width="80%"),
                actionButton('runMCMCButton', label = 'Run MCMC', icon = NULL, width = NULL)
              )
            )
          ),
          fluidRow(
            h2("Parameter Analysis")
          ),
          fluidRow(
            tableOutput("acceptanceProbTab")
          ),
          helpText("Note: acceptance probabilities should be between 20", HTML("&ndash;"), "30% for an optimal scheme."),
          hr(),
          fluidRow(
            h3(withMathJax("\\(\\eta\\) Parameter")),
            p(withMathJax("The acceptance probability for \\( \\eta \\) is ")),
            checkboxInput("showSigmaPlots",
              "Show parameter plot",
              value = FALSE,
              width = NULL
            ),
            conditionalPanel(condition = 'input.showSigmaPlots == true',
              fluidRow(plotOutput("sigmaPlot1")),
              conditionalPanel("input.dataSplittingForAnalysis != 'Overall'",
                fluidRow(plotOutput("sigmaPlot2")),
                fluidRow(plotOutput("sigmaPlot3")),
                fluidRow(plotOutput("sigmaPlot4"))
              ),
              conditionalPanel("input.dataSplittingForAnalysis == 'Monthly'",
                fluidRow(plotOutput("sigmaPlot5")),
                fluidRow(plotOutput("sigmaPlot6")),
                fluidRow(plotOutput("sigmaPlot7")),
                fluidRow(plotOutput("sigmaPlot8")),
                fluidRow(plotOutput("sigmaPlot9")),
                fluidRow(plotOutput("sigmaPlot10")),
                fluidRow(plotOutput("sigmaPlot11")),
                fluidRow(plotOutput("sigmaPlot12"))
              )
            ),
            hr(),
            h3(withMathJax("\\(\\xi\\) Parameter")),
            p(withMathJax("The acceptance probability for \\( \\xi \\) is ")),
            checkboxInput("showXiPlots",
              "Show parameter plot",
              value = FALSE,
              width = NULL
            ),
            conditionalPanel(condition = 'input.showXiPlots == true',
              fluidRow(plotOutput("xiPlot1")),
              conditionalPanel(condition = "input.dataSplittingForAnalysis != 'Overall'",
                fluidRow(plotOutput("xiPlot2")),
                fluidRow(plotOutput("xiPlot3")),
                fluidRow(plotOutput("xiPlot4"))
              ),
              conditionalPanel(condition = "input.dataSplittingForAnalysis == 'Monthly'",
                fluidRow(plotOutput("xiPlot5")),
                fluidRow(plotOutput("xiPlot6")),
                fluidRow(plotOutput("xiPlot7")),
                fluidRow(plotOutput("xiPlot8")),
                fluidRow(plotOutput("xiPlot9")),
                fluidRow(plotOutput("xiPlot10")),
                fluidRow(plotOutput("xiPlot11")),
                fluidRow(plotOutput("xiPlot12"))
              )
            ),
            conditionalPanel(condition = "input.dependenceMethod == 'depend'",
              hr(),
              h3(withMathJax("\\(\\theta\\) Parameter")),
              p(withMathJax("The acceptance probability for \\( \\theta \\) is ")),
              checkboxInput("showThetaPlots",
                "Show parameter plot",
                value = FALSE,
                width = NULL
              ),
              conditionalPanel(condition = 'input.showThetaPlots == true',
                fluidRow(plotOutput("thetaPlot1")),
                conditionalPanel("input.dataSplittingForAnalysis != 'Overall'",
                  fluidRow(plotOutput("thetaPlot2")),
                  fluidRow(plotOutput("thetaPlot3")),
                  fluidRow(plotOutput("thetaPlot4"))
                ),
                conditionalPanel("input.dataSplittingForAnalysis == 'Monthly'",
                  fluidRow(plotOutput("thetaPlot5")),
                  fluidRow(plotOutput("thetaPlot6")),
                  fluidRow(plotOutput("thetaPlot7")),
                  fluidRow(plotOutput("thetaPlot8")),
                  fluidRow(plotOutput("thetaPlot9")),
                  fluidRow(plotOutput("thetaPlot10")),
                  fluidRow(plotOutput("thetaPlot11")),
                  fluidRow(plotOutput("thetaPlot12"))
                )
              )
            )
          )
        ), #end of Run MCMC tab
        tabPanel("Return Levels", #should this be Output instead?
          h1("Return Levels"),
          fluidRow(
            column(12,
              h3("Return Level Analysis"),
              sidebarLayout(
                sidebarPanel(
                  checkboxGroupInput("returnLevelSelection",
                    label = h4("Select which return levels you require:"),
                    choices = list( #check which years should be here
                      "50-year" = "50",
                      "100-year" = "100",
                      "200-year" = "200",
                      "1000-year" = "1000",
                      "10000-year" = "10000",
                      "100000-year" = "100000",
                      "manual selection:" = "rrl"
                    ),
                    selected = "50"
                  ),
                  numericInput("rrlOptionInput",
                    label = "",
                    value = 10
                  ),
                  radioButtons("predictRadioButtons",
                    h4("Select analysis type:"),
                    choices = c("Standard", "Predictive"),
                    selected = "Standard",
                    inline = FALSE
                  ),
                  helpText("Note: Predictive analysis will be longer (especially for monthly analysis and long MCMC schemes).")
                ),
                mainPanel(
                  tableOutput("specifiedRLTable")
                #return level table here
                  #maybe a return level plot with all on?
                )
              )
            )
          ), #end of fluid row 1
          fluidRow(
            h3("Standard Return Level Distribution"),
            plotOutput("specificRLDists")
            #add return level plots here
          ), #end of fluid row 2
          conditionalPanel(condition = "input.predictRadioButtons == 'Predictive'",
            fluidRow(
              h3("Predictive Return Level"),
              column(3,
                wellPanel(
                  numericInput(
                    "maxPredRetLevel",
                    label = "Select a maximum return level period:",
                    value = 10000,
                    min = 100
                  )
                )
              ),
              column(9,
                plotOutput("predictiveRLPlot")
              )
            ) #end of fluid row 3
          )
        ) #end of Return Levels tab
  #       tabPanel("Pre-analysis",
  #                h1("Pre-analysis"),
  #                div(
  #                  sidebarLayout(
  #                    sidebarPanel(
  #                    uiOutput("threshnuminput"), #now threshMRLInput
  #                      p("Alternatively, choose a quantile and enter the automated threshold choice."), #thresholdchoice needs a min and max but won't work wthout renderUI
  #                      uiOutput("quantradiobuttons"),  # now threshQuantileInput                                                 #using it resulted in an error for future calculations
  #                      textOutput("threshchoicetext")
  #                    ),
  #                    mainPanel(#plotOutput("MRLplot")
  #                      )
  #                  )
  #                ),
  # #                fluidRow(
  # #                  column(6,
  # #                         #plotOutput("scatterPlot")
  # #                  ),
  # #                  column(6,
  # #                         #plotOutput("scatterPlotexceedance")
  # #                  )
  # #                ),
  # #                fluidRow(
  # #                  column(6,
  # #                         #plotOutput("neighbourplot")
  # #                  ),
  # #                  column(6,
  # #                         #plotOutput("pacfplot")
  # #                  )
  # #                ),
  #                fluidRow(
  #                  uiOutput("countermeasbuttons"),
  #                  conditionalPanel(condition = "input.adjustmentChoice == 3",
  #                               uiOutput("declusterresult")
  #                  ),
  #                  conditionalPanel(condition = "input.adjustmentChoice == 4",
  #                                   column(4,h2("Extremal index"),
  #                                          p("A significant p-test has been conducted on the neighbour plot and we strongly advise taking action.
  #                                             This signifies dependence between the data. To counter this, we can consider estimating the extremal index.
  #                                             This in turn affects return levels and the standard errors. This method is less wasteful than declustering,
  #                                             however this is extremely taxing computationally and can take a standard computer hours to finish.")
  #                                         ),
  #                                   column(4,
  #                                          numericInput("bootstrapITER","Please enter the number of bootstrap iterations you would like to use",value=1000)
  #                                          ),
  #                                   column(4,
  #                                          numericInput("bootstrapRL","Please enter the desired r-year return level to be calculated on the next page",value=100)
  #                                          ),
  #                                   column(6,
  #                                          actionButton("extrmIndexbutton","Click here to generate an extremal index estimate and a return level estimate")
  #                                          )
  #                 )
  #                 )
  #       ), # End of Pre-analysis tab
  #       tabPanel("Probability Model",
  #                h1("Probability Model"),
  #                         radioButtons("analysisChoice", "Choose type of analysis",
  #                                      choices = list("Frequentist" = 1,
  #                                                     "Bayesian" = 2)),
  #                         tags$hr(style = "border-color:black"),
  #                         tags$hr(style = "border-color:black"),
  #                  conditionalPanel( condition = "input.analysisChoice == 1",
  #                         h2("Generalised Pareto Distribution"),
  #                         div(
  #                           div(
  #                             h3("How probability is calculated using a probability model", class = "panel-title"),
  #                             class = "panel-heading"
  #                           ),
  #                           div(
  #                             withMathJax(
  #                               p("The probability of an event having threshold excess greater than \\(y\\) given a threshold \\(u\\) is given by the formula,$$\\mathrm{Pr}(X-u>y|X>u)=\\left[1+\\frac{\\xi y}{\\tilde{\\sigma}}\\right]^{-\\frac{1}{\\xi}}_+\\text{,}$$where:"),
  #                               tags$ul(
  #                                 tags$li("\\(\\tilde{\\sigma} = \\sigma + \\xi(u\\ - \\mu\\)) is the ", em("scale"), " parameter,"),
  #                                 tags$li("\\(\\xi\\) is the ", em("shape"), " parameter,"),
  #                                 tags$li("\\(X\\) is our ", em("random variable"), ","),
  #                                 tags$li("\\(y\\) is the ", em("value"), " of our random variable,"),
  #                                 tags$li("\\(a_+ = \\max(0, a)\\).")
  #                               )
  #                             ),
  #                             checkboxInput("standardErrorGPD", "Include Standard Errors", FALSE),
  #                             uiOutput("GPDTablePreamble"),
  #                             uiOutput("GPDextremeoutput"),
  #                             class = "panel-body"
  #                           ),
  #                           class = "panel panel-info"
  #                         ),
  #                         fluidRow(
  #                         column(12,
  #                           div(
  #                             div(
  #                               h3("Assess the goodness of fit", class = "panel-primary"),
  #                               class = "panel-heading"
  #                             ),
  #                             div(
  #                               column(6,
  #                               plotOutput("Pplot")
  #                               ),
  #                               column(6,
  #                               plotOutput("QQplot")
  #                               ),
  #                               class = "panel-body"
  #                             ),
  #                             class = "panel panel-primary"
  #                           )
  #                         )
  #                         ),
  #                         fluidRow(
  #                           column(6,
  #                                  div(
  #                                    div(
  #                                      h3("Calculate a probability from this model", class = "panel-primary"),
  #                                      class = "panel-heading"
  #                                    ),
  #                                    div(
  #                                      wellPanel(uiOutput("GPDProbabilitySlider")),
  #                                      uiOutput("GPDProbabilityDescription"),
  #                                      class = "panel-body"
  #                                    ),
  #                                    class = "panel panel-primary"
  #                                  )
  #                           ),
  #                           column(6,
  #                                  div(
  #                                    div(
  #                                      h3(textOutput("howExtremeText"), class = "panel-primary"),
  #                                      class = "panel-heading"
  #                                    ),
  #                                    div(
  #                                      conditionalPanel(condition =  "input.adjustmentChoice != 4",
  #                                      wellPanel(
  #                                        sliderInput("GPDWallHeightInput",
  #                                                    label = list(
  #                                                      h4("Choose how rare the event should be."),
  #                                                      uiOutput("howExtremeSliderLabel")
  #                                                    ), min = 2, max = 1000, value = 100
  #                                        )
  #                                      ),
  #                                      p("A once in a ",textOutput("GPDWallHeightInput", ,T),"- year event corresponds to an exceedance probability ",htmlOutput("GPDWallHeightP",T), " (to 4 significant figures)."),
  #                                      withMathJax(
  #                                        p("We would expect to see a return level of"),
  #                                        uiOutput("GPDWallHeightCalculation",T),
  #                                        checkboxInput("standardErrorGPDWall", "Include Standard Error", FALSE)
  #                                      )
  #                                      ),
  #                                      conditionalPanel(condition =  "input.adjustmentChoice == 4",
  #                                       withMathJax(
  #                                         uiOutput("EI.RLpreamble"),
  #                                         uiOutput("GPD.EI.RL.CALC"),
  #                                         checkboxInput("standardErrorEIRL", "Include Standard Error", FALSE)
  #                                         )
  #                                      ),
  #                                      class = "panel-body"
  #                                    ),
  #                                    class = "panel panel-primary"
  #                                  )
  #                           )
  #                         )
  #                ),
  #                 conditionalPanel(condition = "input.analysisChoice == 2",
  #                                  tabsetPanel("Bayesian Inference",
  #                                              tabPanel("Parameter Analysis",
  #                                                       fluidRow(
  #                                                         column(2,
  #                                                                wellPanel(
  #                                                                  numericInput("iterations", "Iterations:", value = 100)
  #                                                                )
  #                                                         ),
  #                                                         column(2,
  #                                                                actionButton("startmcmc" , "Click here to run your mcmc alogrithm")
  #                                                         )
  #                                                       ),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       #SIGMA STUFF
  #                                                       div(
  #                                                         fluidRow(
  #                                                           column(4,
  #                                                                  h2(HTML("&sigma;"), "  (Scale Parameter) :")
  #                                                           ),
  #                                                           column(2,
  #                                                                  h3("Posterior Mean:", textOutput("meansigma"), style = "color:blue")
  #                                                           ),
  #                                                           column(2,
  #                                                                  h3("Posterior SD:", textOutput("sdsigma"))
  #                                                           ),
  #                                                           column(2,
  #                                                                  h3("Posterior Mode:", textOutput("modeLOGSIGMA"), style = "color:green")
  #                                                           ),
  #                                                           column(2,
  #                                                                  h3(textOutput("titleaccproblogsigma",,T), "% CI: (",  textOutput("logsigmaCIlower",,T),",",textOutput("logsigmaCIupper",,T), ")", style = "color:red")
  #                                                           ),
  #                                                           class = "panel-heading"
  #                                                         )
  #                                                       ),
  #                                                       div(
  #                                                         fluidRow(
  #                                                           column(6,
  #                                                                  plotOutput("tsplotlogsigma")
  #                                                           ),
  #                                                           column(6,
  #                                                                  plotOutput("actdensityplotlogsigma")
  #                                                           )
  #                                                         )
  #                                                         # plotOutput("tsplotlogsigma")
  #                                                       ),
  #                                                       h4("An ideal range for acceptance probabilities is 20-30%. For the scale parameter", HTML("&sigma;"), "yours is", textOutput("accprobnologsigma",,T), "%", textOutput("acceptanceproblogsigmatext",,T)),
  #
  #                                                       fluidRow(
  #                                                         column(3,
  #                                                                wellPanel(
  #                                                                  h5(tags$b("Prior Standard Deviation for the scale parameter", HTML("&sigma;"), ":"), style = "color:black"),
  #                                                                  selectInput("SigmaSD", "",
  #                                                                              choices = list("1" = 1,
  #                                                                                             "10" = 10,
  #                                                                                             "100" = 100,
  #                                                                                             "1000" = 1000,
  #                                                                                             "10000" = 10000),
  #                                                                              selected = 1000)
  #                                                                )
  #                                                         ),
  #                                                         column(3,
  #                                                                wellPanel(
  #                                                                  h5(tags$b("Random walk variance for the scale parameter", HTML("&sigma;"), ":"), style = "color:black"),
  #                                                                  numericInput("RWVLogsigma", "", value = 0.1)
  #                                                                )
  #                                                         ),
  #                                                         column(3,
  #                                                                wellPanel(
  #                                                                  h5(tags$b("Smoothness for your density plot of ", HTML("&sigma;"), ":"), style = "color:black"),
  #                                                                  sliderInput("denSmoothlogsigma", "", min = 0.05, max = 2, value = 1, step = 0.05)
  #                                                                )
  #                                                         ),
  #                                                         column(3,
  #                                                                wellPanel(
  #                                                                  h5(tags$b("Required % confidence interval for", HTML("&sigma;"), ":"), style = "color:black"),
  #                                                                  sliderInput("CILOGSIGMAslider", "", min = 80, max = 99, value = 5)
  #                                                                )
  #                                                         )
  #                                                       ),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       #XI STUFF
  #                                                       fluidRow(
  #                                                         column(4,
  #                                                                h2(HTML("&xi;"), "  (Shape Parameter) :")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior Mean:", textOutput("meanxi"), style = "color:blue")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior SD:", textOutput("sdxi"))
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior Mode:", textOutput("modeXI"), style = "color:green")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3(textOutput("titleaccprobxi",,T), "% CI: (" ,textOutput("xiCIlower",,T),",",textOutput("xiCIupper",,T), ")", style = "color:red")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                plotOutput("tsplotxi")
  #                                                         ),
  #                                                         column(6,
  #                                                                plotOutput("actdensityplotxi")
  #                                                         )
  #                                                       ),
  #                                                       # plotOutput("densityplotxi"),
  #                                                       h4("An ideal range for acceptance probabilities is 20-30%. For the shape parameter", HTML("&xi;"), "yours is", textOutput("accprobnoxi",,T), "%", textOutput("acceptanceprobxitext",,T)),
  #
  #                                                       fluidRow(
  #                                                         column(3,
  #                                                                wellPanel(
  #                                                                  h5(tags$b("Prior Standard Deviation for the shape parameter", HTML("&xi;"), ":"), style = "color:black"),
  #                                                                  selectInput("XiSD", "",
  #                                                                              choices = list("1" = 1,
  #                                                                                             "10" = 10,
  #                                                                                             "100" = 100,
  #                                                                                             "1000" = 1000,
  #                                                                                             "10000" = 10000),
  #                                                                              selected = 100)
  #                                                                )
  #                                                         ),
  #                                                         column(3,
  #                                                                wellPanel(
  #                                                                  h5(tags$b("Random walk variance for the shape parameter", HTML("&xi;"), ":"), style = "color:black"),
  #                                                                  numericInput("RWVXi", "", value = 0.1)
  #                                                                )
  #                                                         ),
  #                                                         column(3,
  #                                                                wellPanel(
  #                                                                  h5(tags$b("Smoothness for your density plot of ", HTML("&xi;"), ":"), style = "color:black"),
  #                                                                  sliderInput("denSmoothxi", "", min = 0.05, max = 2, value = 1, step = 0.05)
  #                                                                )
  #                                                         ),
  #                                                         column(3,
  #                                                                wellPanel(
  #                                                                  h5(tags$b("Required % confidence interval for", HTML("&xi;"), ":"), style = "color:black"),
  #                                                                  sliderInput("CIXIslider", "", min = 80, max = 99, value = 5)
  #                                                                )
  #                                                         )
  #                                                       ),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       tags$hr(style = "border-color:black")
  #                                              ),
  #
  #                                              #################################
  #                                              ################################  GOODNESS OF FIT
  #
  #                                              tabPanel("Goodness of Fit",
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                plotOutput("Pplotbayes")
  #                                                         ),
  #                                                         column(6,
  #                                                                plotOutput("QQplotbayes")
  #                                                         )
  #                                                       )
  #                                              ),
  #
  #
  #                                              ##################                   RETURN LEVEL
  #                                              ##################
  #
  #                                              tabPanel("Return Level Analysis",
  #
  #                                                       ################# 50 years ###################
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                h2("Return Level, 50 Years:")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(2,
  #                                                                h3("Posterior Mean:", textOutput("meanRL50"), style = "color:blue")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior SD:", textOutput("sdRL50"))
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior Mode:", textOutput("modeRL50"), style = "color:green")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3(textOutput("titleaccprobrl50",,T), "% CI: (" ,textOutput("RLCIlower50",,T),",",textOutput("RLCIupper50",,T), ")", style = "color:red")
  #                                                         ),
  #                                                         column(4,
  #                                                                h3("Predictive Return Level, 50 years:", textOutput("PRL501"), style = "color:orange")  ## use inline = T to keep on same line
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                plotOutput("tsplotRL50")
  #                                                         ),
  #                                                         column(6,
  #                                                                plotOutput("densplotRL50")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                wellPanel(
  #                                                                  sliderInput("CIRLslider50", "Required % confidence interval for return level:", min = 80, max = 99, value = 95)
  #                                                                )
  #                                                         ),
  #                                                         column(6,
  #                                                                wellPanel(
  #                                                                  sliderInput("RLsmooth50", "Smoothness of your density plot of return level:", min = 0.05, max = 2, value = 1)
  #                                                                )
  #                                                         )
  #                                                       ),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       ################# 100 years ###################
  #
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                h2("Return Level, 100 Years:")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(2,
  #                                                                h3("Posterior Mean:", textOutput("meanRL100"), style = "color:blue")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior SD:", textOutput("sdRL100"))
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior Mode:", textOutput("modeRL100"), style = "color:green")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3(textOutput("titleaccprobrl100",,T), "% CI: (" ,textOutput("RLCIlower100",,T),",",textOutput("RLCIupper100",,T), ")", style = "color:red")
  #                                                         ),
  #                                                         column(4,
  #                                                                h3("Predictive Return Level, 100 years:", textOutput("PRL1001"), style = "color:orange")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                plotOutput("tsplotRL100")
  #                                                         ),
  #                                                         column(6,
  #                                                                plotOutput("densplotRL100")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                wellPanel(
  #                                                                  sliderInput("CIRLslider100", "Required % confidence interval for return level:", min = 80, max = 99, value = 95)
  #                                                                )
  #                                                         ),
  #                                                         column(6,
  #                                                                wellPanel(
  #                                                                  sliderInput("RLsmooth100", "Smoothness of your density plot of return level:", min = 0.05, max = 2, value = 1)
  #                                                                )
  #                                                         )
  #                                                       ),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       ################# 500 years ###################
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                h2("Return Level, 500 Years:")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(2,
  #                                                                h3("Posterior Mean:", textOutput("meanRL500"), style = "color:blue")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior SD:", textOutput("sdRL500"))
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior Mode:", textOutput("modeRL500"), style = "color:green")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3(textOutput("titleaccprobrl500",,T), "% CI: (" ,textOutput("RLCIlower500",,T),",",textOutput("RLCIupper500",,T), ")", style = "color:red")
  #                                                         ),
  #                                                         column(4,
  #                                                                h3("Predictive Return Level, 500 years:", textOutput("PRL5001"), style = "color:orange")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                plotOutput("tsplotRL500")
  #                                                         ),
  #                                                         column(6,
  #                                                                plotOutput("densplotRL500")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                wellPanel(
  #                                                                  sliderInput("CIRLslider500", "Required % confidence interval for return level:", min = 80, max = 99, value = 95)
  #                                                                )
  #                                                         ),
  #                                                         column(6,
  #                                                                wellPanel(
  #                                                                  sliderInput("RLsmooth500", "Smoothness of your density plot of return level:", min = 0.05, max = 2, value = 1)
  #                                                                )
  #                                                         )
  #                                                       ),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       ################# 1000 years ###################
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                h2("Return Level, 1000 Years:")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(2,
  #                                                                h3("Posterior Mean:", textOutput("meanRL1000"), style = "color:blue")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior SD:", textOutput("sdRL1000"))
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior Mode:", textOutput("modeRL1000"), style = "color:green")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3(textOutput("titleaccprobrl1000",,T), "% CI: (" ,textOutput("RLCIlower1000",,T),",",textOutput("RLCIupper1000",,T), ")", style = "color:red")
  #                                                         ),
  #                                                         column(4,
  #                                                                h3("Predictive Return Level, 1000 years:", textOutput("PRL10001"), style = "color:orange")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                plotOutput("tsplotRL1000")
  #                                                         ),
  #                                                         column(6,
  #                                                                plotOutput("densplotRL1000")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                wellPanel(
  #                                                                  sliderInput("CIRLslider1000", "Required % confidence interval for return level:", min = 80, max = 99, value = 95)
  #                                                                )
  #                                                         ),
  #                                                         column(6,
  #                                                                wellPanel(
  #                                                                  sliderInput("RLsmooth1000", "Smoothness of your density plot of return level:", min = 0.05, max = 2, value = 1)
  #                                                                )
  #                                                         )
  #                                                       ),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       ################# 5000 years ###################
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                h2("Return Level, 5000 Years:")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(2,
  #                                                                h3("Posterior Mean:", textOutput("meanRL5000"), style = "color:blue")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior SD:", textOutput("sdRL5000"))
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior Mode:", textOutput("modeRL5000"), style = "color:green")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3(textOutput("titleaccprobrl5000",,T), "% CI: (" ,textOutput("RLCIlower5000",,T),",",textOutput("RLCIupper5000",,T), ")", style = "color:red")
  #                                                         ),
  #                                                         column(4,
  #                                                                h3("Predictive Return Level, 5000 years:", textOutput("PRL50001"), style = "color:orange")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                plotOutput("tsplotRL5000")
  #                                                         ),
  #                                                         column(6,
  #                                                                plotOutput("densplotRL5000")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                wellPanel(
  #                                                                  sliderInput("CIRLslider5000", "Required % confidence interval for return level:", min = 80, max = 99, value = 95)
  #                                                                )
  #                                                         ),
  #                                                         column(6,
  #                                                                wellPanel(
  #                                                                  sliderInput("RLsmooth5000", "Smoothness of your density plot of return level:", min = 0.05, max = 2, value = 1)
  #                                                                )
  #                                                         )
  #                                                       ),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       tags$hr(style = "border-color:black"),
  #                                                       ################# 10000 years ###################
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                h2("Return Level, 10000 Years:")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(2,
  #                                                                h3("Posterior Mean:", textOutput("meanRL10000"), style = "color:blue")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior SD:", textOutput("sdRL10000"))
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior Mode:", textOutput("modeRL10000"), style = "color:green")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3(textOutput("titleaccprobrl10000",,T), "% CI: (" ,textOutput("RLCIlower10000",,T),",",textOutput("RLCIupper10000",,T), ")", style = "color:red")
  #                                                         ),
  #                                                         column(4,
  #                                                                h3("Predictive Return Level, 10000 years:", textOutput("PRL100001"), style = "color:orange")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                plotOutput("tsplotRL10000")
  #                                                         ),
  #                                                         column(6,
  #                                                                plotOutput("densplotRL10000")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                wellPanel(
  #                                                                  sliderInput("CIRLslider10000", "Required % confidence interval for return level:", min = 80, max = 99, value = 95)
  #                                                                )
  #                                                         ),
  #                                                         column(6,
  #                                                                wellPanel(
  #                                                                  sliderInput("RLsmooth10000", "Smoothness of your density plot of return level:", min = 0.05, max = 2, value = 1)
  #                                                                )
  #                                                         )
  #                                                       ),
  #                                                       p("Note: All distributions here are normal with mean 0 and SD of your choice, to keep prior ignorance")
  #                                              ),
  #                                              tabPanel("Return Level User Selected",
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                h2("Return Level,")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(2,
  #                                                                h3("Posterior Mean:", textOutput("meanRL"), style = "color:blue")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior SD:", textOutput("sdRL"))
  #                                                         ),
  #                                                         column(2,
  #                                                                h3("Posterior Mode:", textOutput("modeRL"), style = "color:green")
  #                                                         ),
  #                                                         column(2,
  #                                                                h3(textOutput("titleaccprobrl",,T), "% CI: (" ,textOutput("RLCIlower",,T),",",textOutput("RLCIupper",,T), ")", style = "color:red")
  #                                                         ),
  #                                                         column(4,
  #                                                                h3("Predictive Return Level,",tags$br(), textOutput("PRLyears",inline=T), textOutput("years",inline=T), textOutput("PRL1",inline=T), style = "color:orange")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                plotOutput("tsplotRL")
  #                                                         ),
  #                                                         column(6,
  #                                                                plotOutput("densplotRL")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(4,
  #                                                                wellPanel(
  #                                                                  numericInput("RLperiod", "Return Level Period", value = 50)
  #                                                                )
  #                                                         ),
  #                                                         column(4,
  #                                                                wellPanel(
  #                                                                  sliderInput("RLsmooth", "Smoothness of density of return level", min = 0.05, max = 2, value = 1, step = 0.05)
  #                                                                )
  #                                                         ),
  #                                                         column(4,
  #                                                                wellPanel(
  #                                                                  sliderInput("CIRLslider", "Required % confidence interval for return level:", min = 80, max = 99, value = 95)
  #                                                                )
  #                                                         )
  #                                                       )
  #                                              ),
  #                                              tabPanel("Return Level Plot",
  #                                                       actionButton("PRLRLplot", "Click here to show a graph of predictive return level and mean return level vs the return period"),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                plotOutput("newRLplot")
  #                                                         ),
  #                                                         column(6,
  #                                                                tags$hr(style = "border-color:white"),
  #                                                                tags$hr(style = "border-color:white"),
  #                                                                tableOutput("SummaryTableRL")
  #                                                         )
  #                                                       ),
  #                                                       fluidRow(
  #                                                         column(6,
  #                                                                h3("(", tags$b("Warning:"), " Iterations of ", tags$i("10000"), "  will infer a process time of up to ", tags$i("20"), "  minutes for this graph. During which you will ", tags$i("not"), "  be able to complete any other actions on the app.)")
  #                                                         ),
  #                                                         column(3,
  #                                                                wellPanel(
  #                                                                  numericInput("RLperiodgraph", "Type the period for the 7th row of your summary table:", value = 50)
  #                                                                )
  #                                                         ),
  #                                                         column(3,
  #                                                                wellPanel(
  #                                                                  sliderInput("CIRLslidergraph", "Required % confidence interval for return level:", min = 80, max = 99, value = 95)
  #                                                                )
  #                                                         )
  #                                                       )
  #                                              )
  #                                  )
  #                                  )
  #       )#End of Probability Model
      #)
    ), # End of Navbar
    tags$footer(
      HTML("<p><b>Bae</b> | <b>Ba</b>yesian <b>e</b>xtreme-value analysis<br>
        Application Developers: Keith Newman / Amy Green<br>
        Statistical Development: Amy Green / Lee Fawcett</p>"),
      style = "border-top:1px solid #ecf0f1;margin-top: 21px;padding-top: 18px;text-align: left;font-size: 0.8em;"
    ), # End of Footer
    useShinyjs()
  )
)
