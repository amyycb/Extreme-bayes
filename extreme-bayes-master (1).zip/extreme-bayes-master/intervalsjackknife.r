#test<-c(18,19, 20, 19, 18, 19, 16, 22, 23, 22, 13, 18, 20, 16, 15, 16, 14, 18, 19, 18, 16, 15, 16, 19, 21,16, 18, 15, 14, 20, 21, 16, 15, 14, 13, 14, 18, 16, 19, 20, 16, 14, 13)

library(evd)

#source("extreme.r")

gumbelsim<-function(n,alpha,seed)
{
        f<-function (z,x,v)
                {
                ((1+exp(-z/alpha))**(alpha-1))*exp(-exp(-x)*((1+exp(-z/alpha
))**alpha-1))-v
                }
                        
        sim<-vector("numeric",n)

        x<-seed
        for (i in 1:n)
                {
                        v<-runif(1)
                        y<-uniroot(f,c(-100,100),tol=0.0001,x,v)
                        sim[i]<-x+y$root
                        x<-sim[i]
                }
        return(sim)     
}

GPDsim<-function(n,alpha,sigma,xi,seed)
  {
    test<-gumbelsim(n,alpha,seed)
    test2<-(sigma/xi)*((1-exp(-exp(-test)))**(-xi)-1)
    return(test2)
  }

    
maxima<-function(data,k)
  {
    blockmax<-vector("numeric",length(data)/k)
    for(i in 1:length(blockmax))
      {
        blockmax[i]<-max(data[((k*i)-(k-1)):(k*i)])
      }
    blockmax
  }




#Return level function including theta
lee.q<-function(sigma,xi,theta,thresh,lambda,period,obs)
  {
    q<-thresh+(sigma/xi)*(((1/lambda)*((1-(1-(1/(period*obs)))**(1/theta))))**(-xi)-1)
    q
  }

#Edited clustering function
clusters1<-function (data, u, r = 1, ulow = -Inf, rlow = 1, cmax = FALSE, 
    keep.names = TRUE, plot = FALSE, xdata = seq(along = data), 
    lvals = TRUE, lty = 1, lwd = 1, pch = par("pch"), col = if (n > 
        250) NULL else "grey", xlab = "Index", ylab = "Data", 
    ...) 
{
    n <- length(data)
    if (length(u) != 1) 
        u <- rep(u, length.out = n)
    if (length(ulow) != 1) 
        ulow <- rep(ulow, length.out = n)
    if (any(ulow > u)) 
        stop("`u' cannot be less than `ulow'")
    if (is.null(names(data)) && keep.names) 
        names(data) <- 1:n
    if (!keep.names) 
        names(data) <- NULL
    high <- as.double((data > u) & !is.na(data))
    high2 <- as.double((data > ulow) | is.na(data))
    clstrs <- .C("clusters", high, high2, n, as.integer(r), as.integer(rlow), 
        clstrs = double(3 * n), PACKAGE = "evd")$clstrs
    clstrs <- matrix(clstrs, n, 3)
    start <- clstrs[, 2]
    end <- clstrs[, 3]
    splvec <- clstrs[, 1]
    lee<-as.matrix(cbind(data,splvec,seq(1,length(data),1)))
    return(lee)}
###############################################################################

block.jack<-function(data,thresh,period,obs){

  ind<-seq(1,length(data),1)
    S<-ind[data>thresh]

    T<-vector("numeric",length(S)-1)
    for(i in 1:length(T)){
      T[i]<-S[i+1]-S[i]}

    if(max(T)<3){theta<-(2*((sum(T))^2))/((length(T))*(sum((T^2))))}
    if(max(T)>2){theta<-(2*((sum((T-1)))^2))/((length(T))*sum((T-1)*(T-2)))}

    theta<-min(1,theta)

  C1<-floor(theta*length(data[data>thresh]))
  Tsort<-sort(T,decreasing=TRUE)

  counter<-seq(1,length(Tsort),1)
  C<-min(counter[Tsort==Tsort[C1]])
  
  inter.cluster.times<-Tsort[1:(C-1)]

  intra.cluster.times<-Tsort[C:length(Tsort)]
  #equivalent to runs declustering with kappa=max(intra.cluster.times)
  lee<-clusters1(data,u=thresh,r=max(intra.cluster.times))

  cluster.id<-seq(min(lee[,2]),max(lee[,2]),1)
  cluster.id<-cluster.id[cluster.id>0]

  J<-(length(inter.cluster.times))*(length(cluster.id))
  
  jack.theta<-vector("numeric",J)
  jack.sigma<-vector("numeric",J)
  jack.xi<-vector("numeric",J)
  jack.lambda<-vector("numeric",J)
  jack.q<-vector("numeric",J)

  
  #Now the jackknifing begins!

  for(k in 1:length(inter.cluster.times)){
    jack.inter.cluster.times<-inter.cluster.times[-k] #remove the kth inter cluster time

    for(p in 1:length(cluster.id)){

      coonter<-(k*p)+(k-1)*((length(cluster.id))-p)
      
      jack.cluster.id<-cluster.id[-p] #remove the pth cluster

      A<-as.data.frame(table(jack.cluster.id))
    
      lee2<-matrix(ncol=5,nrow=length(data))
      lee2[,1:3]<-lee
    
      for(j in 1:length(jack.cluster.id)){
        for(i in 1:length(data)){
          if(lee2[i,2]==jack.cluster.id[j]){lee2[i,4]<-jack.cluster.id[j]}}}
      for(j in 1:length(A[,1])){
        for(i in 1:length(data)){
          if(lee2[i,2]==A[j,1]){lee2[i,5]<-A[j,2]}}}

      row.names<-seq(1,length(lee2[,5][!is.na(lee2[,5])]),1)
      col.names<-c("data","cluster #","arrival time","cluster #2","repetitions")
    
    jools2<-matrix(ncol=5,nrow=length(lee2[,5][!is.na(lee2[,5])]),dimnames=list(row.names,col.names))
    jools2[,1]<-lee2[,1][!is.na(lee2[,5])]
    jools2[,2]<-lee2[,2][!is.na(lee2[,5])]
    jools2[,3]<-lee2[,3][!is.na(lee2[,5])]
    jools2[,4]<-lee2[,4][!is.na(lee2[,5])]
    jools2[,5]<-lee2[,5][!is.na(lee2[,5])]


    #6/7/11: Noticed we will have some negative exceedances, as for some clusters we have one or two within-cluster observations sub-threshold! (Look in column jools2[,1]). First of all - set these to NA? And then set arrival times to NA also?

    jools3<-jools2
    for(j in 1:length(jools3[,5])){
      if(jools3[j,1]<thresh){jools3[j,2]<-NA}
      if(jools3[j,1]<thresh){jools3[j,3]<-NA}
      if(jools3[j,1]<thresh){jools3[j,4]<-NA}
      if(jools3[j,1]<thresh){jools3[j,5]<-NA}
      if(jools3[j,1]<thresh){jools3[j,1]<-NA}}

    row.names<-seq(1,length(jools3[,5][!is.na(jools3[,5])]),1)
col.names<-c("data","cluster #","arrival time","cluster #2","repetitions")
    jools4<-matrix(ncol=5,nrow=length(jools3[,1][!is.na(jools3[,1])]),dimnames=list(row.names,col.names))
    jools4[,1]<-jools3[,1][!is.na(jools3[,1])]
    jools4[,2]<-jools3[,2][!is.na(jools3[,2])]
    jools4[,3]<-jools3[,3][!is.na(jools3[,3])]
    jools4[,4]<-jools3[,4][!is.na(jools3[,4])]
    jools4[,5]<-jools3[,5][!is.na(jools3[,5])]

    
    intra.cluster.times<-vector("numeric",length=(length(jools4[,5])-1))
    for(i in 1:length(intra.cluster.times)){
      if(jools4[i+1,2]==jools4[i,2]){intra.cluster.times[i]<-jools4[i+1,3]-jools4[i,3]}
      else(intra.cluster.times[i]<-NA)}

    G<-as.matrix(cbind(intra.cluster.times,jools4[1:(length(jools4[,5])-1),5]))

    jack.intra.cluster.times<-rep.int(G[,1],times=G[,2])
    jack.intra.cluster.times<-jack.intra.cluster.times[!is.na(jack.intra.cluster.times)]
    
    jack.exceedances<-rep.int(jools4[,1],times=jools4[,5])

    #So the bootstrapped intra-cluster times are in boot.intra.cluster.times, the bootstrapped inter-cluster times are in boot.inter.cluster.times, and the actual (bootstrapped) observations associated with the boostrapped intra-cluster times are in boot.exceedances

    #IT WORKS!!! So now we can use something like mle.gpd7 directly on "boot.exceedances" to get lambda, sigma and xi, and we need to use the ferro formula on c(boot.intra.cluster.times,boot.inter.cluster.times) to get theta!!
    
    K<-mle.gpd7(jack.exceedances-thresh)
    jack.sigma[coonter]<-K$est[1]
    jack.xi[coonter]<-K$est[2]
    jack.lambda[coonter]<-length(jack.exceedances)/length(data)
    new.T<-c(jack.intra.cluster.times,jack.inter.cluster.times)
     if(max(new.T)<3){THETA<-(2*((sum(new.T))^2))/((length(new.T))*(sum((new.T^2))))}
    if(max(new.T)>2){THETA<-(2*((sum((new.T-1)))^2))/((length(new.T))*sum((new.T-1)*(new.T-2)))}

    jack.theta[coonter]<-min(1,THETA)
    
    jack.q[coonter]<-lee.q(jack.sigma[coonter],jack.xi[coonter],jack.theta[coonter],thresh,jack.lambda[coonter],period,obs)
      print(c(coonter,jack.sigma[coonter],jack.xi[coonter],jack.lambda[coonter],jack.theta[coonter],jack.q[coonter]))}}
    
   return(cbind(jack.sigma,jack.xi,jack.lambda,jack.theta,jack.q))}

  
    
    
    
    
    
  
  
  
