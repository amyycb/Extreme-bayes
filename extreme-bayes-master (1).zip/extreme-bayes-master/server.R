library(shiny)
library(shinyjs)
library(ggplot2)
library(dygraphs)
library(xts)
library(plotly)
library(texmex)
library(gridExtra)
# Increase maximum file size you can upload to Shiny. 30*1024^2 for a 30MB file.
options(shiny.maxRequestSize=30*1024^2)

shinyServer(
  function(input, output, session) {

    # ===================  DATA UPLOAD =====================

    # Create a data frame from the uploaded data file
    dataUpload <- reactive({
      if (input$dataSourceSelection == "user") {
        # Do nothing until the data is uploaded
        req(input$dataIn)

        tryCatch(a <- read.table(input$dataIn$datapath,
                                 header = input$headerControl,
                                 sep = input$sepControl,
                                 quote = input$quoteControl,
                                 skip = input$dataUploadLineSkips),
                 error = function(e) print(e))
      } else { # For pre-loaded data
        # Set values based on the preloaded dataset.
        headr <- TRUE
        sepr <- ","
        quot <- '"'
        skp <- switch(input$preloadDataSelection,
                      "maxtemp" =, "snowdepth" = 20,
                      "sealevelpressure" =, "sunshine" = 21,
                      0)

        # Load in the data
        a <- read.table(paste0("data/", input$preloadDataSelection, ".txt"),
                        header = headr,
                        sep = sepr,
                        quote = quot,
                        skip = skp)
      }
      return(a)
    })

    # Preview table for the uploaded data.
		output$dataUploadPreview1 <- DT::renderDataTable({
        req(dataUpload())
        return(dataUpload())
      },
			options = list(
				pageLength = 10,
				lengthMenu = list(c(10, 25, 50, -1),
                          c('10', '25', '50', 'All')),
				searching = FALSE
			)
		)

    dataUploadColnames <- reactive({
      req(dataUpload())
      return(colnames(dataUpload()))
    })

    ## ------------  Extract datestamps --------------------

    output$datestampColumnSelectUI <- renderUI({
      return(selectInput("datestampColumnName",
                         "Column containing datestamps:",
                         choices = dataUploadColnames()))
    })

    # Date from uploaded data that is not yet converted into date stamp.
    rawDateStamp <- reactive({
      req(dataUpload(), input$dateStampColumnName)
      return(dataUpload()[, input$dateStampColumnName])
    })

    # Date stamps converted into an actual datestamp
    convertedDateStamp <- reactive({
      return(as.POSIXct(as.character(rawDateStamp()), format = input$dateStampFormat))
    })

    # Show Date before conversion to a datestamp
    output$dateStampRaw <- renderPrint({return(head(rawDateStamp()))})

    # Show Date after conversion to a datestamp. For format codes: see ?strftime
    output$dateStampInterpreted <- renderPrint({
      return(format(head(convertedDateStamp()), format = "%A, %d %B %Y at %T"))
    })

    output$dateStampRangeUI <- renderUI({
      dateRange <- range(convertedDateStamp())
      return(dateRangeInput("dateRange",
                            "Range of dates to use in analysis (inclusive)",
                            start = dateRange[1],
                            end = dateRange[2],
                            startview = "decade"))
    })

    ## ------------------ Select Data column for analysis ---------------------

    ## Update the choices of column names when a dataset has been uploaded.
    observe({
      x <- dataUploadColnames()
      if (input$dataSourceSelection == "user") {
        updateSelectInput(session, "dateStampColumnName", choices = x)
        updateSelectInput(session, "dataValueColumnSelectUI", choices = x)
      } else { # Pre-loaded datasets
        dtCol <- switch(input$preloadDataSelection,
                        "DATE")
        dtStp <- switch(input$preloadDataSelection,
                        "%Y%m%d")
        vlCol <- switch(input$preloadDataSelection,
                        "maxtemp" = "TX",
                        "snowdepth" = "SD",
                        "sealevelpressure" = "PP",
                        "sunshine" = "SS")
        mssVal <- switch(input$preloadDataSelection,
                         "maxtemp" =, "snowdepth" = ,
                         "sealevelpressure" =, "sunshine" = -9999,
                         NA_real_)

        # Change some form inputs
        updateSelectInput(session, "dateStampColumnName", choices = x, selected = dtCol)
        updateSelectInput(session, "dateStampFormatdateStampFormat", selected = dtStp)
        updateSelectInput(session, "dataValueColumnSelectUI", choices = x, selected = vlCol)
        updateCheckboxInput(session, "dataHasMissingValues", value = TRUE)
        updateNumericInput(session, "missingValueCode", value = mssVal)
      }
    })

    # Create a vector of the values of interest
    rawDataValues <- reactive({
      req(dataUpload(), input$dataValueColumnSelectUI %in% dataUploadColnames())
      return(dataUpload()[, input$dataValueColumnSelectUI])
    })

    # Data frame that has been trimmed and NA removed will be called dat()
    dat <- reactive({
      req(input$dataValueColumnSelectUI %in% dataUploadColnames(), input$dateRange)
      d <- data.frame(value = dataUpload()[, input$dataValueColumnSelectUI],
                      timestamp = convertedDateStamp())
      colnames(d)[1] <- input$dataValueColumnSelectUI

      # Trim the observations to only include what's in the selected date range.
      d <- d[(convertedDateStamp() >= as.POSIXct(input$dateRange[1]) &
              convertedDateStamp() <= as.POSIXct(input$dateRange[2])), ]

      # Average number of observations per year (PLEASE CHECK THIS KEITH)
      nPeriod = abs(365.25 * nrow(d) / as.numeric(difftime(as.POSIXct(input$dateRange[1]), as.POSIXct(input$dateRange[2]), units = "days")))

      # If a code other than NA is used for missing values, change them to NA
      if (input$dataHasMissingValues) {
        req(input$missingValueCode)
        d[d[, input$dataValueColumnSelectUI] == input$missingValueCode, input$dataValueColumnSelectUI] = NA
      }

      # Remove all rows containing a missing value
      d <- na.omit(d)

      # Add columns for Day, Month, Quarter and Year
      d$Day <- factor(format(d$timestamp, "%d"), levels = format(ISOdate(2000, 1, 1:31), "%d"))
      d$Weekday <- factor(weekdays(d$timestamp), levels = format(ISOdate(2000, 1, 2:8), "%A"))
      d$Month <- factor(months(d$timestamp), levels = month.name)
      d$Quarter <- factor(quarters(d$timestamp), levels = c("Q1", "Q2", "Q3", "Q4"))
      d$Year <- format(d$timestamp, "%Y")

      return(list(d = d, nPeriod = nPeriod))
    })

    output$numberOfObservationsRetained <- renderText({
      return(nrow(dat()[[1]]))
    })

    output$numberOfMissingRowsRemoved <- renderText({
      return(length(attr(dat()[[1]], "na.action")))
    })

    # Create preview of the first 50 data values
    output$dataValuePreview <- renderPrint({return(head(rawDataValues(), 50))})

    # Convert data into an xts (time-series) format for the plot
    dygraphData <- reactive({
      return(as.xts(dat()[[1]][, input$dataValueColumnSelectUI], order.by = dat()[[1]][, 2]))
    })

    # Plot the time-series of the values.
    output$SelectedDataTimeSeries <- renderDygraph({
      req(dygraphData())
      dygraph(dygraphData(), main = "Time-series of supplied values") %>%
              dyOptions(drawGrid = TRUE) %>%
              dyRangeSelector(height = 20)
    })

    # Produce the boxplot of the output
    output$splitBoxplots <- renderPlotly({
      g <- ggplot(dat()[[1]], aes_string(y = input$dataValueColumnSelectUI))
      if (isTruthy(input$dataSplittingForPlots)) {
        g <- g + geom_boxplot(aes_string(x = input$dataSplittingForPlots))
      } else {
        g <- g + geom_boxplot(aes(x = factor(0))) + xlab("All Data") + coord_flip()
      }
      g <- g + theme_bw()
      return(ggplotly(g))
    })
    ## -------------------  Amy  -------------------------------------------
    #
    # splitDat <- reactive({
    #   switch(input$dataSplittingForAnalysis,
    #     "Monthly" = lapply(1:12, function(m) { dat()[as.numeric(format(dat()[,2], '%m')) == m, 1]}),
    #     "Quarterly" = lapply(1:12, function(q) { dat()[as.numeric(format(dat()[,2], '%q')) == q, 1]}),
    #     "Yearly" = lapply(1:12, function(y) { dat()[as.numeric(format(dat()[,2], '%m')) == y, 1]}),
    #     "Overall" = list(dat()[, 1])
    #   )
    # })
    #

    # splitFunction <- reactive({
    #   function(time) {
    #     lapply(1:max(d$time), function(t) { dat()[d$time == t, 1]})
    #   }
    # })

  ## ------------------------------- THRESHOLD SELECTION TAB ---------------------------------- ##

    splitFunction <- function(time) {
      return(split(dat()[[1]][, 1], dat()[[1]][, time]))
    }

    # splits data into appropriate lists for seasonality
    splitDat <- reactive({
      switch(input$dataSplittingForAnalysis,
             "Monthly" = splitFunction("Month"),
             "Quarterly" = splitFunction("Quarter"),
             # "Yearly" = splitFunction(Year),
             "Overall" = list(dat()[[1]][, 1])
      )
    })

    # mrl plots
    mrlDat <- reactive({
      lapply(1:length(splitDat()),
        function(t) {
          as.data.frame(mrl(splitDat()[[t]], umin = min(splitDat()[[t]]), umax = max((splitDat()[[t]]) - 0.1), nint = 100, alpha=.050)$mrl)
        }
      )
    })

    mrlPlot <- reactive({
      lapply(1:length(splitDat()),
        function(t) {
          g <- ggplot(data=mrlDat()[[t]], aes(x=mrlDat()[[t]]$threshold, y=mrlDat()[[t]]$MRL)) +
            geom_ribbon(aes(x=mrlDat()[[t]]$threshold, ymin=mrlDat()[[t]]$lo, ymax=mrlDat()[[t]]$hi), fill='darkolivegreen3', alpha=0.6) +
            geom_line(aes(x=mrlDat()[[t]]$threshold, y=mrlDat()[[t]]$MRL), color='forestgreen', size=1) +
            geom_vline(xintercept = as.numeric(threshold()[[t]]), colour='firebrick2', linetype=2, size=1) +
            theme_bw() +
            theme(plot.title = element_text(hjust = 0.5))

          quarter.name <- c('Q1', 'Q2', 'Q3', 'Q4')
          # year.name <- seq(from=min(d$Year), to=max(d$Year), by=1)
          switch(input$dataSplittingForAnalysis,
           "Monthly" = g + labs(x='Threshold', y='MRL', title=paste('MRL Plot for ', month.name[t])),
           "Quarterly" = g + labs(x='Threshold', y='MRL', title=paste('MRL Plot for ', quarter.name[t])),
           # "Yearly" = g + labs(x='Threshold', y='MRL', title=paste('MRL Plot for ', year.name [t])),
           "Overall" = g + labs(x='Threshold', y='MRL', title='MRL Plot for Overall Analysis')
          )
        }
      )
    })

    observe({
      lapply(1:length(splitDat()), function(id) {
          output[[paste0("mrlPlot", id)]] <- renderPlot({mrlPlot()[[id]]})
          output[[paste0("threshChoiceText", id)]] <- renderText({paste0("The calculated threshold is ", threshold()[[id]], ".")})
        }
      )
    })

    # output <- renderPlot({ mrlPlot[[t]] })
    # exeedences <- reactive({
    #   lapply(1:length(splitDat),
    #     function(t) {
    #       splitDat[[t]][splitDat[[t]] >= threshold()]
    #     }
    #   )
    # })
    #
    #MRL plot for overall analysis
    # mrlDat <- reactive({
    #   as.data.frame(mrl(dat()[,1], umin = min(dat()[,1]), umax = max(dat()[,1]) - 0.1, nint = 100, alpha=.050)$mrl)
    # })

    # output$MRLplot <- renderPlot({                                                #The MRL plot
    #   ggplot(data=mrlDat(), aes(x=mrlDat()$threshold, y=mrlDat()$MRL)) + geom_ribbon(aes(x=mrlDat()$threshold, ymin=mrlDat()$lo, ymax=mrlDat()$hi), fill='lightBlue', alpha=0.5) + geom_line(aes(x=mrlDat()$threshold, y=mrlDat()$MRL), color='red', size=1) + labs(x='Threshold', y='MRL', title='MRL Plot') + geom_vline(xintercept = as.numeric(threshold()), colour='blue', linetype=2) + theme_bw() + theme(plot.title = element_text(hjust = 0.5))
    # })

    threshold <- reactive({
      if (input$useMRLPlot) {
				return(
          lapply(1:length(splitDat()),
            function(id) {
              input[[paste0("threshMRLInput", id)]]
            }
          )
        )
      } else {
				return(
					lapply(1:length(splitDat()),
					function(t) {
						switch(input$quantileChoice,
							"99%" = round(quantile(splitDat()[[t]], 0.99), 2),
							"95%" = round(quantile(splitDat()[[t]], 0.95), 2),
							"90%" = round(quantile(splitDat()[[t]], 0.90), 2)
							)
						}
					)
				)
      }
    })

    #rate of threshold excesses
    lambdaRate <- reactive({
      lapply(1:length(splitDat()),
        function(id) {
          if(input$useMRLPlot) {
            return(
              length(inputDataMCMC()[[id]])/length(splitDat()[[id]])
            )
          } else {
            return(
              switch(input$quantileChoice,
    						"99%" = 0.01,
    						"95%" = 0.05,
    						"90%" = 0.1
              )
            )
          }
        }
      )
    })

    thresholdLabs <- reactive({
      switch(input$dataSplittingForAnalysis,
	      "Overall" = "Overall",
	      "Quarterly" = c("Q1", "Q2", "Q3", "Q4"),
	      "Monthly" = month.name
      )
    })

    observe({
      lapply(1:length(splitDat()), function(id) {
        output[[paste0("threshLabel", id)]] <- renderText({paste0(thresholdLabs()[id], " threshold:")})
        output[[paste0("dependenceTabLabel", id)]] <- renderText({thresholdLabs()[id]})
      })
    })

    # observe({
    #   switch(input$dataSplittingForAnalysis,
    #     "Overall" = lapply(2:length(splitDat()),
    #       function(id) {
    #         rm(list(output[[paste0("mrlPlot", id)]], output[[paste0("threshChoiceText", id)]]))
    #       }
    #     ),
    #     "Quarterly" = lapply(5:length(splitDat()),
    #       function(id) {
    #         rm(list(output[[paste0("mrlPlot", id)]], output[[paste0("threshChoiceText", id)]]))
    #       }
    #     )
    #   )
    # })

    # output$threshChoiceText <- renderText({                                      #This displays the generated quantile of the raw data
    #   return(paste0("The calculated threshold is  ", threshold()[[1]], ". (2 d.p.)"))  #Add the choice in bold
    # })

    ## -------------------- DEPENDENCE TAB ---------------------------------- ##

    # plot of the raw data
    observe({
      lapply(1:length(splitDat()),
             function(id) {
               splitDatTab <- data.frame(x = 1:length(splitDat()[[id]]), y = splitDat()[[id]])
               output[[paste0('rawPlot', id)]] <- renderPlot({
                 ggplot(data=splitDatTab, aes(x=x, y=y)) +
                   geom_point(size=1, colour='forestgreen') +
                   geom_line(colour='darkolivegreen3', alpha=0.4) +
                   geom_hline(yintercept = threshold()[[id]], colour='firebrick2') +
                   theme_bw() +
                   labs(x = 'Observation', y = 'Value', title = 'Plot of Raw Data') +
                   theme(plot.title = element_text(hjust = 0.5))
               })
             }
      )
    })

    # threshold exceedances
    excesses <- reactive({
      lapply(1:length(splitDat()),
             function(id) {
               splitDat()[[id]][splitDat()[[id]] >= threshold()[[id]]]
             }
      )
    })


    # Plot of threshold excesses
    observe({
      lapply(1:length(excesses()),
             function(id) {
               excessDat <- data.frame(x = 1:length(excesses()[[id]]), y = excesses()[[id]])
               output[[paste0('excessPlot', id)]] <- renderPlot({
                 ggplot(data=excessDat, aes(x=x, y=y)) +
                   geom_point(size=2, colour='forestgreen') +
                   geom_line(colour='darkolivegreen2', alpha=0.8, size=1) +
                   theme_bw() +
                   labs(x = 'Threshold Excess', y = 'Value', title = 'Plot of Threshold Exceedances') +
                   theme(plot.title = element_text(hjust = 0.5))
               })
             }
      )
    })

    # scatterplot of successive observations
    successTab <- reactive({
      lapply(1:length(splitDat()),
             function(id) {
               data.frame(x1 = splitDat()[[id]][1:length(splitDat()[[id]]) - 1], x2 = splitDat()[[id]][2:length(splitDat()[[id]])])
             }
      )
    })

    observe({
      lapply(1:length(splitDat()),
             function(id) {
               output[[paste0('scatterplot', id)]] <- renderPlot({
                 ggplot(data=successTab()[[id]], aes(x=x1, y=x2)) +
                   geom_point(size=2, colour='forestgreen', alpha=0.4) +
                   theme_bw() +
                   geom_vline(xintercept = threshold()[[id]], colour='firebrick2', linetype=2, size=1) +
                   geom_hline(yintercept = threshold()[[id]], colour='firebrick2', linetype=2, size=1) +
                   labs(x = expression(X[1]), y = expression(X[2]), title = 'Scatterplot of Successive Observations') +
                   theme(plot.title = element_text(hjust = 0.5))
               })
             }
      )
    })

    # partial autocorrelation plot
    pACF <- reactive({
      lapply(1:length(excesses()),
             function(id) {
               a <- pacf(excesses()[[id]], plot = FALSE)
               data.frame(Lag = a$lag, PACF = a$acf)
             }
      )
    })

    observe({
      lapply(1:length(splitDat()),
             function(id) {
               output[[paste0('pacf', id)]] <- renderPlot({
                 ggplot(data=pACF()[[id]], mapping=aes(x=Lag, y=PACF)) +
                   geom_bar(stat = "identity", position = "identity", fill='forestgreen', colour='forestgreen', alpha=0.8, width=0.1) +
                   theme_bw() +
                   labs(y = 'pacf', title = 'Partial Autocorrelation Plot') +
                   theme(plot.title = element_text(hjust = 0.5))
               })
             }
      )
    })

    #dependence tabs for the ui
    makeDependenceTabs <- function(id) {
      return(
        tabPanel(paste(thresholdLabs()[id]),
          fluidRow(
            h4(paste0(thresholdLabs()[id]))
          ),
          fluidRow(
            column(6,
              plotOutput(paste0("rawPlot", id))
            ),
            column(6,
              plotOutput(paste0("excessPlot", id))
            )
          ),
          fluidRow(
            column(6,
              plotOutput(paste0("scatterplot", id))
            ),
            column(6,
              plotOutput(paste0("pacf", id))
            )
          )
        )
      )
    }

    output$dependenceTabs = renderUI({
      dependenceTabs <- lapply(1:length(splitDat()), makeDependenceTabs)
      do.call(tabsetPanel, dependenceTabs)
    })


    #data for mcmc
    inputDataMCMC <- reactive({
      switch(input$dependenceMethod,
        "depend" = splitDat(),
        "decl" = lapply(1:length(splitDat()),
          function(id) {
            clusterMax(splitDat()[[id]], threshold()[[id]], input$declusterKappa)[, 2] - threshold()[[id]]
          }
        ),
        "none" = lapply(1:length(splitDat()),
          function(id) {
						excesses()[[id]] - threshold()[[id]]
					}
				)
      )
    })

    ## ------------------- RUN MCMC TAB ------------------------------------
    library(gevtools)

    # pilot mcmc scheme
    pilotMCMCFunction <- eventReactive(input$pilotMCMCButton, {
      # Disable runSimulation button and print a "running" message
			session$sendCustomMessage("startingSimulation", "pilotMCMCButton")

      mcmc <- lapply(1:length(inputDataMCMC()),
        function(id) {
          n <- length(inputDataMCMC()[[id]])
          data <- data.frame(inputDataMCMC()[[id]][1:(n-1)],
														 inputDataMCMC()[[id]][2:n])
          mc <- switch(input$dependenceMethod,
            "depend" = {
              bimc <- bivarGPD_MCMC(
                nIter = 1000,
                dataset = data,
                thresholds = c(threshold()[[id]], threshold()[[id]]),
                sigmastart = c(input$sigmaPriorMean, input$sigmaPriorMean),
                xistart = c(input$xiPriorMean, input$xiPriorMean),
                alphastart = 0.1,
                errlogsigma = c(input$errLogSigma, input$errLogSigma),
                errxi = c(input$errXi, input$errXi),
                erralpha = input$errAlpha,
                sdlogsigma = c(input$sigmaPriorSD, input$sigmaPriorSD),
                sdxi = c(input$xiPriorSD, input$xiPriorSD),
                lik.tol = 10,
                nThin = 1,
                nBurn = 200
              )
              bimc[, 5] <- 0.013 - 0.092*bimc[, 5] + 1.833*bimc[, 5]^2 - 0.756*bimc[, 5]^3 #calculates theta from alpha
              return(list(mc = bimc[, c(1, 3, 5)], ap = acceptanceProbability(bimc)[c(1, 3, 5)], means = mean(bimc)[c(1,  3, 5)]))
            },
            {
              gpdmc <- gpdMCMC(
                nIter = 1000,
                dataset = inputDataMCMC()[[id]],
                sigmastart = input$sigmaPriorMean,
                xistart = input$xiPriorMean,
                errlogsigma = input$errLogSigma,
                errxi = input$errXi,
                sdlogsigma = input$sigmaPriorSD,
                sdxi = input$xiPriorSD,
                nThin = 1,
                nBurn = 200
              )
              return(list(mc = gpdmc[, 1:2], ap = acceptanceProbability(gpdmc)[1:2], means = mean(gpdmc[1:2])))
            }
          )
          return(mc)
        }
      )

      # re-enable RunSimulation Button when finished
			session$sendCustomMessage("endingSimulation",
        list(id = "pilotMCMCButton", message = "Run new pilot MCMC")
      )

      return(mcmc)
    })

    pilotMCMC <- reactive({
      lapply(1:length(pilotMCMCFunction()),
        function(id) {
          pilotMCMCFunction()[[id]][[1]]
        }
      )
    })

    pilotAcceptanceProbs <- reactive({
			apTab <- do.call(
				rbind.data.frame,
				data.frame(
					sapply(pilotMCMCFunction(), '[[', 2, simplify = TRUE)
				)
			)
# 			colnames(apTab) <- switch(condition = input$dependenceMethod == 'depend',
# 			  c("log(sigma)", "xi", "theta"),
# 			  c("log(sigma)", "xi")
# 			)
			colnames(apTab) <- names(pilotMCMCFunction()[[1]][[2]])
			rownames(apTab) <- thresholdLabs()
			return(apTab)
    })

     # output$acceptanceProbTab <- renderTable({
     #   tab <- data.frame(
    #     sapply(1:length(pilotAcceptanceProbs()),
    #       function(id) {
    #         pilotAcceptanceProbs[[id]]
    #       }
    #     )
    #   )
    #   colnames(tab) <- unlist(thresholdLabs())
    # },
    # include.rownames = TRUE
    # )
    # outputOptions(
    #   output, "tab", priority = -2, suspendWhenHidden = FALSE
    # )

    output$pilotAcceptanceProbTab <- renderTable({pilotAcceptanceProbs()}, include.rownames = TRUE, include.colnames = TRUE)
    outputOptions(output, "pilotAcceptanceProbTab", priority = -2)

    #
    # observe({
    #   lapply(1:length(pilotMCMC()),
    #     function(id) {
    #       switch(input$dependenceMethod == 'depend',
    #         output[[paste0('pilotAPTab', id)]] <- renderTable({paste0(withMathJax("Acceptance probability"))})
    #
    #
    #       accProbs <- colMeans(na.omit(pilotMCMC()[[id]]))
    #       sapply(1:length(accProbs),
    #         function(param) {
    #           p
    #              }
    #           )
    #            output[[paste0('pilotAcceptanceProbs', id)]] <- renderPlot({
    # output$pilotAcceptanceProbs <- renderText({
    #   parameter <- switch(input$dependenceMethod, "depend" = c("eta", "xi", "theta"), c("eta", "xi"))
    #   returnp(withMathJax("The acceptance probability for \\( \\xi \\) is ")),
    #
    #   )
    # })

    # output$calcOutputIterations <- renderText({
    #   return(
    #     paste0("The total number of output iterations is  ", (round((input$numberIterations - input$burnIn) / input$thinning)), ".")
    #   )
    # })

    # mcmc scheme
    mcmcOutFunction <- eventReactive(input$runMCMCButton, {
      # Disable runSimulation button and print a "running" message
      session$sendCustomMessage("startingSimulation", "runMCMCButton")

      mcmc <- lapply(1:length(inputDataMCMC()),
        function(id) {
          n <- length(inputDataMCMC()[[id]])
          data <- data.frame(inputDataMCMC()[[id]][1:(n-1)],
														 inputDataMCMC()[[id]][2:n])
          mc <- switch(input$dependenceMethod,
            "depend" = {
              bimc <- bivarGPD_MCMC(
                nIter = input$numberIterations,
                dataset = data,
                thresholds = c(threshold()[[id]], threshold()[[id]]),
                sigmastart = c(input$sigmaPriorMean, input$sigmaPriorMean),
                xistart = c(input$xiPriorMean, input$xiPriorMean),
                alphastart = 0.5,
                errlogsigma = c(input$errLogSigma, input$errLogSigma),
                errxi = c(input$errXi, input$errXi),
                erralpha = input$errAlpha,
                sdlogsigma = c(input$sigmaPriorSD, input$sigmaPriorSD),
                sdxi = c(input$xiPriorSD, input$xiPriorSD),
                lik.tol = 13,
                nThin = input$thinning,
                nBurn = input$burnIn
              )
              bimc[, 5] <- 0.013 - 0.092*bimc[, 5] + 1.833*bimc[, 5]^2 - 0.756*bimc[, 5]^3 #calculates theta from alpha
              return(list(mc = bimc[, c(1, 3, 5)], ap = acceptanceProbability(bimc)[c(1, 3, 5)], means = mean(bimc)[c(1, 3, 5)]))
            },
            {
              gpdmc <- gpdMCMC(
                nIter = input$numberIterations, #((input$numberIterations + input$burnIn) * input$thinning),
                dataset = inputDataMCMC()[[id]],
                sigmastart = input$sigmaPriorMean,
                xistart = input$xiPriorMean,
                errlogsigma = input$errLogSigma,
                errxi = input$errXi,
                sdlogsigma = input$sigmaPriorSD,
                sdxi = input$xiPriorSD,
                nThin = input$thinning,
                nBurn = input$burnIn #need to add nBurn but i don't have the right version of gevtools
              )
              return(list(mc = gpdmc[, 1:2], ap = acceptanceProbability(gpdmc)[1:2], means = mean(gpdmc)[1:2]))
            }
          )
          return(mc)
        }
      )

      # re-enable RunSimulation Button when finished
      session$sendCustomMessage("endingSimulation",
        list(id = "runMCMCButton", message = "Re-run MCMC")
      )

      return(mcmc)
    })

    mcmcOut <- reactive({
      lapply(1:length(mcmcOutFunction()),
        function(id) {
          mcmcOutFunction()[[id]][[1]]
        }
      )
    })

    acceptanceProbs <- reactive({
			apTab <- do.call(
				rbind.data.frame,
				data.frame(
					sapply(mcmcOutFunction(), '[[', 2, simplify = TRUE)
				)
			)
# 			colnames(apTab) <- switch(condition = input$dependenceMethod == 'depend',
# 		    c("log(sigma)", "xi", "theta"),
# 			  c("log(sigma)", "xi")
# 			) #
			colnames(apTab)  <- names(mcmcOutFunction()[[1]][[2]])
			rownames(apTab) <- thresholdLabs()
			return(apTab)
    })

    # acceptance probabilityes table
    output$acceptanceProbTab <- renderTable({acceptanceProbs()}, include.rownames = TRUE, include.colnames = TRUE)
    outputOptions(output, "acceptanceProbTab", priority = -2)

    # mcmcOut <- eventReactive(input$runMCMCButton, {
    #   lapply(1:length(inputDataMCMC()),
    #          function(id) {
    #            n <- length(inputDataMCMC()[[id]])
    #            data <- data.frame(inputDataMCMC()[[id]][1:(n-1)], inputDataMCMC()[[id]][2:n])
    #            mc <- bivarGPD_MCMC(nIter = ((input$numberIterations + input$burnIn) * input$thinning),
    #              dataset = data,
    #              thresholds = c(threshold()[[id]], threshold()[[id]]),
    #              sigmastart = c(input$sigmaPriorMean, input$sigmaPriorMean),
    #              xistart = c(input$xiPriorMean, input$xiPriorMean),
    #              alphastart = 0.1,
    #              errlogsigma = c(input$errLogSigma, input$errLogSigma),
    #              errxi = c(input$errXi, input$errXi),
    #              erralpha = 0.01,
    #              sdlogsigma = c(input$sigmaPriorSD, input$sigmaPriorSD),
    #              sdxi = c(input$xiPriorSD, input$xiPriorSD),
    #              lik.tol = 10,
    #              nThin = thinning
    #            )
    #            return(mc[seq(input$burnIn, nrow(mc), by=input$thinning), ])
    #          }
    #   )
    # })

    mcmcOut <- reactive({
      lapply(1:length(mcmcOutFunction()),
        function(id) {
          mcmcOutFunction()[[id]][[1]]
        }
      )
    })

    acceptanceProbs <- reactive({
      aps <- lapply(1:length(mcmcOutFunction()),
        function(id) {
          mcmcOutFunction()[[id]][[2]]
        }
      )
      return(sapply(aps, as.vector))
    })

    outputNoIters <- reactive({
      return(nrow(mcmcOut()[[1]]))
    })

    tracePlotFunction <- function(id, dataset, iterations, names) {
      tab <- data.frame(Iteration = 1:iterations, Value = unlist(dataset))
      g <- ggplot(data=tab, aes(x = Iteration, y = Value)) +
        geom_line(col='forestgreen') +
        labs(title = paste(names[[id]], 'Trace Plot')) +
        theme_bw() +
        theme(plot.title = element_text(hjust = 0.5))
      return(g)
    }

    autocorrPlotFunction <- function(id, dataset, iterations, names) {
      A <- acf(dataset, plot = FALSE)
      ACFTab <- data.frame(Lag = A$lag, ACF = A$acf)
      g <- ggplot(data=ACFTab, mapping=aes(x=Lag, y=ACF)) +
        geom_bar(stat = "identity", position = "identity", fill='forestgreen', col='forestgreen', alpha=0.8, width=0.1) +
        theme_bw() +
        labs(y = 'acf', title = paste(names[[id]], 'Autocorrelation Plot')) +
        theme(plot.title = element_text(hjust = 0.5))
      return(g)
    }

    densityPlotFunction <- function(id, dataset, iterations, names) {
      g <- qplot(dataset, geom = "blank") +
        geom_density(col='forestgreen', fill='darkolivegreen2', alpha=0.6) +
        theme_bw() +
        labs(y = 'Density', x = 'Value', title = paste(names[[id]], 'Density Plot')) +
        theme(plot.title = element_text(hjust = 0.5))
      return(g)
    }

    # pilot parameter plots
    observe({
      lapply(1:length(pilotMCMC()),
        function(id) {
          output[[paste0('pilotSigmaPlot', id)]] <- renderPlot({
            g1 <- tracePlotFunction(id, pilotMCMC()[[id]][, 1], 1000, thresholdLabs())
            g2 <- autocorrPlotFunction(id, pilotMCMC()[[id]][, 1], 1000, thresholdLabs())
            g3 <- densityPlotFunction(id, pilotMCMC()[[id]][, 1], 1000, thresholdLabs())
            return(grid.arrange(g1, g2, g3, ncol=3))
          })
          output[[paste0('pilotXiPlot', id)]] <- renderPlot({
            g1 <- tracePlotFunction(id, pilotMCMC()[[id]][, 2], 1000, thresholdLabs())
            g2 <- autocorrPlotFunction(id, pilotMCMC()[[id]][, 2], 1000, thresholdLabs())
            g3 <- densityPlotFunction(id, pilotMCMC()[[id]][, 2], 1000, thresholdLabs())
            return(grid.arrange(g1, g2, g3, ncol=3))
          })
          if(input$dependenceMethod == 'depend') {
            output[[paste0('pilotThetaPlot', id)]] <- renderPlot({
              g1 <- tracePlotFunction(id, pilotMCMC()[[id]][, 3], 1000, thresholdLabs())
              g2 <- autocorrPlotFunction(id, pilotMCMC()[[id]][, 3], 1000, thresholdLabs())
              g3 <- densityPlotFunction(id, pilotMCMC()[[id]][, 3], 1000, thresholdLabs())
              return(grid.arrange(g1, g2, g3, ncol=3))
            })
          }
        }
      )
    })

    # parameter plots
    observe({
      lapply(1:length(mcmcOut()),
        function(id) {
          output[[paste0('sigmaPlot', id)]] <- renderPlot({
            g1 <- tracePlotFunction(id, mcmcOut()[[id]][, 1], outputNoIters(), thresholdLabs())
            g2 <- autocorrPlotFunction(id, mcmcOut()[[id]][, 1], outputNoIters(), thresholdLabs())
            g3 <- densityPlotFunction(id, mcmcOut()[[id]][, 1], outputNoIters(), thresholdLabs())
            return(grid.arrange(g1, g2, g3, ncol=3))
          })
          output[[paste0('xiPlot', id)]] <- renderPlot({
            g1 <- tracePlotFunction(id, mcmcOut()[[id]][, 2], outputNoIters(), thresholdLabs())
            g2 <- autocorrPlotFunction(id, mcmcOut()[[id]][, 2], outputNoIters(), thresholdLabs())
            g3 <- densityPlotFunction(id, mcmcOut()[[id]][, 2], outputNoIters(), thresholdLabs())
            return(grid.arrange(g1, g2, g3, ncol=3))
          })
          if(input$dependenceMethod == 'depend') {
            output[[paste0('thetaPlot', id)]] <- renderPlot({
              g1 <- tracePlotFunction(id, mcmcOut()[[id]][, 3], outputNoIters(), thresholdLabs())
              g2 <- autocorrPlotFunction(id, mcmcOut()[[id]][, 3], outputNoIters(), thresholdLabs())
              g3 <- densityPlotFunction(id, mcmcOut()[[id]][, 3], outputNoIters(), thresholdLabs())
              return(grid.arrange(g1, g2, g3, ncol=3))
            })
          }
        }
      )
    })


    ## ----------------------- Return Levels Tab -----------------------------

    rvals <- reactive({
      if(any(input$returnLevelSelection == 'rrl')) {
        return(sort(c(as.numeric(input$returnLevelSelection[-length(input$returnLevelSelection)]), as.numeric(input$rrlOptionInput))))
      } else {
        return(as.numeric(input$returnLevelSelection))
      }
    })

    specificRLDists <- reactive({
      lapply(rvals(),
        function(r) {
          switch(input$dataSplittingForAnalysis,
            "Monthly" = {},
            "Quarterly" = {},
            "Overall" = {
              returnLevelGPD(r = r,
                sigma = exp(mcmcOut()[[1]][,1]),
                xi = mcmcOut()[[1]][,2],
                theta = switch(input$dependenceMethod, "depend" = mcmcOut()[[1]][,3], 1),
                lambda = lambdaRate()[[1]],
                thresh = threshold()[[1]]#,
                #nPeriod = dat()[[2]]
              )
            }
          )
        }
      )
    })

    output$specificRLDists <- renderPlot({
      tab <- data.frame(specificRLDists())
      colnames(tab) <- rvals()
      tab1 <- reshape::melt.data.frame(tab)
      colnames(tab1) <- c('r', 'returnlevel')
      g <- ggplot(data=tab1, aes(x=returnlevel)) +
        theme_bw() +
        labs(y = 'Density', x = expression(z[r]), title = "Return Level Density Plot") +
        theme(plot.title = element_text(hjust = 0.5)) +
        geom_density(aes(x=returnlevel, colour=r, fill=r), alpha=0.4)
      return(g)
    })
    # specifiedRLMeans <- reactive({sapply(specificRLDists(), mean)})
    # specifiedRLModes <- reactive({sapply(specificRLDists(), function(d) {D = density(d); return(D$x[which.max(D$y)])})})
    # specifiedRLSDs <-  reactive({sapply(specificRLDists(), sd)})
    # specifiedRLLower95 <- reactive({sapply(specificRLDists(), function(i) {quantile(i, 0.025)})})
    # specifiedRLUpper95 <- reactive({sapply(specificRLDists(), function(i) {quantile(i, 0.975)})})

    predReturnLevelHelper <- function(z, sigma, xi, theta = 1, lambda, thresh, r) {
    	if (z < thresh) {
    	  return((1 / r) - 1)
    	} else {
    	  return(
    	    mean((1 - lambda * ifelse(xi,
    	      pmax(0, (1 + xi * (z - thresh) / sigma)) ^ (-1 / xi),
    	      exp(- (z - thresh) / sigma))) ^ theta
    	    ) - (1 - (1 / r)))
    	}
    }

    predReturnLevel <- function(r, sigma, xi, theta = 1, lambda, thresh, nPeriod = NULL, interval, ...) {
    	if(any(sigma < 0)) {
    	  stop("Invalid negative scale parameter supplied!")
    	}
    	if (!is.null(nPeriod)) {
    	  r <- r * nPeriod
    	}
    	return(uniroot(predReturnLevelHelper, interval, ..., sigma = sigma, xi = xi, theta = theta, lambda = lambda, thresh = thresh, r = r)$root)
    }

    output$specifiedRLTable <- renderTable({
      switch(input$predictRadioButtons,
        "Standard" = {
          Summary <- data.frame(r = rvals(),
            Mean = unlist(lapply(specificRLDists(), mean)),
            Mode = unlist(lapply(specificRLDists(), function(d) {D = density(d,  na.rm=T); return(D$x[which.max(D$y)])})),
            SD = unlist(lapply(specificRLDists(), sd)),
            Lower95 = unlist(lapply(specificRLDists(), function(i) {quantile(i, 0.025)})),
            Upper95 = unlist(lapply(specificRLDists(), function(i) {quantile(i, 0.975)}))
          )
          colnames(Summary) <- c("r",
                                 "Mean",
                                 "Mode",
                                 "Standard Deviation",
                                 "95% CI Lower Bound",
                                 "95% CI Upper Bound")
          return(Summary)
        },
        "Predictive" = {
         Summary <- data.frame(r = rvals(),
            Mean = unlist(lapply(specificRLDists(), mean)),
            Mode = unlist(lapply(specificRLDists(), function(d) {D = density(d,  na.rm=T); return(D$x[which.max(D$y)])})),
            SD = unlist(lapply(specificRLDists(), sd)),
            Lower95 = unlist(lapply(specificRLDists(), function(i) {quantile(i, 0.025)})),
            Upper95 = unlist(lapply(specificRLDists(), function(i) {quantile(i, 0.975)})),
            Predictive = unlist(lapply(rvals(),
              function(r) {
                switch(input$dataSplittingForAnalysis,
                  "Monthly" = {},
                  "Quarterly" = {},
                  "Overall" = {
                    predReturnLevel(r,
                      sigma = exp(mcmcOut()[[1]][,1]),
                      xi = mcmcOut()[[1]][,2],
                      theta = switch(input$dependenceMethod, "depend" = mcmcOut()[[1]][,3], 1),
                      lambda = lambdaRate()[[1]],
                      thresh = threshold()[[1]],
                      365.25*24,
                      interval = c(1, 1000),
                      extendInt = 'yes'
                    )
                  }
                )
              }
            ))
          )

          colnames(Summary) <- c("r",
                                 "Mean",
                                 "Mode",
                                 "Standard Deviation",
                                 "95% CI Lower Bound",
                                 "95% CI Upper Bound",
                                 "Predictive")
          return(Summary)
        }
      )
    },
    include.rownames = FALSE
    )

    predictivePlotFunction <- reactive({
      rseq <- exp(seq(log(10), log(input$maxPredRetLevel), length = 80))
      RLs <- lapply(rseq,
        function(r) {
          switch(input$dataSplittingForAnalysis,
            "Monthly" = {},
            "Quarterly" = {},
            "Overall" = {
              returnLevelGPD(r = r,
                sigma = exp(mcmcOut()[[1]][,1]),
                xi = mcmcOut()[[1]][,2],
                theta = switch(input$dependenceMethod, "depend" = mcmcOut()[[1]][,3], 1),
                lambda = lambdaRate()[[1]],
                thresh = threshold()[[1]],
                nPeriod = 365.25*24
              )
            }
          )
        }
      )
      tab <- data.frame(
        r = rseq,
        Mean = unlist(lapply(RLs, mean)),
        Mode = unlist(lapply(RLs, function(d) {D = density(d,  na.rm=T); return(D$x[which.max(D$y)])})),
        SD = unlist(lapply(RLs, sd)),
        Lower95 = unlist(lapply(RLs, function(i) {quantile(i, 0.025)})),
        Upper95 = unlist(lapply(RLs, function(i) {quantile(i, 0.975)})),
        Predictive <- sapply(rseq, predReturnLevel,
          sigma = exp(mcmcOut()[[1]][,1]),
          xi = mcmcOut()[[1]][,2],
          theta = switch(input$dependenceMethod, "depend" = mcmcOut()[[1]][,3], 1),
          lambda = lambdaRate()[[1]],
          thresh = threshold()[[1]],
          nPeriod = 365.25*24,
          interval = c(1, 1000),
          extendInt = 'yes'
        )
      )
      g <- ggplot(data=tab, aes(x=r)) +
        geom_ribbon(aes(ymin=Lower95, ymax=Upper95), fill='darkolivegreen2', show.legend=TRUE, alpha=0.4) +
        geom_line(aes(y=Mean, lwd=1), colour="forestgreen", show.legend=TRUE, lwd=1) +
        geom_line(aes(y=Predictive), colour="red", show.legend=TRUE, lwd=1) +
        labs(x = expression(r), y = 'Return Level', title = "Predictive Return Levels for Varying r") +
        theme(legend.position = "bottom") +
        theme(plot.title = element_text(hjust = 0.5)) +
        scale_x_log10() +
        theme_bw()
      return(g)
    })

    output$predictiveRLPlot <- renderPlot(predictivePlotFunction())

    # specificPredRLs <- reactive({
    #   lapply(rvals(),
    #     function(r) {
    #       switch(input$dataSplittingForAnalysis,
    #         "Monthly" = {},
    #         "Quarterly" = {},
    #         "Overall" = {
    #           predReturnLevel(r,
    #             sigma = exp(mcmcOut()[[1]][,1]),
    #             xi = mcmcOut()[[1]][,2],
    #             theta = switch(input$dependenceMethod, "depend" = mcmcOut()[[1]][,3], 1),
    #             lambda = lambdaRate()[[1]],
    #             thresh = threshold()[[1]]#,
    #             #nPeriod = dat()[[2]]
    #           )
    #         }
    #       )
    #     }
    #   )
    # })


#
#
#     ## -------------------  Theo & Matthew stuff  --------------------------
#
#     # Uploaded data is going in its own environment so that it can be extracted
#     # from the function when being uploaded.
#     # TODO:
#     # Look for a better way of handling this scoping issue
#     # Warning produced with the new renderUI quantile thresholdchoice - the one which had a default value of 30 didn't produce this warning
#     # Note that the probability calculation in the bottom left of the PM page does not change for extremal index adjustment -
#     # not sure if this is desired or not.
#     # Button randomly doesn't work sometimes?
#     dataProvided <- new.env()
#
#     # Pre-loaded data sets
#     library(ismev); data(rain) #uses ismev just for data set
#     brad = scan('data/bradfield.txt'); brad2 = brad[!is.na(brad)]
#     maxtemp = read.table('data/maxtempnotext.txt',sep=",",skip=1)[,4] #Essentially just reading the data
#     snowd = read.table('data/snowdepthnotext.txt',sep=",",skip=1)[,4]; snowd[which(snowd==-9999)]=NA; snowdepth = snowd[!is.na(snowd)]
#     sunsh = read.table('data/sunshinenotext.txt',sep=",",skip=1)[,4]; sunsh[which(sunsh==-9999)]=NA; sunshine = sunsh[!is.na(sunsh)]
#     sealev = read.table('data/sealevelpressurenotext.txt',sep=",",skip=1)[,4]; sealev[which(sealev==-9999)]=NA; sealevel = sealev[!is.na(sealev)]
#     #NOTE: the snow depth has some very few odd extreme values, with one as 700. This seems unusual.
#     #Additionally, the brad dataset is very large - 80,000+ observations, which means parameters can take a short while to calculate sometimes.
#
#     #Which names on the graph
#     dataTypeNew <- reactive({               #This function decides what name to show on the graph (can be removed if needed)
#       if (input$dataInSelect) {
#         return(input$dataName)
#       }
#       else {
#         return(input$dataType)
#       }
#     })
#
#     #Uploading data code
#     # dataReadupin <- reactive({
#     #   return(read.table(input$dataUpin$datapath, header = input$headerUpload, sep = input$sepUpload, quote = input$quoteUpload))
#     # })
#     #
#     #   threshcode <- reactive ({                          #We assign a provided value to be NA, and then remove it
#     #     removeNA = dataReadupin()[,input$maxSelect]
#     #     removeNA[which(removeNA==input$missingSelect)]=NA
#     #      return(removeNA[!is.na(removeNA)])
#     #   })
#     #
#     # #Switching between uploading and pre loaded data sets
#     # dataRead <- reactive({
#     #
#     #   if (!input$dataInSelect) {           #If the upload box is not checked, uses the a chosen preset datafile.
#     #     assign("datafile", get(input$dataType), envir = dataProvided)
#     #     return(dataProvided$datafile)
#     #   } else {
#     #     req(input$dataUpin)          #If it is checked, use the datafile uploaded without NA's in
#     #     assign("datafile", threshcode(), envir = dataProvided)
#     #     return(dataProvided$datafile)
#     #     #   }
#     #   }
#     # })
#
#     output$SummaryTable <- renderTable({
#       # Find min, LQ, median, UQ and max in one go
#       summaryQuant <- quantile(dataRead())
#
#       Summary <- data.frame(l    = length(dataRead()),
#                             Mean = mean(dataRead()),
#                             sd   = sd(dataRead()),
#                             min  = summaryQuant[1],
#                             lq   = summaryQuant[2],
#                             med  = summaryQuant[3],
#                             uq   = summaryQuant[4],
#                             max  = summaryQuant[5])
#
#       colnames(Summary) <- c("Number of Observations",
#                              "Mean",
#                              "Standard Deviation",
#                              "Minimum Observation",
#                              "Lower Quartile",
#                              "Median",
#                              "Upper Quartile",
#                              "Maximum Observation")
#       return(Summary)
#     },
#     include.rownames = FALSE
#     )
#     outputOptions(
#       output, "SummaryTable", priority = -2, suspendWhenHidden = FALSE
#     )
#
#     # Break points needed for plotting histogram and Relative Frequency table
#     dataPrettyBreaks <- reactive({
#       return(pretty(dataRead(), 2 * nclass.FD(dataRead())))
#     })
#     # Text for the return level
#     output$howExtremeText <- renderText({"An insight into predicting future events"})
#
#     # Label for the input slider
#     output$howExtremeSliderLabel <- renderUI({
#       p("How extreme could we expect the data to be once every ", input$GPDWallHeightInput, "years?")
#     })
#
#     # Summary plots of input data: histogram and boxplot.
#     output$datafileHistogram <- renderPlot({
#       return(
#         qplot(dataRead(), # defaults to histogram as only x-values supplied
#               binwidth = dataPrettyBreaks()[2] - dataPrettyBreaks()[1],
#               col = I("black"),
#               fill = I("white"),
#               main = paste("Histogram of", tolower(dataTypeNew()), "raw data"),
#               xlab = paste0(dataTypeNew(), " raw data (", input$dataUnits, ")"),
#               ylab = "Frequency"
#         ) +
#           theme_bw()
#       )
#     })
#     output$datafileBoxplot <- renderPlot({
#       return(
#         qplot(
#           factor(0),
#           dataRead(),
#           geom = "boxplot",
#           main = paste("Boxplot of", tolower(dataTypeNew()), "raw data"),
#           ylab = paste0(dataTypeNew(), " raw data (", input$dataUnits, ")"),
#           xlab = " "
#         ) + coord_flip() + theme_bw()
#       )
#     })
#     outputOptions(output, "datafileHistogram", priority = -1)
#     outputOptions(output, "datafileBoxplot", priority = -1)
#
#     # Create data for the plot              #Old code from Rel Freq page - used for slider limits later on (not sure why?)
#     makeRelFreqPlotData <- function (d) {
#       h = c(min(d) - 0.4, d, max(d) + 2)
#       relFreqPlot <- data.frame(
#         Height = h,
#         Probability = sapply(h, function(x) sum(d > x) / length(d))
#       )
#       return(relFreqPlot)
#     }
#     relFreqPlotData <- reactive({makeRelFreqPlotData(exceedances())})
#
#     ############################################################################
#     ######################## Pre-analysis page #################################
#     ############################################################################
#     #The numeric input for the threshold
#      output$threshnuminput <- renderUI({
#        return(
#          numericInput("thresholdchoice", "Please enter a threshold according to the mean life residual plot, based on the linearity at that point.", round(quantile(dataRead(),0.9),0)))
#      })
#
#     #MRL plot
# #     u <- reactive({ u1=seq(0,max(dataRead(),0.1))})                               #Possible thresholds
# #     meanexce <-  reactive({meanexce1=vector('numeric',length(u()))                #Our mean excesses for ith threshold
# #                            for(i in 1:length(meanexce1)){
# #                              threshold.exceedances=dataRead()[dataRead()>u()[i]]  #Pick all values of dataset where dataset is over the threshold
# #                              meanexce1[i]=mean(threshold.exceedances-u()[i])      #Mean of exceedances, giving mean excess
# #                            }
# #                            return(meanexce1)})
# #     output$MRLplot <- renderPlot({                                                #The MRL plot
# #       return(
# #         plot(meanexce()~u(), type='l',main='MRL plot',ylab='Mean excess',xlab='u')
# #       )
# #     })
#     #Suggested quantiles
#     output$quantradiobuttons <- renderUI({                                        #Choices for a quantile
#       return(
#         radioButtons("quantilechoice", label = h3("Choose a quantile"),
#                      choices = list(
#                        "99% quantile" = round(quantile(dataRead(),0.99),2),
#                        "95% quantile" = round(quantile(dataRead(),0.95),2),
#                        "90% quantile" = round(quantile(dataRead(),0.9),2)
#                      ))
#       )
#     })
#
#     output$threshchoicetext <- renderText({                                      #This displays the generated quantile of the raw data
#       return(paste0("The calculated threshold is  ",input$quantilechoice, ". (2 d.p.)"))  #Add the choice in bold
#     })
#
#     #calculate threshold excesses
#
#     excesses <- reactive({
#       lapply(1:length(splitDat()),
#              function(id) {
#                splitDat()[[id]][splitDat()[[id]] >= threshold()[[id]]]
#              }
#       )
#     })
#
#     # scatterplot
#
#     #Four plots underneath
#     output$scatterPlot <- renderPlot({                                           #Plot of raw data
#       plot(dataRead(),main='Plot of raw data',pch=".")
#       abline(h=input$thresholdchoice, col="bisque3")
#     })
#     output$neighbourplot <- renderPlot({                                         #Plot of data against their neighbours
#       plot(x=dataRead()[1:(length(dataRead())-1)],y=dataRead()[2:(length(dataRead()))],main="Plot of neighbours",pch=".",xlab=expression("x"[i]),ylab=expression("x"[i-1]))
#       abline(h=input$thresholdchoice, col="cyan")
#       abline(v=input$thresholdchoice, col="cyan")
#     })
#     output$pacfplot <- renderPlot({                                              #PACF plot
#       pacf(dataRead(),main="")
#       title(main="PACF plot for data")
#     })
#     exceedances <- reactive({                                                    #This contains all threshold exceedances
#       if(input$adjustmentChoice==3){                                             #If the declustered option is chosen, use the new declustered exceedances
#         threshold.exceedances <- declustered.exceedances()
#         } else {                                                                 #Otherwise, calculate threshold exceedances as normal
#           threshold.exceedances <- dataRead()[dataRead()>input$thresholdchoice]-input$thresholdchoice
#         }
#       return(threshold.exceedances)})
#     output$scatterPlotexceedance <- renderPlot({                                 #Plots all exceedances
#       return(
#         plot(exceedances(),main='Plot of threshold exceedances',ylab='Exceedance')
#       )
#     })
#     outputOptions(output, "scatterPlotexceedance", priority = -5)
#
#     neighbourptest <- reactive({      #This is the p < 0.05 test for the top-rh corner of the neighbourplot. A TRUE result will mean we need to decluster.
#       return(cor.test(dataRead()[input$thresholdchoice:(length(dataRead())-1)],dataRead()[(input$thresholdchoice+1):(length(dataRead()))])$p.value<0.05)})
#
#     decluster <- function(dataset,threshold,kappa){       #Our function to decluster the data for arbitrary kappa.
#       # HACK: Kappa doesn't exist at the moment the page is loaded, so pre-define a kappa until it does.
#       if(!length(kappa)) {
#         kappa = 10
#       }
#       x=list()
#       z=list()
#       j=1
#       {
#       for(i in (kappa+1):length(dataset)){
#         if(dataset[i-kappa]>threshold &
#              all(dataset[i:(i-kappa+1)]<=threshold)
#         ){
#           x=max(dataset[j:i])
#           ifelse(i != length(dataset), j<-i+1, NA)
#           z=c(z,x)}}}
#       return(as.numeric(z))
#     }
#
#     cluster.peaks <- reactive({return(decluster(dataRead(),input$thresholdchoice,input$kappa))})      #Decluster the raw data
#     declustered.exceedances <- reactive({                                                             #Calculate the new declustered exceedances
#       declthreshold.exceedances <- cluster.peaks()-input$thresholdchoice
#       return(declthreshold.exceedances)
#     })
#     output$postclusterPlot <- renderPlot({                                                            #Plot of new declustered exceedances
#       return(
#         plot(declustered.exceedances(),main='Plot of threshold exceedances after declustering',ylab='Exceedances')
#       )
#     })
#
#     #This choice will be given depending on whether the p-test is significant.
#     output$countermeasbuttons <- renderUI(
#       if(neighbourptest()){
#          radioButtons("adjustmentChoice", "Choose type of dependence counter-measure",
#                      choices = list("Declustering" = 3,
#                                       "Extremal index" = 4))
#       }
#       )
#
#     #This is the text for the declustering procedure.
#     output$declusterresult <- renderUI(
#       if(input$adjustmentChoice==3){
#         list(column(4, h2("Declustering"),
#                     p("A significant p-test has been conducted on the neighbour plot and we strongly advise declustering.
#                       You will need to pick a value of kappa in order to decluster the data - this value will help us classify a cluster.
#                       Kappa is the number of data points following any given threshold exceedance(s) which remain underneath the threshold.
#                       A larger value of kappa will result in less data, and a smaller value of kappa will make the clusters too small."),
#                     p("Note that the return levels generated after declustering are sensitive to a choice of kappa."),
#                     numericInput("kappa","Pick a value for kappa" ,value=10,min=1,max=5000)
#                     ),
#              column(4,
#                     plotOutput("postclusterPlot")
#              ))}
#         )
#
#     #Code for extremal index and return levels
#     dep.ei = function(data, thresh, r, ny, B=1000){
#
#       source("intervalsboot2.r")
#       source("intervalsjackknife.r")
#       library(ismev)
#
#       #Perform the bootstrap replications:
#       BOOT = block.boot(data, thresh, r, ny, B)
#
#       #Perform the jackkninfe replications:
#       JACK = block.jack(data, thresh, r, ny)
#
#       main.fit = gpd.fit(data, thresh, show = FALSE)
#       main.lambda = length(data[data>thresh])/length(data)
#       main.theta = ferrocluster(data, thresh)
#       main.q = lee.q(main.fit$mle[1], main.fit$mle[2], main.theta, thresh, main.lambda, r, ny)
#       boot.q = lee.q(BOOT[,1], BOOT[,2], BOOT[,4], thresh, BOOT[,3], r, ny)
#
#       jack.sigma = JACK[,1]
#       jack.xi = JACK[,2]
#       jack.lambda = JACK[,3]
#       jack.theta = JACK[,4]
#
#       jackknife.q = lee.q(jack.sigma, jack.xi, jack.theta, thresh, jack.lambda, r, ny)
#
#       mean.jackknife.q = mean(jackknife.q)
#
#       skew.jackknife.q = sum(((mean.jackknife.q-jackknife.q)^3))/((sum(((mean.jackknife.q-jackknife.q)^2)))^(3/2))
#
#       a = (1/6)*skew.jackknife.q
#
#       hash = length(boot.q[boot.q < main.q])
#
#       z = qnorm(hash[1]/B)
#
#       a1 = pnorm(z+((z-qnorm(0.975))/(1-a*(z-qnorm(0.975)))))
#
#       a2 = pnorm(z+((z+qnorm(0.975))/(1-a*(z+qnorm(0.975)))))
#
#       lower = round(B*a1)
#       upper = round(B*a2)
#
#       sort.bootq = sort(boot.q)
#
#       #Confidence interval for q
#       BCa.q = c(sort.bootq[lower],sort.bootq[upper])
#
#       #Other things to return:
#       #Extremal index
#       EI = main.theta
#       #EI standard error
#       EI.se = sd(BOOT[,4])
#       #Ret level
#       Q = main.q
#       #Ret level standard error
#       Q.se = sd(BOOT[,5])
#
#       A = list(Extremal.index = EI, Extremal.index.se = EI.se, Return.level = Q, Return.level.se = Q.se, Return.level.CI.lower = BCa.q[1],Return.level.CI.upper=BCa.q[2])
#
#       return(A)}
#      #Reactive for dep.ei
#      dep.ei.calculated <- eventReactive(input$extrmIndexbutton, ({dep.ei(dataRead(),input$thresholdchoice, input$bootstrapRL ,as.numeric(input$occurrence), input$bootstrapITER)}))
#
#     ############################################################################
#     ######################## Probability model page ############################
#     ############################################################################
#
#                      #######################################
#                      ############ Frequentist  #############
#                      #######################################
#
#     calculateGPDParameters <- function(dataset) {                    #Derives the GPD parameters
#       theta <- c(mean(dataset), sd(dataset))
#       gpd.loglik <- function(theta){
#         sigma <- theta[1]
#         xi <- theta[2]
#         m <- min(1+(dataset*(xi/sigma)))
#         if(m<0.00001)return(as.double(1000000))
#         if(sigma<0.00001)return(as.double(1000000))
#         if(xi==0){
#           loglik <- -length(dataset)*log(sigma)-sum(dataset)/sigma
#         } else {
#           loglik <- -length(dataset)*log(sigma) - sum(log(1+(dataset*(xi/sigma)))*(1/xi+1))
#         }
#         return(-loglik)
#       }
#       return(nlm(gpd.loglik, theta, hessian=TRUE))
#     }
#     GPDParameters <- reactive({                                    #The first element contains lambda hat, the second contains sigma hat, and the third contains xi hat - this is
#         return(c(length(exceedances())/length(dataRead()),calculateGPDParameters(exceedances())$est))#necessary because the dimensions must be like this for the delta method.
#     })
#     GPDParametersSE <- reactive({                                  #Calculates the s.e's of the GPD parameters using the hessian.
#         hess <- calculateGPDParameters(exceedances())$hessian
#         errors <- sqrt(diag(solve(hess)))
#         return(c(sqrt(GPDParameters()[1]*(1-GPDParameters()[1])/length(dataRead())),errors))
#     })
#     # The calculations with the option for standard errors
#     output$GPDTablePreamble <- renderUI({
#       withMathJax(
#         paste0(
#           "For the data you provided, we have found that \\(\\tilde{\\sigma}=",
#           round(GPDParameters()[2], 3),
#           ifelse(input$standardErrorGPD, paste0(" \\left(", round(GPDParametersSE()[2], 3), "\\right)"), ""),
#           "\\) and \\(\\xi=",                                                   #If the s.e. box is checked, display the SE. Otherwise, display nothing
#           round(GPDParameters()[3], 3),                                         #This ifelse procedure for s.e.'s is used throughout.
#           ifelse(input$standardErrorGPD, paste0(" \\left(", round(GPDParametersSE()[3], 3), "\\right)"), ""),
#           "\\) (Both values given to 3 decimal places). Additionally, the threshold exceedance rate is \\(\\lambda=",
#           round(GPDParameters()[1],4),
#           ifelse(input$standardErrorGPD, paste0(" \\left(", round(GPDParametersSE()[1], 4), "\\right)"), ""),
#           "\\) (4 d.p.)."
#         )
#       )
#     })
#     # The output for the extremal index
#     output$GPDextremeoutput <- renderUI({
#       if(input$adjustmentChoice==4){       #Only appears if extremal index is chosen on pre-analysis
#         withMathJax(
#           paste0(
#             "The extremal index estimate was calculated to be \\(\\theta=",
#             round(dep.ei.calculated()$Extremal.index,5),
#             ifelse(input$standardErrorGPD , paste0("\\left(", round(dep.ei.calculated()$Extremal.index.se,5), "\\right)"), ""),
#             "\\) (5 d.p.)."
#           )
#         )
#       }
#     })
#
#     #GOODNESS OF FIT SECTION
#
#     #Probability plot
#     output$Pplot <- renderPlot({
#         ordered = sort(exceedances())
#         empirical=vector('numeric',length(exceedances()))
#         for(i in 1:length(empirical)){                       #The empirical distribution
#           empirical[i]=i/(length(empirical)+1)
#         }
#         GPD.DF=function(data,sigma,xi){                      #CDF for GPD
#           if(xi==0){
#             GPD=1-exp(-data/sigma)
#           }
#           else{
#             GPD=1-(1+(xi*data)/sigma)^(-1/xi)
#           }
#           return(GPD)
#         }
#         model=vector('numeric',length(exceedances()))
#         for(i in 1:length(exceedances())){
#           model[i]=GPD.DF(ordered[i],GPDParameters()[2],GPDParameters()[3])
#         }
#         plot(model~empirical,col = "magenta",main='Probability plot',pch = 19,xlab="Empirical",ylab="Model",cex.lab = 1.3)
#         abline(0,1)
#       })
#     #QQplot
#     output$QQplot <- renderPlot({
#       ordered = sort(exceedances())                         #Exceedances sorted
#       model.quantile=vector('numeric',length(exceedances()))
#       empirical=vector('numeric',length(exceedances()))
#       for(i in 1:length(empirical)){
#         empirical[i]=i/(length(empirical)+1)                #The empirical distribution
#       }
#       GPD.INV=function(data,sigma,xi){
#         if(xi==0){
#           INV = -sigma*log(1-data)}                        #Calculated myself - may need a check
#         else{
#           INV = sigma/xi * ((1-data)^(-xi)-1)}
#         return(INV)}
#       for(i in 1:length(model.quantile)){
#         model.quantile[i]=GPD.INV(empirical[i],GPDParameters()[2],GPDParameters()[3])
#       }
#       plot(model.quantile,ordered, col = "magenta",main='Quantile plot',pch = 19, xlab="Model quantile", ylab="Ordered data",cex.lab = 1.3)
#       abline(0,1)
#     })
#
#     # Find a probability: input slider
#     output$GPDProbabilitySlider <- renderUI({
#       sliderRange <- range(relFreqPlotData()[, 1])
#       return(
#         sliderInput("GPDProbabilityInput",
#                     label = h4(
#                       "Choose a value (",
#                       input$dataUnits,
#                       ") to find the probability of exceeding it"
#                     ),
#                     min = max(0, sliderRange[1] - 2),
#                     max = max(0, floor(abs(GPDParameters()[2]/GPDParameters()[3]))),   #The upper limit of the slider here causes problems.
#                     #For negative xi, we need to implement an upper bound of -sigma/xi on the slider as a fool-proof way of not returning NaNs, since
#                     #for xi<0, -sigma/xi is where the bracket is zero. However, for xi>0, this end slider input seems not quite small enough (i.e. p=0.01 instead of 0.000001).
#                     #I imagine practitioners would want a higher input than this for the slider.
#                     value = round(runif(1, sliderRange[1], sliderRange[2]), 1),
#                     step = 0.05
#         )
#       )
#     })
#     outputOptions(
#       output, "GPDProbabilitySlider", priority = -2, suspendWhenHidden = TRUE
#     )
#
#     # Find a probability: text description
#     output$GPDProbabilityDescription <- renderUI({
#       return(
#         withMathJax(
#           p(
#             paste0(
#               "The probability of observing an exceedance greater than \\(y=",input$GPDProbabilityInput,"\\) ",
#               input$dataUnits,
#               " is given by $$\\mathrm{Pr}(Y>",
#               input$GPDProbabilityInput,
#               "|Y>0)=\\left[1+\\frac{",
#               input$GPDProbabilityInput,
#               "\\times",
#               round(GPDParameters()[3], 3),
#               "}{",
#               round(GPDParameters()[2], 3),
#               "}\\right]^{-\\frac{1}{",
#               round(GPDParameters()[3], 3),
#               "}}=",
#               signif((1 +input$GPDProbabilityInput*GPDParameters()[3]/GPDParameters()[2])^(-1/GPDParameters()[3]), 4),
#               "\\text{ (to 4 significant figures).}$$"
#             )
#           )
#         )
#       )
#     })
#     outputOptions(output,
#                   "GPDProbabilityDescription", priority = -3, suspendWhenHidden = TRUE
#     )
#
#     # Find a wall height
#     output$GPDWallHeightInput <- renderText({
#       paste(input$GPDWallHeightInput, input$dataTimeframe)
#     })
#     output$GPDWallHeightP <- renderUI({
#       withMathJax(
#         paste0("\\(p=", signif(1 / input$GPDWallHeightInput, 4), "\\)")
#       )
#     })
#
#     # Return Standard Error
#     GPDWallSE <- reactive({
#       varcovar = matrix(ncol = 3, nrow = 3)
#       varcovar[2:3,2:3] <- solve(calculateGPDParameters(exceedances())$hessian)[1:2,1:2]  #Bottom right-hand of 3x3 is the 2x2 hessian for sigma and xi
#       varcovar[1,1] <- GPDParameters()[1]*(1-GPDParameters()[1])/length(dataRead())       #Top left value is Var(lambda)
#       varcovar[2:3,1] <- 0; varcovar[1,2:3] <- 0                                          #Assuming Var(lambda, GPD parameters)=0
#       est <- calculateGPDParameters(exceedances())$est
#       lambda <- GPDParameters()[1]
#       r <- input$GPDWallHeightInput
#       ny <- as.numeric(input$occurrence)
#       del = matrix(ncol = 1, nrow = 3)
#       del[1,1] = est[1]*((r*ny)^est[2])*(lambda)^(est[2]-1)
#       del[2,1] = (est[2]^-1)*((r*ny*lambda)^est[2]-1)
#       del[3,1] = -est[1]*(est[2]^(-2))*((r*ny*lambda)^est[2]-1)+est[1]*(est[2]^(-1))*((r*ny*lambda)^est[2])*log(r*ny*lambda)
#       del.transpose = t(del)
#       error = sqrt(del.transpose%*%varcovar%*%del)
#       return(error)
#     })
#
#     #This is the LaTeX writing for the return level. It is dependent on whether the bootstrap method is used.
#     output$GPDWallHeightCalculation <- renderUI({
#       return(
#         withMathJax(
#           paste0(
#             "$$z_{",
#             input$GPDWallHeightInput,
#             "}=",
#             input$thresholdchoice,
#             "+",
#             "\\frac{",
#             round(GPDParameters()[2], 3),
#             "}{",
#             round(GPDParameters()[3], 3),
#             "}\\left[\\left(",
#             input$GPDWallHeightInput,
#             "\\times",
#             input$occurrence,
#             "\\times",
#             signif(length(exceedances())/length(dataRead()),4),
#             "\\right)^{",
#             round(GPDParameters()[3], 3),
#             "}-1\\right]=",
#             round(input$thresholdchoice + (GPDParameters()[2]/GPDParameters()[3])*((input$GPDWallHeightInput*as.numeric(input$occurrence)*length(exceedances())/length(dataRead()))^GPDParameters()[3] - 1),2),
#             ifelse(input$standardErrorGPDWall, paste0(" (", round(GPDWallSE()[1], 3), ")"), ""),
#             "\\text{ ",
#             input$dataUnits,
#             " (to 2 decimal places).}$$"
#           )
#         )
#       )
#     })
#     output$GPD.EI.RL.CALC <- renderUI({
#       return(
#         withMathJax(
#           paste0(
#             "$$z_{",
#             input$bootstrapRL,
#             "}=",
#             round(dep.ei.calculated()$Return.level,2),
#             ifelse(input$standardErrorEIRL, paste0(" (", round(dep.ei.calculated()$Return.level.se,2), ")"), ""),
#             "\\text{ ",
#             input$dataUnits,
#             " (to 2 decimal places).}$$",
#             "This gives us a 95% confidence interval of (",
#             round(dep.ei.calculated()$Return.level.CI.lower,2),
#             " , ",
#             round(dep.ei.calculated()$Return.level.CI.upper,2),
#             ")."
#         )
#       )
#       )
#     })
#     output$EI.RLpreamble <- renderUI({
#       return(
#         paste0(
#           "We would expect to see for the ",
#           input$bootstrapRL,
#           "-year return level a value of"
#           ))
#     })
#
#     #######################################
#     ############# Bayesian  ###############
#     #######################################
#
#     #Function to sample mcmc iterations
#     gpd.bayes <- function(n, dataset, sigmastart, xistart, erreta, errxi, sdeta, sdxi)
#     {
#       k <- length(dataset)
#       x <- numeric(n)
#       y <- numeric(n)
#       aprobeta <- numeric(n)
#       aprobxi <- numeric(n)
#       x[1] <- log(sigmastart)
#       y[1] <- xistart
#       loglik <- function(k, dataset, ETA, XI) {
#         expEta <- exp(ETA)
#         if (expEta < 0.00001) return(as.double(-1000000))
#         m <- min(1 + (dataset * XI / expEta))
#         if (m < 0.00001) return(as.double(-1000000))
#         return(-k * ETA - (1 + (1 / XI)) * sum(log(1 + (XI * dataset / expEta))))
#       }
#
#       # Pre-sample proposal steps and uniform acceptance probability
#       uEta <- runif(n)
#       uXi  <- runif(n)
#       propStepEta <- rnorm(n, 0, erreta)
#       propStepXi  <- rnorm(n, 0, errxi)
#
#       for(i in 2:n){
#         # Update eta
#         proposal <- x[i - 1] + propStepEta[i]
#         likely <- exp(loglik(k, dataset, proposal, y[i - 1]) - loglik(k, dataset, x[i-1], y[i - 1]))
#         aprobeta[i] <- min(1, likely * dnorm(proposal, 0, sdeta) * dnorm(y[i - 1], 0, sdxi) / (dnorm(x[i - 1], 0, sdeta) * dnorm(y[i - 1], 0, sdxi)))
#         if (uEta[i] < aprobeta[i]) {
#           x[i] <- proposal
#         } else {
#           x[i] <- x[i - 1]
#         }
#         # Update xi
#         proposal <- y[i - 1] + propStepEta[i]
#         likely2 <- exp(loglik(k, dataset, x[i], proposal) - loglik(k, dataset, x[i], y[i - 1]))
#         aprobxi[i] <- min(1, likely2 * dnorm(x[i], 0, sdeta) * dnorm(proposal, 0, sdxi) / (dnorm(x[i], 0, sdeta) * dnorm(y[i-1], 0, sdxi)))
#         if (uXi[i] < aprobxi[i]) {
#           y[i] <- proposal
#         } else {
#           y[i] <- y[i - 1]
#         }
#       }
#       results <- matrix(ncol = 4, nrow = n)
#       results[, 1] <- exp(x)
#       results[, 2] <- y
#       results[, 3] <- aprobeta
#       results[, 4] <- aprobxi
#       return(results)
#     }
#
#     #Reactive putting iteration values into a data frame called mcmc
#     mcmc <- eventReactive(input$startmcmc, ({gpd.bayes(input$iterations,  exceedances(), GPDParameters()[2], GPDParameters()[3], input$RWVLogsigma, input$RWVXi, as.numeric(input$SigmaSD), as.numeric(input$XiSD))}))
#     sigma.mcmc <- reactive(return(mcmc()[,1]))
#     xi.mcmc <- reactive(return(mcmc()[,2]))
#     aprobexp.mcmc <- reactive(return(mcmc()[,3]))
#     aprobxi.mcmc <- reactive(return(mcmc()[,4]))
#
#     #Summary statistics for parameters
#
#     output$meansigma <- renderText({round(mean(sigma.mcmc()), digits = 3)})
#     output$meanxi <- renderText({round(mean(xi.mcmc()), digits = 3)})
#
#
#     #Standard deviations
#     output$sdsigma <- renderText({round(sd(sigma.mcmc()), digits = 3)})
#     output$sdxi <- renderText({round(sd(xi.mcmc()), digits = 3)})
#
#     #Formulas returning quantile points from slider input of CI
#     #NOTE: For some reason, "logsigma" is used throughout as a name when it is infact sigma. It has already been exponentiated.
#     LOGSIGMAlower <- reactive({return(((100-input$CILOGSIGMAslider)/200))})
#     LOGSIGMAupper <- reactive({return((LOGSIGMAlower() + (input$CILOGSIGMAslider/100)))})
#
#     XIlower <- reactive({return(((100-input$CIXIslider)/200))})
#     XIupper <- reactive({return((XIlower() + (input$CIXIslider/100)))})
#
#
#     #Lower CI bounds
#     output$logsigmaCIlower <- renderText({round(quantile(sigma.mcmc(), LOGSIGMAlower()), digits = 3)})
#
#     output$xiCIlower <- renderText({round(quantile(xi.mcmc(), XIlower()), digits = 3 )})
#
#     #Upper CI bbounds
#     output$logsigmaCIupper <- renderText({round(quantile(sigma.mcmc(), LOGSIGMAupper()), digits =3 )})
#
#     output$xiCIupper <- renderText({round(quantile(xi.mcmc(), XIupper()), digits = 3)})
#
#
#
#     ##Acceptance probability reactives
#     logsigmaaccprob <- reactive({mean(aprobexp.mcmc()[!is.na(aprobexp.mcmc())])})
#     xiaccprob <- reactive({mean(aprobxi.mcmc()[!is.na(aprobxi.mcmc())])})
#
#     output$accprobnologsigma <- renderText({100*round(logsigmaaccprob(), digits = 3)})
#     output$accprobnoxi <- renderText({100*round(xiaccprob(), digits = 3)})
#
#     ##Reactives for CI title, not sure why they're called accprobs ####
#
#     output$titleaccproblogsigma <- renderText({return(input$CILOGSIGMAslider)})
#     output$titleaccprobxi <- renderText({return(input$CIXIslider)})
#
#
#     ##Function for the mode
#
#     Mode <- function(dataset,BW) {                  #BW added as a parameter because the smoothness of
#       a=density(dataset, bw=as.numeric(BW))         #the curve affects the placement of the mode.
#       return(a$x[which.max(a$y)])
#     }
#
#     ##Reactives for mode
#
#     output$modeLOGSIGMA <- renderText({round(Mode(sigma.mcmc(),input$denSmoothlogsigma), digits = 3)})
#     output$modeXI <- renderText({round(Mode(xi.mcmc(),input$denSmoothxi), digits = 3)})
#
#
#     output$acceptanceproblogsigmatext <- renderText({                              #Generates text depending on the acceptable probabilities for sigma and xi
#       if(logsigmaaccprob()<0.2){
#         return(". This is too low. Decrease your random walk variance.")
#       }
#       else if(logsigmaaccprob()>0.4) {
#         return(". This is too high. Increase your random walk variance.")
#       }
#       else if(logsigmaaccprob()>0.3 & logsigmaaccprob()<0.4){
#         return(". This is slightly too high, but can be acceptable to use.")
#       }
#       else{
#         return(". This is good.")
#       }
#     })
#
#     output$acceptanceprobxitext <- renderText({
#       if(xiaccprob()<0.2){
#         return(". This is too low. Decrease your random walk variance.")
#       }
#       else if(xiaccprob()>0.4) {
#         return(". This is too high. Increase your random walk variance.")
#       }
#       else if(xiaccprob()>0.3 & xiaccprob()<0.4){
#         return(". This is slightly too high, but can be acceptable to use.")
#       }
#       else{
#         return(". This is good.")
#       }
#     })
#
#     output$tsplotlogsigma <- renderPlot({                                          #Trace plot for sigma
#
#       logsigmaplot <- plot(ts(sigma.mcmc()), xlab = "",main = "", ylab= "", cex.lab=1.3)
#       title(xlab = "Iteration", ylab = expression(sigma), main = expression(paste("Trace Plot of the Scale Parameter ", sigma)), cex.lab=1.3)
#       abline(h = mean(sigma.mcmc()), col = "blue", lwd = 2)
#       abline(h = Mode(sigma.mcmc(),input$denSmoothlogsigma), col = "green", lwd = 2)
#       abline(h = quantile(sigma.mcmc(), LOGSIGMAlower()), col = "red", lty = 2)
#       abline(h = quantile(sigma.mcmc(), LOGSIGMAupper()), col = "red", lty = 2)
#
#       return(logsigmaplot)
#
#     })
#
#     output$tsplotxi <- renderPlot({                                                #Trace plot for xi
#
#       xiplot <- plot(ts(xi.mcmc()), xlab = "",main = "", ylab= "", cex.lab=1.3)
#       title(xlab = "Iteration", ylab = expression(xi), main = expression(paste("Trace Plot of the Shape Parameter ", xi)), cex.lab=1.3)
#       abline(h = mean(xi.mcmc()), col = "blue", lwd = 2)
#       abline(h = Mode(xi.mcmc(),input$denSmoothxi), col = "green", lwd = 2)
#       abline(h = quantile(xi.mcmc(), XIlower()), col = "red", lty = 2)
#       abline(h = quantile(xi.mcmc(), XIupper()), col = "red", lty = 2)
#
#       return(xiplot)
#
#     })
#
#     #Actual densities
#
#     output$actdensityplotlogsigma <- renderPlot({
#
#       actdenslogsigma <- plot(density(sigma.mcmc(), bw = input$denSmoothlogsigma), main = expression(paste("Posterior vs Prior of the Scale Parameter ", sigma)), xlab = expression(sigma), cex.lab = 1.3)
#       x <- seq(-100, 100, by =0.01)
#       dx <- dnorm(x)
#       lines(x, dx, lty = 2)
#       legend("topright", legend = c("Prior", "Posterior"), border = "black", lty = c(2,1))
#       abline(v = mean(sigma.mcmc()), col = "blue", lwd = 2)
#       abline(v = Mode(sigma.mcmc(),input$denSmoothlogsigma), col = "green", lwd = 2)
#       abline(v = quantile(sigma.mcmc(), LOGSIGMAlower()), col = "red", lty = 2, lwd = 1.5)
#       abline(v = quantile(sigma.mcmc(), LOGSIGMAupper()), col = "red", lty = 2, lwd = 1.5)
#       return(actdenslogsigma)
#
#     })
#     output$actdensityplotxi <- renderPlot({
#
#       actdensxi <- plot(density(xi.mcmc(),bw = input$denSmoothxi),main = expression(paste("Posterior vs Prior of the Shape Parameter ", xi)), xlab = expression(xi), cex.lab = 1.3)
#       x <- seq(-100,100 , by =0.01)
#       dx <- dnorm(x)
#       lines(x, dx, lty = 2)
#       legend("topright", legend = c("Prior", "Posterior"), border = "black", lty = c(2,1))
#       abline(v = mean(xi.mcmc()), col = "blue", lwd = 2)
#       abline(v = Mode(xi.mcmc(),input$denSmoothxi), col = "green", lwd = 2)
#       abline(v = quantile(xi.mcmc(), XIlower()), col = "red", lty = 2, lwd = 1.5)
#       abline(v = quantile(xi.mcmc(), XIupper()), col = "red", lty = 2, lwd = 1.5)
#       return(actdensxi)
#
#     })
#
#
#     ################### USER SELECTED RETURN LEVEL TAB ###################      #Note this actually appears after the return level tab
#     returnlevel <- reactive ({ret.level.gpd(input$thresholdchoice,sigma.mcmc(),xi.mcmc(),as.numeric(input$occurrence),input$RLperiod,length(exceedances())/length(dataRead()))})
#     output$meanRL <- renderText({round(mean(returnlevel()), digits = 3)})
#     output$sdRL <- renderText({round(sd(returnlevel()), digits = 3)})
#     RLlower <- reactive({return(((100-input$CIRLslider)/200))})
#     RLupper <- reactive({return((RLlower() + (input$CIRLslider/100)))})
#     output$RLCIlower <- renderText({round(quantile(returnlevel(), RLlower()), digits = 3)})
#     output$RLCIupper <- renderText({round(quantile(returnlevel(), RLupper()), digits = 3)})
#     output$maxRL <- renderText({round(max(returnlevel()), digits = 3)})
#     output$titleaccprobrl <- renderText({return(input$CIRLslider)})
#     output$modeRL <- renderText({round(Mode(returnlevel(),input$RLsmooth), digits = 3)})
#
#     output$densplotRL <- renderPlot({
#
#       RLplot <- plot(density(returnlevel(), bw = input$RLsmooth), main = "Density of the Return Level", xlab = "Return Level",cex.lab = 1.3)
#       abline(v = mean(returnlevel()), col = "blue", lwd = 2)
#       abline(v = Mode(returnlevel(),input$RLsmooth), col = "green", lwd = 2)
#       abline(v = quantile(returnlevel(), RLlower()), col = "red", lty = 2)
#       abline(v = quantile(returnlevel(), RLupper()), col = "red", lty = 2)
#       abline(v = PRL()$root, col = "orange", lty = 3)
#
#       return(RLplot)
#
#     })
#
#     output$tsplotRL <- renderPlot({
#
#       RLplot1 <- plot(ts(returnlevel()), xlab="", ylab="")
#       title(xlab = "Iteration", ylab = "Return Level", cex.lab = 1.3)
#       abline(h = mean(returnlevel()), col = "blue", lwd = 2)
#       abline(h = Mode(returnlevel(),input$RLsmooth), col = "green", lwd = 2)
#       abline(h = quantile(returnlevel(), RLlower()), col = "red", lty = 2)
#       abline(h = quantile(returnlevel(), RLupper()), col = "red", lty = 2)
#       abline(h = PRL()$root, col = "orange", lty = 3)
#
#     })
#
#
#     ################### RETURN LEVEL TAB ###################
#
#     #GPD return level calculation
#
#
#     ret.level.gpd <- function(u,sigma,xi,ny,r,lambda)
#     { for(i in 1:length(xi)){
#         if(xi[i]==0){
#         ret.level <- u + sigma * log(ny*r*lambda)     #Case for xi=0 may need testing! (untested)
#       } else {
#         ret.level <- u + (sigma/xi)*((ny*r*lambda)**(xi)-1)
#      }
#       return(ret.level)
#       }
#     }
#     #All return levels use the above function, as well as lambda hat and ny.
#     returnlevel50 <- reactive ({ret.level.gpd(input$thresholdchoice,sigma.mcmc(),xi.mcmc(),as.numeric(input$occurrence),50,length(exceedances())/length(dataRead()))})
#     returnlevel100 <- reactive ({ret.level.gpd(input$thresholdchoice,sigma.mcmc(),xi.mcmc(),as.numeric(input$occurrence),100,length(exceedances())/length(dataRead()))})
#     returnlevel500 <- reactive ({ret.level.gpd(input$thresholdchoice,sigma.mcmc(),xi.mcmc(),as.numeric(input$occurrence),500,length(exceedances())/length(dataRead()))})
#     returnlevel1000 <- reactive ({ret.level.gpd(input$thresholdchoice,sigma.mcmc(),xi.mcmc(),as.numeric(input$occurrence),1000,length(exceedances())/length(dataRead()))})
#     returnlevel5000 <- reactive ({ret.level.gpd(input$thresholdchoice,sigma.mcmc(),xi.mcmc(),as.numeric(input$occurrence),5000,length(exceedances())/length(dataRead()))})
#     returnlevel10000 <- reactive ({ret.level.gpd(input$thresholdchoice,sigma.mcmc(),xi.mcmc(),as.numeric(input$occurrence),10000,length(exceedances())/length(dataRead()))})
#
#     output$meanRL50 <- renderText({round(mean(returnlevel50()), digits = 3)})
#     output$meanRL100 <- renderText({round(mean(returnlevel100()), digits = 3)})
#     output$meanRL500 <- renderText({round(mean(returnlevel500()), digits = 3)})
#     output$meanRL1000 <- renderText({round(mean(returnlevel1000()), digits = 3)})
#     output$meanRL5000 <- renderText({round(mean(returnlevel5000()), digits = 3)})
#     output$meanRL10000 <- renderText({round(mean(returnlevel10000()), digits = 3)})
#
#     output$sdRL50 <- renderText({round(sd(returnlevel50()), digits = 3)})
#     output$sdRL100 <- renderText({round(sd(returnlevel100()), digits = 3)})
#     output$sdRL500 <- renderText({round(sd(returnlevel500()), digits = 3)})
#     output$sdRL1000 <- renderText({round(sd(returnlevel1000()), digits = 3)})
#     output$sdRL5000 <- renderText({round(sd(returnlevel5000()), digits = 3)})
#     output$sdRL10000 <- renderText({round(sd(returnlevel10000()), digits = 3)})
#
#     RLlower50 <- reactive({return(((100-input$CIRLslider50)/200))})
#     RLupper50 <- reactive({return((RLlower50() + (input$CIRLslider50/100)))})
#
#     RLlower100 <- reactive({return(((100-input$CIRLslider100)/200))})
#     RLupper100 <- reactive({return((RLlower100() + (input$CIRLslider100/100)))})
#
#     RLlower500 <- reactive({return(((100-input$CIRLslider500)/200))})
#     RLupper500 <- reactive({return((RLlower500() + (input$CIRLslider500/100)))})
#
#     RLlower1000 <- reactive({return(((100-input$CIRLslider1000)/200))})
#     RLupper1000 <- reactive({return((RLlower1000() + (input$CIRLslider1000/100)))})
#
#     RLlower5000 <- reactive({return(((100-input$CIRLslider5000)/200))})
#     RLupper5000 <- reactive({return((RLlower5000() + (input$CIRLslider5000/100)))})
#
#     RLlower10000 <- reactive({return(((100-input$CIRLslider10000)/200))})
#     RLupper10000 <- reactive({return((RLlower10000() + (input$CIRLslider10000/100)))})
#
#     #Return level quantiles
#     output$RLCIlower50 <- renderText({round(quantile(returnlevel50(), RLlower50()), digits = 3)})
#     output$RLCIupper50 <- renderText({round(quantile(returnlevel50(), RLupper50()), digits = 3)})
#
#     output$RLCIlower100 <- renderText({round(quantile(returnlevel100(), RLlower100()), digits = 3)})
#     output$RLCIupper100 <- renderText({round(quantile(returnlevel100(), RLupper100()), digits = 3)})
#
#     output$RLCIlower500 <- renderText({round(quantile(returnlevel500(), RLlower500()), digits = 3)})
#     output$RLCIupper500 <- renderText({round(quantile(returnlevel500(), RLupper500()), digits = 3)})
#
#     output$RLCIlower1000 <- renderText({round(quantile(returnlevel1000(), RLlower1000()), digits = 3)})
#     output$RLCIupper1000 <- renderText({round(quantile(returnlevel1000(), RLupper1000()), digits = 3)})
#
#     output$RLCIlower5000 <- renderText({round(quantile(returnlevel5000(), RLlower5000()), digits = 3)})
#     output$RLCIupper5000 <- renderText({round(quantile(returnlevel5000(), RLupper5000()), digits = 3)})
#
#     output$RLCIlower10000 <- renderText({round(quantile(returnlevel10000(), RLlower10000()), digits = 3)})
#     output$RLCIupper10000 <- renderText({round(quantile(returnlevel10000(), RLupper10000()), digits = 3)})
#
#     #Confidence interval title reactives
#     output$titleaccprobrl50 <- renderText({return(input$CIRLslider50)})
#     output$titleaccprobrl100 <- renderText({return(input$CIRLslider100)})
#     output$titleaccprobrl500 <- renderText({return(input$CIRLslider500)})
#     output$titleaccprobrl1000 <- renderText({return(input$CIRLslider1000)})
#     output$titleaccprobrl5000 <- renderText({return(input$CIRLslider5000)})
#     output$titleaccprobrl10000 <- renderText({return(input$CIRLslider10000)})
#
#     #Mode reactives
#     #Note that the BW term is necessary in order to be consistent with the graph
#     output$modeRL50 <- renderText({round(Mode(returnlevel50(),input$RLsmooth50), digits = 3)})
#     output$modeRL100 <- renderText({round(Mode(returnlevel100(),input$RLsmooth100), digits = 3)})
#     output$modeRL500 <- renderText({round(Mode(returnlevel500(),input$RLsmooth500), digits = 3)})
#     output$modeRL1000 <- renderText({round(Mode(returnlevel1000(),input$RLsmooth1000), digits = 3)})
#     output$modeRL5000 <- renderText({round(Mode(returnlevel5000(),input$RLsmooth5000), digits = 3)})
#     output$modeRL10000 <- renderText({round(Mode(returnlevel10000(),input$RLsmooth10000), digits = 3)})
#
#
#     #Histogram plots
#
#     output$densplotRL50 <- renderPlot({
#
#       RLplot <- plot(density(returnlevel50(), bw = input$RLsmooth50), main = "Density of the Return Level", xlab = paste("Return Level (", input$dataUnits, ")"),cex.lab = 1.3)
#       abline(v = mean(returnlevel50()), col = "blue", lwd = 2)
#       abline(v = Mode(returnlevel50(),input$RLsmooth50), col = "green", lwd = 2)
#       abline(v = quantile(returnlevel50(), RLlower50()), col = "red", lty = 2)
#       abline(v = quantile(returnlevel50(), RLupper50()), col = "red", lty = 2)
#       abline(v = PRL50()$root, col = "orange", lty = 2)
#       return(RLplot)
#
#     })
#
#     output$densplotRL100 <- renderPlot({
#
#       RLplot <- plot(density(returnlevel100(), bw = input$RLsmooth100), main = "Density of the Return Level", xlab = paste("Return Level (", input$dataUnits, ")"),cex.lab = 1.3)
#       abline(v = mean(returnlevel100()), col = "blue", lwd = 2)
#       abline(v = Mode(returnlevel100(),input$RLsmooth100), col = "green", lwd = 2)
#       abline(v = quantile(returnlevel100(), RLlower100()), col = "red", lty = 2)
#       abline(v = quantile(returnlevel100(), RLupper100()), col = "red", lty = 2)
#       abline(v = PRL100()$root, col = "orange", lty = 2)
#       return(RLplot)
#
#     })
#
#     output$densplotRL500 <- renderPlot({
#
#       RLplot <- plot(density(returnlevel500(), bw = input$RLsmooth500), main = "Density of the Return Level", xlab = paste("Return Level (", input$dataUnits, ")"),cex.lab = 1.3)
#       abline(v = mean(returnlevel500()), col = "blue", lwd = 2)
#       abline(v = Mode(returnlevel500(),input$RLsmooth500), col = "green", lwd = 2)
#       abline(v = quantile(returnlevel500(), RLlower500()), col = "red", lty = 2)
#       abline(v = quantile(returnlevel500(), RLupper500()), col = "red", lty = 2)
#       abline(v = PRL500()$root, col = "orange", lty = 2)
#       return(RLplot)
#
#     })
#
#     output$densplotRL1000 <- renderPlot({
#
#       RLplot <- plot(density(returnlevel1000(), bw = input$RLsmooth1000), main = "Density of the Return Level", xlab = paste("Return Level (", input$dataUnits, ")"),cex.lab = 1.3)
#       abline(v = mean(returnlevel1000()), col = "blue", lwd = 2)
#       abline(v = Mode(returnlevel1000(),input$RLsmooth1000), col = "green", lwd = 2)
#       abline(v = quantile(returnlevel1000(), RLlower1000()), col = "red", lty = 2)
#       abline(v = quantile(returnlevel1000(), RLupper1000()), col = "red", lty = 2)
#       abline(v = PRL1000()$root, col = "orange", lty = 2)
#       return(RLplot)
#
#     })
#
#     output$densplotRL5000 <- renderPlot({
#
#       RLplot <- plot(density(returnlevel5000(), bw = input$RLsmooth5000), main = "Density of the Return Level", xlab = paste("Return Level (", input$dataUnits, ")"),cex.lab = 1.3)
#       abline(v = mean(returnlevel5000()), col = "blue", lwd = 2)
#       abline(v = Mode(returnlevel5000(),input$RLsmooth5000), col = "green", lwd = 2)
#       abline(v = quantile(returnlevel5000(), RLlower5000()), col = "red", lty = 2)
#       abline(v = quantile(returnlevel5000(), RLupper5000()), col = "red", lty = 2)
#       abline(v = PRL5000()$root, col = "orange", lty = 2)
#       return(RLplot)
#
#     })
#
#     output$densplotRL10000 <- renderPlot({
#
#       RLplot <- plot(density(returnlevel10000(), bw = input$RLsmooth10000), main = "Density of the Return Level", xlab = paste("Return Level (", input$dataUnits, ")"),cex.lab = 1.3)
#       abline(v = mean(returnlevel10000()), col = "blue", lwd = 2)
#       abline(v = Mode(returnlevel10000(),input$RLsmooth10000), col = "green", lwd = 2)
#       abline(v = quantile(returnlevel10000(), RLlower10000()), col = "red", lty = 2)
#       abline(v = quantile(returnlevel10000(), RLupper10000()), col = "red", lty = 2)
#       abline(v = PRL10000()$root, col = "orange", lty = 2)
#       return(RLplot)
#
#     })
#
#
#     #Trace plots
#
#     output$tsplotRL50 <- renderPlot({
#
#       RLplot1 <- plot(ts(returnlevel50()), xlab="", ylab="")
#       title(xlab = "Iteration", ylab = paste("Return Level (",input$dataUnits, ")"), cex.lab = 1.3)
#       abline(h = mean(returnlevel50()), col = "blue", lwd = 2)
#       abline(h = Mode(returnlevel50(),input$RLsmooth50), col = "green", lwd = 2)
#       abline(h = quantile(returnlevel50(), RLlower50()), col = "red", lty = 2)
#       abline(h = quantile(returnlevel50(), RLupper50()), col = "red", lty = 2)
#       abline(h = PRL50()$root, col = "orange", lty = 3)
#     })
#
#     output$tsplotRL100 <- renderPlot({
#
#       RLplot1 <- plot(ts(returnlevel100()), xlab="", ylab="")
#       title(xlab = "Iteration", ylab = paste("Return Level (",input$dataUnits, ")"), cex.lab = 1.3)
#       abline(h = mean(returnlevel100()), col = "blue", lwd = 2)
#       abline(h = Mode(returnlevel100(),input$RLsmooth100), col = "green", lwd = 2)
#       abline(h = quantile(returnlevel100(), RLlower100()), col = "red", lty = 2)
#       abline(h = quantile(returnlevel100(), RLupper100()), col = "red", lty = 2)
#       abline(h = PRL100()$root, col = "orange", lty = 3)
#     })
#
#     output$tsplotRL500 <- renderPlot({
#
#       RLplot1 <- plot(ts(returnlevel500()), xlab="", ylab="")
#       title(xlab = "Iteration", ylab = paste("Return Level (",input$dataUnits, ")"), cex.lab = 1.3)
#       abline(h = mean(returnlevel500()), col = "blue", lwd = 2)
#       abline(h = Mode(returnlevel500(),input$RLsmooth500), col = "green", lwd = 2)
#       abline(h = quantile(returnlevel500(), RLlower500()), col = "red", lty = 2)
#       abline(h = quantile(returnlevel500(), RLupper500()), col = "red", lty = 2)
#       abline(h = PRL500()$root, col = "orange", lty = 3)
#     })
#
#     output$tsplotRL1000 <- renderPlot({
#
#       RLplot1 <- plot(ts(returnlevel1000()), xlab="", ylab="")
#       title(xlab = "Iteration", ylab = paste("Return Level (",input$dataUnits, ")"), cex.lab = 1.3)
#       abline(h = mean(returnlevel1000()), col = "blue", lwd = 2)
#       abline(h = Mode(returnlevel1000(),input$RLsmooth1000), col = "green", lwd = 2)
#       abline(h = quantile(returnlevel1000(), RLlower1000()), col = "red", lty = 2)
#       abline(h = quantile(returnlevel1000(), RLupper1000()), col = "red", lty = 2)
#       abline(h = PRL1000()$root, col = "orange", lty = 3)
#     })
#
#     output$tsplotRL5000 <- renderPlot({
#
#       RLplot1 <- plot(ts(returnlevel5000()), xlab="", ylab="")
#       title(xlab = "Iteration", ylab = paste("Return Level (",input$dataUnits, ")"), cex.lab = 1.3)
#       abline(h = mean(returnlevel5000()), col = "blue", lwd = 2)
#       abline(h = Mode(returnlevel5000(),input$RLsmooth5000), col = "green", lwd = 2)
#       abline(h = quantile(returnlevel5000(), RLlower5000()), col = "red", lty = 2)
#       abline(h = quantile(returnlevel5000(), RLupper5000()), col = "red", lty = 2)
#       abline(h = PRL5000()$root, col = "orange", lty = 3)
#     })
#
#     output$tsplotRL10000 <- renderPlot({
#
#       RLplot1 <- plot(ts(returnlevel10000()), xlab="", ylab="")
#       title(xlab = "Iteration", ylab = paste("Return Level (",input$dataUnits, ")"), cex.lab = 1.3)
#       abline(h = mean(returnlevel10000()), col = "blue", lwd = 2)
#       abline(h = Mode(returnlevel10000(),input$RLsmooth10000), col = "green", lwd = 2)
#       abline(h = quantile(returnlevel10000(), RLlower10000()), col = "red", lty = 2)
#       abline(h = quantile(returnlevel10000(), RLupper10000()), col = "red", lty = 2)
#       abline(h = PRL10000()$root, col = "orange", lty = 3)
#     })
#
#
#     ########################################################
#     ##############  Predictive Return Level ################
#     ########################################################
#
#     f = function(zrpred, u, sigma, xi, ny, r, lambda) {
#       B = length(sigma)
#       summ = vector("numeric", length = B)
#       for (i in 1:B) {
#         if (xi[i] == 0) {
#           summ[i] = 1 - lambda * exp(-(zrpred - u) / sigma[i])    #needs checking
#         } else {
#           if(1 + xi[i] * (zrpred - u) / sigma[i] < 0) {
#             summ[i] = 1
#           } else {
#           summ[i] = 1 - lambda * (1 + xi[i] * (zrpred - u) / sigma[i]) ** (-1 / xi[i])
#           }
#         }
#       }
#       # Could (sum(summ) / B) be simplified to mean(summ)?
#       return((sum(summ) / B) - (1 - 1 / (ny*r)))
#     }
#
#     PRL <- reactive({uniroot(f, lower = 1, upper = 10*max(dataRead()), u =  input$thresholdchoice, sigma = sigma.mcmc(), xi = xi.mcmc(),ny=as.numeric(input$occurrence), r = input$RLperiod,lambda=length(exceedances())/length(dataRead()))})
#     PRL50 <- reactive({uniroot(f, lower = 1, upper = 10*max(dataRead()), u = input$thresholdchoice, sigma = sigma.mcmc(), xi = xi.mcmc(),ny=as.numeric(input$occurrence), r = 50,lambda=length(exceedances())/length(dataRead()))})
#     PRL100 <- reactive({uniroot(f, lower = 1, upper = 10*max(dataRead()), u =  input$thresholdchoice, sigma = sigma.mcmc(), xi = xi.mcmc(),ny=as.numeric(input$occurrence), r = 100,lambda=length(exceedances())/length(dataRead()))})
#     PRL500 <- reactive({uniroot(f, lower = 1, upper = 10*max(dataRead()), u =  input$thresholdchoice, sigma = sigma.mcmc(), xi = xi.mcmc(),ny=as.numeric(input$occurrence), r = 500,lambda=length(exceedances())/length(dataRead()))})
#     PRL1000 <- reactive({uniroot(f, lower = 1, upper = 10*max(dataRead()), u =  input$thresholdchoice, sigma = sigma.mcmc(), xi = xi.mcmc(),ny=as.numeric(input$occurrence), r = 1000,lambda=length(exceedances())/length(dataRead()))})
#     PRL5000 <- reactive({uniroot(f, lower = 1, upper = 10*max(dataRead()), u =  input$thresholdchoice, sigma = sigma.mcmc(), xi = xi.mcmc(),ny=as.numeric(input$occurrence), r = 5000,lambda=length(exceedances())/length(dataRead()))})
#     PRL10000 <- reactive({uniroot(f, lower = 1, upper = 10*max(dataRead()), u =  input$thresholdchoice, sigma = sigma.mcmc(), xi = xi.mcmc(),ny=as.numeric(input$occurrence), r = 10000,lambda=length(exceedances())/length(dataRead()))})
#     output$PRLyears <- renderText({input$RLperiod})
#     output$years <- renderText({"years:"})
#     output$PRL1 <- renderText({round(PRL()$root, digit = 3)})
#     output$PRL501 <- renderText({round(PRL50()$root, digits = 3)})
#     output$PRL1001 <- renderText({round(PRL100()$root, digits = 3)})
#     output$PRL5001 <- renderText({round(PRL500()$root, digits = 3)})
#     output$PRL10001 <- renderText({round(PRL1000()$root, digits = 3)})
#     output$PRL50001 <- renderText({round(PRL5000()$root, digits = 3)})
#     output$PRL100001 <- renderText({round(PRL10000()$root, digits = 3)})
#
#
#     #RETURN LEVEL VS MEAN RETURN LEVEL PLOTS
#
#     output$newRLplot <- renderPlot({
#       input$PRLRLplot
#       x <- seq(10, 10000, 10)
#       xlog <- -log(-log(1 - (1 / x)))
#       manyRL1 <- vector("numeric", length = 1000)
#       manyCIL <- vector("numeric", length = 1000)
#       manyCIU <- vector("numeric", length = 1000)
#
#       for(i in seq(10, 10000, 10)){
#         listofreturnlevels <- ret.level.gpd(input$thresholdchoice,sigma.mcmc(),xi.mcmc(),as.numeric(input$occurrence),i,length(exceedances())/length(dataRead()))
#         manyRL1[i] <- mean(listofreturnlevels)
#         manyCI1 <- quantile(listofreturnlevels, c(0.025, 0.975))
#         manyCIL[i] <- manyCI1[1]
#         manyCIU[i] <- manyCI1[2]
#       }
#       manyRL2 <- manyRL1[!is.na(manyRL1)]
#       manyRL3 <- manyRL2[manyRL2 != 0]
#
#       manyCIL2 <- manyCIL[!is.na(manyCIL)]
#       manyCIL3 <- manyCIL2[manyCIL2 != 0]
#
#       manyCIU2 <- manyCIU[!is.na(manyCIU)]
#       manyCIU3 <- manyCIU2[manyCIU2 != 0]
#
#       manyPRL1 <- vector("numeric", length = 1000)
#       for(i in seq(10, 10000, 10)){
#         manyPRL1[i] <- uniroot(f, lower = 1, upper = 1000*max(dataRead()), u =  input$thresholdchoice, sigma = sigma.mcmc(), xi = xi.mcmc(),ny=as.numeric(input$occurrence), r=i,lambda=length(exceedances())/length(dataRead()))$root
#       }        #Note: this uniroot returns an error in some instances where the threshold is low - specifically, it doesn't like the endpoints.
#       manyPRL2 <- manyPRL1[!is.na(manyPRL1)]
#       manyPRL3 <- manyPRL2[!manyPRL2==0]
#
#       plot(xlog, manyRL3, type="l", ylim = c(min(manyCIL3), max(manyCIU3)), xaxt = 'n', xlab = "Years/Period", ylab = "Return Level")
#       x <- seq(10,10000,10)
#       xlog <- -log(-log(1-(1/x)))
#       axis(side = 1, at = c(xlog[1],xlog[5],xlog[10],xlog[50],xlog[100],xlog[500],xlog[1000]), labels = c(10,50,100,500,1000,5000,10000), tick = TRUE)
#       lines(xlog, manyPRL3, col = "red")
#       lines(xlog, manyCIL3, lty = 2)
#       lines(xlog, manyCIU3, lty = 2)
#       legend("topleft", legend = c("Posterior Return Level Mean", "Predictive Return Level", "95% CI Interval"), border = "black", lty = c(1,1,2), col = c("Black", "Red", "Black"))
#     })
#
#     ###################################################################################################################
#     ####################################### SUMMARY TABLE ON LAST BAYESIAN TAB ########################################
#     ###################################################################################################################
#
#     returnleveluser <- reactive ({ret.level.gpd(input$thresholdchoice,sigma.mcmc(),xi.mcmc(),as.numeric(input$occurrence),input$RLperiodgraph,length(exceedances())/length(dataRead()))})
#     PRLusergraph <- reactive({uniroot(f, lower = 1, upper = 10*max(dataRead()), u =  input$thresholdchoice, sigma = sigma.mcmc(), xi = xi.mcmc(),ny = as.numeric(input$occurrence), r = input$RLperiodgraph,lambda = length(exceedances())/length(dataRead()))})
#     meanRLusergraph <- reactive({round(mean(returnlevel()), digits = 3)})
#     meanRL50graph <- reactive({round(mean(returnlevel50()), digits = 3)})
#     meanRL100graph <- reactive({round(mean(returnlevel100()), digits = 3)})
#     meanRL500graph <- reactive({round(mean(returnlevel500()), digits = 3)})
#     meanRL1000graph <- reactive({round(mean(returnlevel1000()), digits = 3)})
#     meanRL5000graph <- reactive({round(mean(returnlevel5000()), digits = 3)})
#     meanRL10000graph <- reactive({round(mean(returnlevel10000()), digits = 3)})
#
#     sdRLusergraph <- reactive({round(sd(returnleveluser()), digits = 3)})
#     sdRL50graph <- reactive({round(sd(returnlevel50()), digits = 3)})
#     sdRL100graph <- reactive({round(sd(returnlevel100()), digits = 3)})
#     sdRL500graph <- reactive({round(sd(returnlevel500()), digits = 3)})
#     sdRL1000graph <- reactive({round(sd(returnlevel1000()), digits = 3)})
#     sdRL5000graph <- reactive({round(sd(returnlevel5000()), digits = 3)})
#     sdRL10000graph <- reactive({round(sd(returnlevel10000()), digits = 3)})
#
#     RLlowergraph <- reactive({return(((100-input$CIRLslidergraph)/200))})
#     RLuppergraph <- reactive({return((RLlowergraph() + (input$CIRLslidergraph/100)))})
#
#
#     #Return level quantiles
#     RLCIlowerusergraph <- reactive({round(quantile(returnleveluser(), RLlowergraph()), digits = 3)})
#     RLCIupperusergraph <- reactive({round(quantile(returnleveluser(), RLuppergraph()), digits = 3)})
#
#     RLCIlower50graph <- reactive({round(quantile(returnlevel50(), RLlowergraph()), digits = 3)})
#     RLCIupper50graph <- reactive({round(quantile(returnlevel50(), RLuppergraph()), digits = 3)})
#
#     RLCIlower50graph <- reactive({round(quantile(returnlevel50(), RLlowergraph()), digits = 3)})
#     RLCIupper50graph <- reactive({round(quantile(returnlevel50(), RLuppergraph()), digits = 3)})
#
#     RLCIlower100graph <- reactive({round(quantile(returnlevel100(), RLlowergraph()), digits = 3)})
#     RLCIupper100graph <- reactive({round(quantile(returnlevel100(), RLuppergraph()), digits = 3)})
#
#     RLCIlower500graph <- reactive({round(quantile(returnlevel500(), RLlowergraph()), digits = 3)})
#     RLCIupper500graph <- reactive({round(quantile(returnlevel500(), RLuppergraph()), digits = 3)})
#
#     RLCIlower1000graph <- reactive({round(quantile(returnlevel1000(), RLlowergraph()), digits = 3)})
#     RLCIupper1000graph <- reactive({round(quantile(returnlevel1000(), RLuppergraph()), digits = 3)})
#
#     RLCIlower5000graph <- reactive({round(quantile(returnlevel5000(), RLlowergraph()), digits = 3)})
#     RLCIupper5000graph <- reactive({round(quantile(returnlevel5000(), RLuppergraph()), digits = 3)})
#
#     RLCIlower10000graph <- reactive({round(quantile(returnlevel10000(), RLlowergraph()), digits = 3)})
#     RLCIupper10000graph <- reactive({round(quantile(returnlevel10000(), RLuppergraph()), digits = 3)})
#
#
#     #Confidence interval title reactives
#     titleaccprobrl50 <- reactive({return(input$CIRLslidergraph)})
#
#     #Mode reactives
#     modeRLusergraph <- reactive({round(Mode(returnleveluser(),input$RLsmooth), digits = 3)})
#     modeRL50graph <- reactive({round(Mode(returnlevel50(),input$RLsmooth50), digits = 3)})
#     modeRL100graph <- reactive({round(Mode(returnlevel100(),input$RLsmooth100), digits = 3)})
#     modeRL500graph <- reactive({round(Mode(returnlevel500(),input$RLsmooth500), digits = 3)})
#     modeRL1000graph <- reactive({round(Mode(returnlevel1000(),input$RLsmooth1000), digits = 3)})
#     modeRL5000graph <- reactive({round(Mode(returnlevel5000(),input$RLsmooth5000), digits = 3)})
#     modeRL10000graph <- reactive({round(Mode(returnlevel10000(),input$RLsmooth10000), digits = 3)})
#
#     PRLusergraphroot <- reactive({round(PRLusergraph()$root, digit = 3)})
#     PRL501graph <- reactive({round(PRL50()$root, digits = 3)})
#     PRL1001graph <- reactive({round(PRL100()$root, digits = 3)})
#     PRL5001graph <- reactive({round(PRL500()$root, digits = 3)})
#     PRL10001graph <- reactive({round(PRL1000()$root, digits = 3)})
#     PRL50001graph <- reactive({round(PRL5000()$root, digits = 3)})
#     PRL100001graph <- reactive({round(PRL10000()$root, digits = 3)})
#
#     output$SummaryTableRL <- renderTable({
#
#       Summary <- data.frame( years = c("50", "100", "500", "1000", "5000", "10000", input$RLperiodgraph),
#                              mean = c(meanRL50graph(),meanRL100graph(),meanRL500graph(),meanRL1000graph(),meanRL5000graph(),meanRL10000graph(), meanRLusergraph()),
#                              sd = c(sdRL50graph(),sdRL100graph(),sdRL500graph(),sdRL1000graph(),sdRL5000graph(),sdRL10000graph(),sdRLusergraph()),
#                              mode = c(modeRL50graph(),modeRL100graph(),modeRL500graph(),modeRL1000graph(),modeRL5000graph(),modeRL10000graph(),modeRLusergraph()),
#                              lci = c(RLCIlower50graph(),RLCIlower100graph(),RLCIlower500graph(),RLCIlower1000graph(),RLCIlower5000graph(),RLCIlower10000graph(),RLCIlowerusergraph()),
#                              uci = c(RLCIupper50graph(),RLCIupper100graph(),RLCIupper500graph(),RLCIupper1000graph(),RLCIupper5000graph(),RLCIupper10000graph(), RLCIupperusergraph()),
#                              prl = c(PRL501graph(),PRL1001graph(),PRL5001graph(),PRL10001graph(),PRL50001graph(),PRL100001graph(), PRLusergraphroot()))
#
#       colnames(Summary) <- c("Period",
#                              "Posterior Mean",
#                              "Posterior SD",
#                              "Posterior Mode",
#                              paste(input$CIRLslidergraph, "% Bayesian CI Lower Bound"),
#                              paste(input$CIRLslidergraph, "% Bayesian CI Upper Bound"),
#                              "Predictive Return Level")
#       return(Summary)
#     })
#
#             ######GOODNESS OF FIT FOR BAYESIAN######
#
#     output$Pplotbayes <- renderPlot({
#       ordered = sort(exceedances())
#       empirical=vector('numeric',length(exceedances()))
#       for(i in 1:length(empirical)){
#         empirical[i]=i/(length(empirical)+1)
#       }
#       GPD.DF=function(data,sigma,xi){
#         if(xi==0){
#           GPD=1-exp(-data/sigma)
#         }
#         else{
#           GPD=1-(1+(xi*data)/sigma)^(-1/xi)
#         }
#         return(GPD)
#       }
#       model=vector('numeric',length(exceedances()))
#       for(i in 1:length(exceedances())){
#         model[i]=GPD.DF(ordered[i],mean(sigma.mcmc()),mean(xi.mcmc()))
#       }
#       plot(model~empirical,col = "magenta",main='Probability plot',pch = 19,xlab="Empirical",ylab="Model",cex.lab = 1.3)
#       abline(0,1)
#     })
#
#     #Quantile-quantile plot
#     output$QQplotbayes <- renderPlot({
#       ordered = sort(exceedances())
#       model.quantile=vector('numeric',length(exceedances()))
#       empirical=vector('numeric',length(exceedances()))
#       for(i in 1:length(empirical)){
#         empirical[i]=i/(length(empirical)+1)
#       }
#       GPD.INV=function(data,sigma,xi){
#         if(xi==0){
#           INV = -sigma*log(1-data)}
#         else{
#           INV = sigma/xi * ((1-data)^(-xi)-1)}
#         return(INV)}
#       for(i in 1:length(model.quantile)){
#         model.quantile[i]=GPD.INV(empirical[i],mean(sigma.mcmc()),mean(xi.mcmc()))
#       }
#       plot(model.quantile,ordered, col = "magenta",main='Quantile plot',pch = 19, xlab="Model quantile", ylab="Ordered data",cex.lab = 1.3)
#       abline(0,1)
#     })
  }
)
